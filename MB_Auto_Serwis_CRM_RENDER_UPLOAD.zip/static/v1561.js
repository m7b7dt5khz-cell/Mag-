/* MB Auto Serwis 15.6.4 — B2B product name + catalog price as default sale price */
(()=>{
'use strict';
const el=id=>document.getElementById(id);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const normMb=v=>String(v||'').toUpperCase().replace(/[\s.\-]+/g,'').replace(/[^A-Z0-9]/g,'');
let b2bOpenLock=0,b2bSearchBusy=false;

function setB2BStatus(text,state=''){
  const x=el('productB2BSearchStatus');if(!x)return;x.textContent=text;x.dataset.state=state;
}
async function b2bPortalOnline(){
  try{
    const d=await api('/api/quick-catalog');
    return (d.portals||[]).some(p=>p.online&&['B2B','XENTRY'].includes(String(p.source||'').toUpperCase()));
  }catch(_){return false}
}
async function ensureB2BPortal(){
  if(await b2bPortalOnline())return {reused:true};
  const now=Date.now();if(b2bOpenLock&&now-b2bOpenLock<20000)return {opening:true};b2bOpenLock=now;
  try{
    await api('/api/system/open-chrome',{method:'POST',body:JSON.stringify({url:'https://b2bconnect.mercedes-benz.com/pl/catalog'})});
    return {opened:true};
  }catch(e){
    throw new Error(e?.code==='chrome_not_found'?'Nie znaleziono Google Chrome':'Nie udało się otworzyć Mercedes B2B');
  }
}
function mergeAliases(current,item){
  const vals=[];const seen=new Set();
  const add=v=>{const n=normMb(v);if(n&&!seen.has(n)){seen.add(n);vals.push(n)}};
  String(current||'').split(/[,;\s]+/).forEach(add);
  for(const k of ['related_numbers','replacement_numbers','substitute_numbers'])for(const v of (Array.isArray(item?.[k])?item[k]:[]))add(v);
  return vals.join(', ');
}
function invalidB2BName(v){
  const x=String(v||'').trim();
  if(!x)return true;
  return /^(?:cena\s*(?:netto|katalogowa)|llp|cl|cn|dodaj|szukaj|sprawdź\s+szybszą\s+dostępność|ilość|pln)\s*:?$/i.test(x);
}
function applyB2BToProductForm(item){
  if(!item||typeof item!=='object')return;
  const nm=String(item.name||'').trim();
  if(nm&&!invalidB2BName(nm)&&el('name')){
    const cur=String(el('name').value||'').trim();
    if(!cur||invalidB2BName(cur)||/^Mercedes-Benz OEM\b/i.test(cur)||/^Do skatalogowania\b/i.test(cur))el('name').value=nm;
  }
  const buy=Number(item.purchase_price||0),cat=Number(item.suggested_price||0);
  if(buy>0&&el('purchase_price')){el('purchase_price').value=buy.toFixed(2);el('purchase_price').dispatchEvent(new Event('input',{bubbles:true}))}
  if(cat>0){
    if(el('sale_price')){el('sale_price').value=cat.toFixed(2);el('sale_price').dispatchEvent(new Event('input',{bubbles:true}))}
    // Cena katalogowa B2B = domyślna cena sprzedaży netto.
    // Zdarzenie input na sell_price_net przelicza również marżę/narzut i brutto.
    if(el('sell_price_net')){el('sell_price_net').value=cat.toFixed(2);el('sell_price_net').dispatchEvent(new Event('input',{bubbles:true}))}
  }
  if(item.diagram_position&&el('diagram_position')&&!el('diagram_position').value)el('diagram_position').value=String(item.diagram_position);
  if(el('productAliasesInput'))el('productAliasesInput').value=mergeAliases(el('productAliasesInput').value,item);
}
async function pollManualSearch(id,code){
  for(let i=0;i<95;i++){
    await sleep(1000);
    const d=await api(`/api/b2b/manual-search/status?id=${encodeURIComponent(id)}`).catch(()=>null);
    const r=d?.request;if(!r)continue;
    const st=String(r.status||'').toUpperCase();
    if(st==='DONE'){
      applyB2BToProductForm(r.item||{});
      const price=Number(r.item?.purchase_price||0);const cat=Number(r.item?.suggested_price||0);
      setB2BStatus(`B2B: ${code} znaleziony${price?` · zakup ${price.toFixed(2)} zł`:''}${cat?` · katalog ${cat.toFixed(2)} zł`:''}.`,'ok');
      toast('B2B: dane części uzupełnione w formularzu');return true;
    }
    if(st==='ERROR'){
      setB2BStatus(`B2B: ${r.error||'nie udało się odczytać danych'}. Wynik może być widoczny w otwartej karcie B2B.`,'error');
      toast('B2B: wyszukiwanie zakończone z błędem odczytu');return false;
    }
    setB2BStatus(`B2B: szukam ${code}…`,'working');
  }
  setB2BStatus(`B2B nadal przetwarza ${code}. Karta B2B pozostaje otwarta.`,'working');return false;
}
async function searchProductInB2B(){
  if(b2bSearchBusy)return;
  const code=normMb(el('oem_no')?.value||el('sku')?.value||'');
  if(!code||code.length<8){setB2BStatus('Wpisz prawidłowy numer OEM Mercedes.','error');el('oem_no')?.focus();return}
  b2bSearchBusy=true;const btn=el('productB2BSearch');if(btn){btn.disabled=true;btn.textContent='Szukam…'};
  try{
    setB2BStatus(`B2B: zlecam wyszukiwanie ${code}…`,'working');
    const r=await api('/api/b2b/manual-search/request',{method:'POST',body:JSON.stringify({oem:code})});
    await ensureB2BPortal();
    setB2BStatus(`B2B: szukam ${code} w otwartej karcie…`,'working');
    await pollManualSearch(r.request_id,code);
  }catch(e){
    setB2BStatus(e?.message||'Nie udało się uruchomić wyszukiwania B2B.','error');toast('Nie udało się uruchomić wyszukiwania B2B');
  }finally{b2bSearchBusy=false;if(btn){btn.disabled=false;btn.textContent='Szukaj w B2B'}}
}
function bind(){
  const b=el('productB2BSearch');if(b&&!b.dataset.mb1561){b.dataset.mb1561='1';b.addEventListener('click',searchProductInB2B)}
  const o=el('oem_no');if(o&&!o.dataset.mb1561){o.dataset.mb1561='1';o.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();searchProductInB2B()}})}
}
const mo=new MutationObserver(bind);mo.observe(document.documentElement,{childList:true,subtree:true});bind();
})();
