/* MB Auto Serwis 15.4.1 — Excel import narzędzi */
(()=>{
'use strict';
const $=id=>document.getElementById(id);
function ab64(buf){
  const bytes=new Uint8Array(buf);let binary='';const step=0x8000;
  for(let i=0;i<bytes.length;i+=step)binary+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+step,bytes.length)));
  return btoa(binary);
}
async function runImport(file){
  if(!file)return;
  if(!/\.xlsx$/i.test(file.name)){window.alert('Wybierz plik Excel .xlsx');return;}
  const btn=$('importToolExcelBtn');if(btn)btn.disabled=true;
  try{
    if(typeof toast==='function')toast('Analizuję plik narzędzi…');
    const data_b64=ab64(await file.arrayBuffer());
    const pre=await api('/api/tools/import-xlsx',{method:'POST',body:JSON.stringify({filename:file.name,data_b64,dry_run:true})});
    const msg=[
      `Rozpoznano pozycji: ${pre.recognized||0}`,
      `Nowe pozycje: ${pre.new_rows||0}`,
      `Duplikaty do pominięcia: ${pre.duplicates||0}`,
      `Zdjęcia osadzone w Excelu: ${pre.images||0}`,
      `Pozycje EUR: ${pre.eur_rows||0}`,
      `Pozycje PLN: ${pre.pln_rows||0}`,
      `Daty wymagające kursu NBP: ${pre.nbp_dates||0}`,
      '',
      'Import nie nadpisuje istniejących identycznych zakupów. Ten sam numer katalogowy z inną fakturą/datą/ceną zostanie zachowany jako osobny zakup.',
      '',
      'Zaimportować dane do Kartoteki narzędzi?'
    ].join('\n');
    if(!window.confirm(msg))return;
    if(typeof toast==='function')toast('Importuję narzędzia i pobieram kursy NBP…');
    const out=await api('/api/tools/import-xlsx',{method:'POST',body:JSON.stringify({filename:file.name,data_b64,dry_run:false})});
    const errors=out.errors||[];
    window.alert([
      'Import narzędzi zakończony.',
      '',
      `Dodano: ${out.imported||0}`,
      `Pominięto duplikaty: ${out.skipped_duplicates||0}`,
      `Zdjęcia rozpoznane w pliku: ${out.images||0}`,
      `Brak kursu NBP dla dat: ${out.nbp_missing||0}`,
      `Błędy wierszy: ${errors.length}`,
      errors.length?'\nPierwszy błąd: '+(errors[0].catalog_no||'')+' — '+(errors[0].message||''):''
    ].join('\n'));
    if(typeof window.loadTools==='function')await window.loadTools(false);
    if(typeof loadToolReport150==='function')await loadToolReport150();
    if(typeof toast==='function')toast(`Excel: dodano ${out.imported||0}, duplikaty ${out.skipped_duplicates||0}`);
  }catch(e){
    const msg=e?.data?.message||e?.message||'Nie udało się zaimportować pliku Excel';
    window.alert('Import Excel nie powiódł się:\n\n'+msg);
    if(typeof toast==='function')toast('Błąd importu Excel');
  }finally{
    if(btn)btn.disabled=false;
    const f=$('importToolExcelFile');if(f)f.value='';
  }
}
function init(){
  const btn=$('importToolExcelBtn'),file=$('importToolExcelFile');
  if(!btn||!file||btn.dataset.ready1541)return;
  btn.dataset.ready1541='1';
  btn.addEventListener('click',()=>file.click());
  file.addEventListener('change',()=>runImport(file.files&&file.files[0]));
}
init();
})();
