/* 15.4.7 — small navigation polish; no changes to inventory data or APIs. */
(()=>{
  'use strict';
  const root=document.documentElement,product=document.getElementById('productsPage'),tools=document.getElementById('toolsPage');
  const update=()=>{
    const onTools=tools&&!tools.classList.contains('hidden');
    const onParts=product&&!product.classList.contains('hidden');
    document.body.classList.toggle('view-tools',!!onTools);
    document.body.classList.toggle('view-products',!!onParts);
    const newPart=document.getElementById('newProductTop'),newMove=document.getElementById('newMovementTop');
    if(newPart)newPart.style.display=onTools?'none':'';
    if(newMove)newMove.style.display=onTools?'none':'';
  };
  new MutationObserver(update).observe(document.getElementById('app'),{attributes:true,subtree:true,attributeFilter:['class']});
  update();
})();
