(()=>{
'use strict';

const PAGES=['dashboard','products','movements','documents','alternatives','integrations','b2b','suppliers','locations','contractors','tools','users'];
const MODALS=['productDetailModal','documentModal','productModal','moveModal','toolPreviewModal'];
const raw={page,openProductDetail,openDocument,openProduct,openMovement};
let rowIndex=-1;
let selectedProductId=null;

function isTyping(el){return !!el&&(el.matches?.('input,textarea,select,[contenteditable="true"]')||el.closest?.('[contenteditable="true"]'))}
function currentPage(){for(const p of PAGES){const el=document.getElementById(p+'Page');if(el&&!el.classList.contains('hidden'))return p}return 'dashboard'}
function topModal(){for(let i=MODALS.length-1;i>=0;i--){const el=document.getElementById(MODALS[i]);if(el?.classList.contains('show'))return el}return null}
function productRows(){return [...document.querySelectorAll('#productsBody tr[data-product-row]')]}
function rowByProductId(id){return productRows().find(r=>+r.dataset.productRow===+id)||null}
function selectedRow(){const rows=productRows();if(selectedProductId){const r=rowByProductId(selectedProductId);if(r)return r}if(rowIndex>=0&&rows[rowIndex])return rows[rowIndex];return rows.find(r=>r.classList.contains('kbd-selected'))||null}
function selectRowAt(index,scroll=true){const rows=productRows();if(!rows.length){rowIndex=-1;selectedProductId=null;return null}rowIndex=Math.max(0,Math.min(rows.length-1,index));rows.forEach(r=>r.classList.remove('kbd-selected'));const row=rows[rowIndex];row.classList.add('kbd-selected');selectedProductId=+row.dataset.productRow||null;if(scroll)row.scrollIntoView({block:'nearest'});return row}
function selectProductId(id,scroll=true){const rows=productRows(),idx=rows.findIndex(r=>+r.dataset.productRow===+id);return idx>=0?selectRowAt(idx,scroll):null}
function ensureSelected(){const rows=productRows();if(!rows.length)return null;if(selectedProductId){const x=selectProductId(selectedProductId,false);if(x)return x}if(rowIndex<0||rowIndex>=rows.length)rowIndex=0;return selectRowAt(rowIndex,false)}
function moveSelection(delta){const rows=productRows();if(!rows.length)return;const current=selectedRow();const idx=current?rows.indexOf(current):Math.max(0,rowIndex);selectRowAt(idx+delta,true)}
function firstSelection(){selectRowAt(0,true)}
function lastSelection(){const rows=productRows();if(rows.length)selectRowAt(rows.length-1,true)}
function toggleSelectedCheckbox(){const r=ensureSelected();const cb=r?.querySelector('.product-select');if(cb){cb.checked=!cb.checked;cb.dispatchEvent(new Event('change',{bubbles:true}))}}
function getControl(id,prop='value'){const el=document.getElementById(id);return el?el[prop]:undefined}
function setControl(id,value,prop='value'){const el=document.getElementById(id);if(el&&value!==undefined&&value!==null)el[prop]=value}
function captureForm(formId){const f=document.getElementById(formId);if(!f)return null;const out={};for(const el of f.querySelectorAll('input,select,textarea')){const k=el.id||el.name;if(!k)continue;out[k]=el.type==='checkbox'?!!el.checked:el.value}return out}
function restoreForm(values){if(!values)return;for(const [id,v] of Object.entries(values)){const el=document.getElementById(id);if(!el)continue;if(el.type==='checkbox')el.checked=!!v;else el.value=v;el.dispatchEvent(new Event('change',{bubbles:true}))}}
function modalDescriptor(){const m=topModal();if(!m)return null;if(m.id==='productDetailModal')return {id:m.id,entity:+(S.detailProduct?.product?.id||0)||null};if(m.id==='documentModal')return {id:m.id,entity:+(S.currentDocument?.document?.id||0)||null,form:captureForm('documentEditPanel')};if(m.id==='productModal')return {id:m.id,entity:+(document.getElementById('productId')?.value||0)||null,form:captureForm('productForm')};if(m.id==='moveModal')return {id:m.id,form:captureForm('moveForm')};return {id:m.id}}
function capture(){
  const wrap=document.querySelector('#productsPage .products-tablewrap');
  const active=document.activeElement;
  return {
    page:currentPage(),
    modal:modalDescriptor(),
    products:{
      q:getControl('productSearch')||'',active:getControl('productActive')||'1',sort:getControl('productSort')||'name',dir:document.getElementById('productSortDir')?.dataset.dir||'asc',low:!!getControl('lowOnly','checked'),selectedProductId:selectedProductId||(+selectedRow()?.dataset.productRow||null),scrollTop:wrap?.scrollTop||0,scrollLeft:wrap?.scrollLeft||0
    },
    docs:{q:getControl('documentSearch')||'',type:getControl('documentType')||''},
    moves:{q:getControl('moveSearch')||'',type:getControl('moveTypeFilter')||''},
    mainScroll:document.querySelector('main')?.scrollTop||window.scrollY||0,
    focusId:active?.id||null
  }
}
function signature(s){return [s?.page||'',s?.modal?.id||'',s?.modal?.entity||''].join('|')}
function labelFor(s){
  if(!s)return '';
  if(s.modal?.id==='productDetailModal')return 'Karta produktu';
  if(s.modal?.id==='productModal')return s.modal.entity?'Edycja części':'Nowa część';
  if(s.modal?.id==='documentModal')return 'Dokument';
  if(s.modal?.id==='moveModal')return 'Ruch magazynowy';
  return ({dashboard:'Dashboard',products:'Kartoteka',movements:'Ruchy',documents:'Dokumenty',alternatives:'Zamienniki / IC',integrations:'Sklep / WooCommerce',b2b:'Mercedes B2B',suppliers:'Dostawcy',locations:'Lokalizacje',contractors:'Kontrahenci'})[s.page]||s.page;
}

const Nav={
  entries:[],index:-1,restoring:false,
  init(){this.entries=[capture()];this.index=0;this.updateUi()},
  sync(){if(this.index<0)return;const now=capture(),cur=this.entries[this.index];if(signature(now)===signature(cur))this.entries[this.index]=now},
  async transition(fn){if(this.restoring)return await fn();this.sync();const before=this.entries[this.index];const out=await fn();await Promise.resolve();const after=capture();if(signature(after)!==signature(before)){
      this.entries=this.entries.slice(0,this.index+1);this.entries.push(after);this.index=this.entries.length-1;
    }else this.entries[this.index]=after;
    this.updateUi();return out
  },
  async back(){if(this.index<=0){this.updateUi();return}this.sync();this.index--;await this.restore(this.entries[this.index]);this.updateUi()},
  async forward(){if(this.index>=this.entries.length-1){this.updateUi();return}this.sync();this.index++;await this.restore(this.entries[this.index]);this.updateUi()},
  async restore(s){if(!s)return;this.restoring=true;try{
      document.querySelectorAll('.modal.show').forEach(m=>m.classList.remove('show'));
      setControl('productSearch',s.products?.q||'');setControl('productActive',s.products?.active||'1');setControl('productSort',s.products?.sort||'name');if(document.getElementById('productSortDir'))document.getElementById('productSortDir').dataset.dir=s.products?.dir||'asc';setControl('lowOnly',!!s.products?.low,'checked');
      setControl('documentSearch',s.docs?.q||'');setControl('documentType',s.docs?.type||'');setControl('moveSearch',s.moves?.q||'');setControl('moveTypeFilter',s.moves?.type||'');
      page(s.page||'dashboard');
      if(s.page==='products'&&typeof loadProducts==='function')await loadProducts();
      else if(s.page==='documents'&&typeof loadDocuments==='function')await loadDocuments();
      else if(s.page==='movements'&&typeof loadMovements==='function')await loadMovements();
      await new Promise(r=>setTimeout(r,40));
      if(s.modal?.id==='productDetailModal'&&s.modal.entity)await openProductDetail(s.modal.entity);
      else if(s.modal?.id==='documentModal'&&s.modal.entity){await openDocument(s.modal.entity);restoreForm(s.modal.form)}
      else if(s.modal?.id==='productModal'){openProduct(s.modal.entity||null);restoreForm(s.modal.form)}
      else if(s.modal?.id==='moveModal'){openMovement();restoreForm(s.modal.form);if(typeof updateStockHint==='function')updateStockHint()}
      await new Promise(r=>setTimeout(r,35));
      selectedProductId=s.products?.selectedProductId||null;if(selectedProductId)selectProductId(selectedProductId,false);
      const wrap=document.querySelector('#productsPage .products-tablewrap');if(wrap){wrap.scrollTop=s.products?.scrollTop||0;wrap.scrollLeft=s.products?.scrollLeft||0}
      const main=document.querySelector('main');if(main)main.scrollTop=s.mainScroll||0;else window.scrollTo(0,s.mainScroll||0);
      if(s.focusId){const el=document.getElementById(s.focusId);if(el&&el.offsetParent!==null)el.focus({preventScroll:true})}
    }finally{this.restoring=false}},
  updateUi(){const b=document.getElementById('kbdNavBack'),f=document.getElementById('kbdNavForward'),l=document.getElementById('kbdNavLabel');if(b){b.disabled=this.index<=0;b.title=this.index>0?'Wstecz: '+labelFor(this.entries[this.index-1])+' (Alt+←)':'Brak wcześniejszego widoku'}if(f){f.disabled=this.index>=this.entries.length-1;f.title=this.index<this.entries.length-1?'Dalej: '+labelFor(this.entries[this.index+1])+' (Alt+→)':'Brak następnego widoku'}if(l)l.textContent=labelFor(this.entries[this.index])}
};
window.MBNav=Nav;

// Owijamy istniejącą nawigację — logika aplikacji pozostaje bez zmian.
page=function(p){return Nav.transition(()=>raw.page(p))};
openProductDetail=function(id){return Nav.transition(()=>raw.openProductDetail(id))};
openDocument=function(id){return Nav.transition(()=>raw.openDocument(id))};
openProduct=function(id=null){return Nav.transition(()=>raw.openProduct(id))};
openMovement=function(){return Nav.transition(()=>raw.openMovement())};

function injectNavButtons(){const actions=document.querySelector('main>header .actions');if(!actions||document.getElementById('kbdNavBack'))return;const box=document.createElement('div');box.className='history-nav';box.innerHTML='<button type="button" class="btn history-btn" id="kbdNavBack" aria-label="Wstecz">←</button><button type="button" class="btn history-btn" id="kbdNavForward" aria-label="Dalej">→</button><span id="kbdNavLabel" class="history-label"></span>';actions.prepend(box);document.getElementById('kbdNavBack').onclick=()=>Nav.back();document.getElementById('kbdNavForward').onclick=()=>Nav.forward()}

function quickMove(type){openMovement().then?.(()=>{});setTimeout(()=>{setControl('move_type',type);const r=ensureSelected();if(r){setControl('move_product_id',r.dataset.productRow);if(typeof updateStockHint==='function')updateStockHint();document.getElementById('quantity')?.focus()}else document.getElementById('move_product_id')?.focus()},40)}
function editSelected(){const r=ensureSelected();if(r)openProduct(+r.dataset.productRow);else{page('products');setTimeout(()=>document.getElementById('productSearch')?.focus(),50)}}
function openSelected(){const r=ensureSelected();if(r)openProductDetail(+r.dataset.productRow)}
function deleteSelection(){let checked=[...document.querySelectorAll('.product-select:checked')];if(!checked.length){const r=ensureSelected(),cb=r?.querySelector('.product-select');if(cb){cb.checked=true;cb.dispatchEvent(new Event('change',{bubbles:true}));checked=[cb]}}if(checked.length)document.getElementById('deleteSelectedProducts')?.click()}
function selectAllVisible(){const all=[...document.querySelectorAll('.product-select')];all.forEach(x=>x.checked=true);all.forEach(x=>x.dispatchEvent(new Event('change',{bubbles:true})))}
function visibleForm(){const modal=topModal();if(modal)return modal.querySelector('form');const page=document.getElementById(currentPage()+'Page');return page?.querySelector('form:not(.hidden)')||null}
function saveCurrent(){const f=visibleForm();if(f){f.requestSubmit();return true}if(topModal()?.id==='documentModal'){document.getElementById('saveDocumentEdit')?.click();return true}return false}
function closeOrBack(){const m=topModal();if(!m)return false;if(m.id==='toolPreviewModal'){m.classList.remove('show');return true}if(m.id==='productDetailModal'){m.classList.remove('show');if(Nav.index>=0)Nav.entries[Nav.index]=capture();Nav.updateUi();return true}if(Nav.index>0){Nav.back();return true}m.classList.remove('show');return true}

function showHelp(){let b=document.getElementById('kbdHelp');if(!b){b=document.createElement('div');b.id='kbdHelp';b.className='kbd-help';b.innerHTML=`<div class="kbd-help-card"><div class="kbd-help-head"><div><h3>Sterowanie klawiaturą</h3><p>MB Auto Serwis · tryb szybkiej obsługi magazynu</p></div><button type="button" class="x" id="kbdHelpClose">×</button></div><div class="kbd-help-grid"><div><kbd>Alt</kbd>+<kbd>←</kbd><span>Poprzedni widok / okno</span></div><div><kbd>Alt</kbd>+<kbd>→</kbd><span>Następny widok / okno</span></div><div><kbd>Esc</kbd><span>Zamknij bieżące okno / wróć</span></div><div><kbd>↑</kbd> <kbd>↓</kbd><span>Wybór towaru</span></div><div><kbd>PgUp</kbd> <kbd>PgDn</kbd><span>Skok o 10 pozycji</span></div><div><kbd>Home</kbd> <kbd>End</kbd><span>Pierwsza / ostatnia pozycja</span></div><div><kbd>Enter</kbd><span>Otwórz kartę towaru</span></div><div><kbd>Spacja</kbd><span>Zaznacz / odznacz towar</span></div><div><kbd>Insert</kbd><span>Nowa część</span></div><div><kbd>F2</kbd><span>Edytuj wybraną część / otwórz kartotekę</span></div><div><kbd>Delete</kbd><span>Usuń zaznaczone (z potwierdzeniem)</span></div><div><kbd>Ctrl</kbd>+<kbd>A</kbd><span>Zaznacz wszystkie widoczne</span></div><div><kbd>Ctrl</kbd>+<kbd>F</kbd><span>Szukaj / skaner</span></div><div><kbd>F4</kbd><span>Szybkie PZ</span></div><div><kbd>F5</kbd><span>Szybkie RW</span></div><div><kbd>F6</kbd><span>Szybkie WZ</span></div><div><kbd>F7</kbd><span>Dokumenty</span></div><div><kbd>F8</kbd><span>Kontrahenci</span></div><div><kbd>F9</kbd><span>Zamienniki / Inter Cars</span></div><div><kbd>F10</kbd><span>Mercedes B2B</span></div><div><kbd>Ctrl</kbd>+<kbd>S</kbd><span>Zapisz bieżący formularz</span></div><div><kbd>Ctrl</kbd>+<kbd>P</kbd><span>Drukuj otwarty dokument</span></div><div><kbd>Ctrl</kbd>+<kbd>B</kbd><span>Kopia bazy</span></div><div><kbd>Ctrl</kbd>+<kbd>E</kbd><span>Eksport CSV</span></div><div><kbd>F1</kbd><span>Ta pomoc</span></div></div></div>`;document.body.appendChild(b);b.addEventListener('click',e=>{if(e.target===b||e.target.id==='kbdHelpClose')b.classList.remove('show')})}b.classList.add('show')}

// Kliknięcie X/Anuluj w modalu zachowuje semantykę „wstecz”.
document.addEventListener('click',e=>{const c=e.target.closest?.('[data-close]');if(!c)return;const m=document.getElementById(c.dataset.close);if(!m?.classList.contains('show'))return;if(m.id==='toolPreviewModal'){e.preventDefault();e.stopImmediatePropagation();m.classList.remove('show');return}if(m.id==='productDetailModal'){e.preventDefault();e.stopImmediatePropagation();m.classList.remove('show');if(Nav.index>=0)Nav.entries[Nav.index]=capture();Nav.updateUi();return}if(Nav.index>0){e.preventDefault();e.stopImmediatePropagation();Nav.back()}},true);

// Po przeładowaniu tabeli zachowujemy wybór klawiaturowy.
const body=document.getElementById('productsBody');if(body&&window.MutationObserver)new MutationObserver(()=>{if(selectedProductId)selectProductId(selectedProductId,false);else rowIndex=-1}).observe(body,{childList:true});
document.addEventListener('click',e=>{const r=e.target.closest?.('#productsBody tr[data-product-row]');if(r&&!e.target.closest('button,input,a')){const rows=productRows();selectRowAt(rows.indexOf(r),false)}});

function keyHandler(e){
  const key=e.key,lower=String(key).toLowerCase();
  if(e.altKey&&key==='ArrowLeft'){e.preventDefault();e.stopPropagation();Nav.back();return}
  if(e.altKey&&key==='ArrowRight'){e.preventDefault();e.stopPropagation();Nav.forward();return}
  if(key==='F1'){e.preventDefault();showHelp();return}
  if(key==='Escape'){if(document.getElementById('kbdHelp')?.classList.contains('show')){e.preventDefault();document.getElementById('kbdHelp').classList.remove('show');return}if(closeOrBack()){e.preventDefault();return}}
  if((e.ctrlKey||e.metaKey)&&lower==='s'){if(saveCurrent()){e.preventDefault();return}}
  if((e.ctrlKey||e.metaKey)&&lower==='p'&&document.getElementById('documentModal')?.classList.contains('show')){e.preventDefault();document.getElementById('printDocument')?.click();return}
  if((e.ctrlKey||e.metaKey)&&lower==='f'){e.preventDefault();page('products');setTimeout(()=>{const x=document.getElementById('productSearch');x?.focus();x?.select?.()},60);return}
  if((e.ctrlKey||e.metaKey)&&lower==='b'){e.preventDefault();document.getElementById('backupSide')?.click();return}
  if((e.ctrlKey||e.metaKey)&&lower==='e'){e.preventDefault();document.getElementById('exportBtn')?.click();return}
  if(isTyping(document.activeElement))return;
  if((e.ctrlKey||e.metaKey)&&lower==='a'&&currentPage()==='products'){e.preventDefault();selectAllVisible();return}
  if(key==='Insert'||((e.ctrlKey||e.metaKey)&&lower==='n')){e.preventDefault();openProduct();return}
  if(key==='F2'){e.preventDefault();editSelected();return}
  if(key==='F4'){e.preventDefault();quickMove('PZ');return}
  if(key==='F5'){e.preventDefault();quickMove('RW');return}
  if(key==='F6'){e.preventDefault();quickMove('WZ');return}
  if(key==='F7'){e.preventDefault();page('documents');return}
  if(key==='F8'){e.preventDefault();page('contractors');return}
  if(key==='F9'){e.preventDefault();page('alternatives');return}
  if(key==='F10'){e.preventDefault();page('b2b');return}
  if((e.ctrlKey||e.metaKey)&&lower==='m'){e.preventDefault();openMovement();return}
  if(currentPage()==='products'&&!topModal()){
    if(key==='ArrowDown'){e.preventDefault();moveSelection(1);return}
    if(key==='ArrowUp'){e.preventDefault();moveSelection(-1);return}
    if(key==='PageDown'){e.preventDefault();moveSelection(10);return}
    if(key==='PageUp'){e.preventDefault();moveSelection(-10);return}
    if(key==='Home'){e.preventDefault();firstSelection();return}
    if(key==='End'){e.preventDefault();lastSelection();return}
    if(key==='Enter'){const r=ensureSelected();if(r){e.preventDefault();openSelected()}return}
    if(key===' '){const r=ensureSelected();if(r){e.preventDefault();toggleSelectedCheckbox()}return}
    if(key==='Delete'){const r=ensureSelected();if(r){e.preventDefault();deleteSelection()}return}
    // Pisanie bez Ctrl na kartotece od razu przenosi do wyszukiwarki.
    if(key.length===1&&!e.ctrlKey&&!e.metaKey&&!e.altKey){const q=document.getElementById('productSearch');if(q){e.preventDefault();q.focus();q.value+=key;q.dispatchEvent(new Event('input',{bubbles:true}))}}
  }
}
document.addEventListener('keydown',keyHandler,true);

function injectStrip(){if(document.querySelector('.kbd-strip'))document.querySelector('.kbd-strip').remove();const h=document.createElement('div');h.className='kbd-strip';h.innerHTML='Klawiatura: <kbd>Alt+←</kbd> wstecz · <kbd>Alt+→</kbd> dalej · <kbd>↑/↓</kbd> wybór · <kbd>Enter</kbd> otwórz · <kbd>F4/F5/F6</kbd> PZ/RW/WZ · <kbd>F1</kbd> skróty';document.body.appendChild(h)}

injectNavButtons();injectStrip();Nav.init();
})();
