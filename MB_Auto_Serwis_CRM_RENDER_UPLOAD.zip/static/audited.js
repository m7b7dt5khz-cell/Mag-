(()=>{
'use strict';
const byId=id=>document.getElementById(id);
const norm=s=>String(s??'').toUpperCase().replace(/[\s.\-_/]+/g,'');
const state={page:1,perPage:100,selected:new Set(),tools:[],toolImage:'',diagram:null};

// Wydruk wewnątrz okna CRM. Nie używamy window.open(), bo w pywebview/Windows
// może on uruchamiać zewnętrzny handler (np. Microsoft Store) zamiast podglądu wydruku.
window.mbasPrintHtml=function({title='MB Auto Serwis',html='',css='',page='A4 portrait',margin='12mm'}={}){
  const oldHost=document.getElementById('mbasNativePrintHost');if(oldHost)oldHost.remove();
  const oldStyle=document.getElementById('mbasNativePrintStyle');if(oldStyle)oldStyle.remove();
  const host=document.createElement('div');host.id='mbasNativePrintHost';host.setAttribute('aria-hidden','true');host.innerHTML=html;document.body.appendChild(host);
  const style=document.createElement('style');style.id='mbasNativePrintStyle';style.textContent=`#mbasNativePrintHost{display:none!important}@media print{@page{size:${page};margin:${margin}}html,body{background:#fff!important;height:auto!important;min-height:0!important;overflow:visible!important}body.mbas-native-print{margin:0!important;padding:0!important;background:#fff!important;height:auto!important;min-height:0!important;overflow:visible!important}body.mbas-native-print> *:not(#mbasNativePrintHost){display:none!important}body.mbas-native-print #mbasNativePrintHost{display:block!important;position:static!important;left:auto!important;top:auto!important;width:100%!important;height:auto!important;min-height:0!important;max-height:none!important;margin:0!important;padding:0!important;background:#fff!important;color:#111!important;overflow:visible!important;z-index:auto!important}body.mbas-native-print #mbasNativePrintHost,body.mbas-native-print #mbasNativePrintHost *{visibility:visible!important;box-sizing:border-box}${css}}`;
  document.head.appendChild(style);
  const oldTitle=document.title;document.title=title;document.body.classList.add('mbas-native-print');
  let cleaned=false;
  let fallbackTimer=null;
  const media=window.matchMedia?window.matchMedia('print'):null;
  const cleanup=()=>{
    if(cleaned)return;
    cleaned=true;
    if(fallbackTimer)clearTimeout(fallbackTimer);
    document.body.classList.remove('mbas-native-print');
    document.title=oldTitle;
    try{host.remove()}catch(_e){}
    try{style.remove()}catch(_e){}
    window.removeEventListener('afterprint',cleanup);
    if(media){try{media.removeEventListener('change',onPrintMediaChange)}catch(_e){try{media.removeListener(onPrintMediaChange)}catch(__e){}}}
  };
  const onPrintMediaChange=e=>{if(!e.matches)cleanup()};
  window.addEventListener('afterprint',cleanup,{once:true});
  if(media){try{media.addEventListener('change',onPrintMediaChange)}catch(_e){try{media.addListener(onPrintMediaChange)}catch(__e){}}}
  // WebView2 otwiera podgląd drukowania asynchronicznie. Nie wolno usuwać
  // zawartości po kilkuset ms, bo podgląd może jeszcze jej nie przejąć.
  // Awaryjne sprzątanie dopiero po 5 minutach, gdyby silnik nie wysłał afterprint.
  fallbackTimer=setTimeout(cleanup,5*60*1000);
  try{
    requestAnimationFrame(()=>requestAnimationFrame(()=>setTimeout(()=>{
      try{window.print()}catch(e){cleanup();throw e}
    },120)));
  }catch(e){cleanup();throw e}
};

window.mbasPrintIsolated=function({title='MB Auto Serwis',html='',css='',page='A4 portrait',margin='10mm'}={}){
  const old=document.getElementById('mbasPrintIsolatedFrame');if(old)old.remove();
  const frame=document.createElement('iframe');
  frame.id='mbasPrintIsolatedFrame';
  frame.setAttribute('aria-hidden','true');
  frame.style.cssText='position:fixed;left:-12000px;top:0;width:210mm;height:297mm;border:0;opacity:0;pointer-events:none;background:white;';
  document.body.appendChild(frame);
  const doc=frame.contentDocument||frame.contentWindow.document;
  const safeTitle=String(title||'MB Auto Serwis').replace(/[<>&"']/g,'');
  doc.open();
  doc.write(`<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${safeTitle}</title><style>@page{size:${page};margin:${margin}}html,body{margin:0!important;padding:0!important;background:#fff!important;color:#111!important;height:auto!important;min-height:0!important;overflow:visible!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}*{box-sizing:border-box}#printRoot{width:100%;margin:0;padding:0}${css}</style></head><body><main id="printRoot">${html}</main></body></html>`);
  doc.close();
  let cleaned=false, fallbackTimer=null;
  const cleanup=()=>{if(cleaned)return;cleaned=true;if(fallbackTimer)clearTimeout(fallbackTimer);try{frame.remove()}catch(_e){}};
  const w=frame.contentWindow;
  try{w.addEventListener('afterprint',cleanup,{once:true})}catch(_e){}
  const media=(()=>{try{return w.matchMedia('print')}catch(_e){return null}})();
  const onMedia=e=>{if(!e.matches)cleanup()};
  if(media){try{media.addEventListener('change',onMedia)}catch(_e){try{media.addListener(onMedia)}catch(__e){}}}
  fallbackTimer=setTimeout(cleanup,5*60*1000);
  const imgs=[...doc.images];
  const ready=imgs.length?Promise.all(imgs.map(img=>img.complete?Promise.resolve():new Promise(r=>{img.onload=img.onerror=r}))):Promise.resolve();
  ready.then(()=>setTimeout(()=>{try{w.focus();w.print()}catch(e){cleanup();throw e}},80));
};

function setVisiblePage(name){
  const pages=['dashboard','products','movements','documents','alternatives','b2b','suppliers','locations','contractors','tools','integrations'];
  pages.forEach(x=>{const el=byId(x+'Page');if(el)el.classList.toggle('hidden',x!==name)});
  document.querySelectorAll('nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===name));
  const titles={dashboard:'Dashboard magazynu',products:'Kartoteka części',movements:'Ruchy magazynowe',documents:'Dokumenty magazynowe',alternatives:'Zamienniki Mercedes',b2b:'Mercedes B2B',suppliers:'Dostawcy',locations:'Lokalizacje',contractors:'Kontrahenci / NIP',tools:'Kartoteka narzędzi',integrations:'Sklep / WooCommerce'};
  if(byId('title'))byId('title').textContent=titles[name]||'MB Auto Serwis';
  if(name==='products')loadProductsAudited(false);
  else if(name==='dashboard')loadSummaryAudited();
  else if(name==='tools')loadTools();
  else if(name==='movements')loadMovements?.();
  else if(name==='documents')loadDocuments?.();
  else if(name==='alternatives'){refreshAltProductSelects?.();if(byId('altBaseProduct')?.value)loadAlternatives?.()}
  else if(name==='b2b'){loadB2bSettings?.();loadB2bCaptures?.()}
  else if(name==='integrations'){loadIntegrationSettings?.();loadIntegrationIssues?.();window.loadShopBeta1534?.()}
  else if(name==='contractors')loadContractors?.();
}
page=setVisiblePage;
document.querySelectorAll('nav [data-page]').forEach(b=>b.onclick=()=>page(b.dataset.page));

function sortLabel(){const b=byId('productSortDir'),k=byId('productSort')?.value||'name',d=b?.dataset.dir||'asc';if(!b)return;const num=['stock','purchase','catalog','created'].includes(k);b.textContent=num?(d==='asc'?'0 → 9':'9 → 0'):(d==='asc'?'A → Z':'Z → A')}
function statusHtml(p){const c=String(p.mb_status_code||'UNKNOWN').toUpperCase();const m={DEALER:['dealer','✓','dealer'],CENTRAL:['central','','centralny'],GERMANY:['germany','','Niemcy'],UNAVAILABLE:['unavailable','','brak'],UNKNOWN:['unknown','','—'],ERROR:['unknown','','—']}[c]||['unknown','','—'];return `<span class="mb-list-status ${m[0]}"><i>${m[1]}</i>${m[2]}</span>`}
function productRow(p,q){
  const nq=norm(q),vals=[p.sku,p.oem_no,p.barcode,...String(p.aliases||'').split(',')].map(norm),exact=!!nq&&vals.includes(nq),hit=!!q;
  const low=+p.min_qty>0&&+p.stock_qty<+p.min_qty;
  const aliases=String(p.aliases||'').split(',').map(x=>x.trim()).filter(Boolean);
  const aliasVisible=aliases.slice(0,2);
  const aliasHtml=aliases.length?`<div class="related-codes" title="Kliknij numer, aby skopiować">${aliasVisible.map(x=>`<button type="button" class="related-code-btn" data-copy-code="${esc(x)}" title="Kopiuj ${esc(x)}">${esc(x)}</button>`).join('')}${aliases.length>2?`<span class="related-more">+${aliases.length-2}</span>`:''}</div>`:'';
  const source=String(p.category||'').trim();
  const gross=(S.priceMode||'net')==='gross',vat=Number(p.vat_rate ?? 23)||0;
  const buyDisplay=(Number(p.purchase_price)||0)*(gross?(1+vat/100):1);
  const catalogDisplay=(Number(p.sale_price)||0)*(gross?(1+vat/100):1);
  const priceLabel=gross?'brutto':'netto';
  return `<tr data-product-row="${p.id}" class="${p.active?'':'archived-row'} ${hit?'search-hit':''} ${exact?'search-exact':''}">
    <td class="cell-select"><input type="checkbox" class="product-select" value="${p.id}" ${state.selected.has(+p.id)?'checked':''}></td>
    <td class="cell-sku">${p.sku?`<button class="code-copy" data-copy-code="${esc(p.sku)}">${esc(p.sku)}</button>`:'<span class="cell-empty">—</span>'}</td>
    <td class="cell-oem">${p.oem_no?`<button class="code-copy primary-code" data-copy-code="${esc(p.oem_no)}">${esc(p.oem_no)}</button>`:'<span class="cell-empty">—</span>'}${aliasHtml}</td>
    <td class="cell-name"><span class="product-name-main">${esc(p.name)}</span>${source?`<span class="product-source">${esc(source)}</span>`:''}</td>
    <td class="cell-location">${esc(p.location_code||'—')}</td>
    <td class="cell-stock ${low?'low':'ok'}"><span class="stock-number">${(+p.stock_qty).toFixed(2)}</span><span class="stock-unit">${esc(p.unit)}</span></td>
    <td class="cell-min">${(+p.min_qty).toFixed(2)}</td>
    <td class="cell-b2b">${statusHtml(p)}</td>
    <td class="cell-price purchase"><b>${money(buyDisplay)}</b><small>${priceLabel}${gross?` · VAT ${vat.toFixed(1)}%`:``}</small></td>
    <td class="cell-price sale"><b>${money(catalogDisplay)}</b><small>${priceLabel}${gross?` · VAT ${vat.toFixed(1)}%`:``}</small></td>
    <td class="cell-supplier">${esc(p.supplier_name||'—')}</td>
    <td class="row-actions"><button class="btn mini open-row" data-open-product="${p.id}">Otwórz</button><button class="btn mini edit-row" data-edit="${p.id}">Edytuj</button></td>
  </tr>`
}
function selectionUi(){const visible=[...document.querySelectorAll('.product-select')];const selectedVisible=visible.filter(x=>state.selected.has(+x.value));if(byId('selectedProductsCount'))byId('selectedProductsCount').textContent=`${state.selected.size} zaznaczonych`;if(byId('deleteSelectedProducts'))byId('deleteSelectedProducts').disabled=state.selected.size===0;if(byId('exportSelectedB2b'))byId('exportSelectedB2b').disabled=state.selected.size===0;const all=byId('selectAllProducts');if(all){all.checked=visible.length>0&&selectedVisible.length===visible.length;all.indeterminate=selectedVisible.length>0&&selectedVisible.length<visible.length}}
function bindRows(q){document.querySelectorAll('.product-select').forEach(x=>x.onchange=()=>{const id=+x.value;x.checked?state.selected.add(id):state.selected.delete(id);selectionUi()});document.querySelectorAll('[data-copy-code]').forEach(b=>b.onclick=e=>{e.stopPropagation();copyCode(b.dataset.copyCode)});document.querySelectorAll('[data-open-product]').forEach(b=>b.onclick=e=>{e.stopPropagation();openProductDetail(+b.dataset.openProduct)});document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=e=>{e.stopPropagation();openProduct(+b.dataset.edit)});document.querySelectorAll('[data-product-row]').forEach(r=>r.ondblclick=e=>{if(!e.target.closest('button,input'))openProductDetail(+r.dataset.productRow)});selectionUi();if(q)requestAnimationFrame(()=>{(document.querySelector('#productsBody .search-exact')||document.querySelector('#productsBody .search-hit'))?.scrollIntoView({block:'center'})})}
function renderPage(){const total=S.products?.length||0,pages=Math.max(1,Math.ceil(total/state.perPage));state.page=Math.max(1,Math.min(state.page,pages));const start=(state.page-1)*state.perPage,rows=(S.products||[]).slice(start,start+state.perPage);byId('productsBody').innerHTML=rows.map(p=>productRow(p,byId('productSearch')?.value||'')).join('');if(byId('productPageInfo'))byId('productPageInfo').textContent=`Strona ${state.page} z ${pages} · ${total} pozycji${total?` · ${start+1}–${Math.min(total,start+state.perPage)}`:''}`;if(byId('productPrevPage'))byId('productPrevPage').disabled=state.page<=1;if(byId('productNextPage'))byId('productNextPage').disabled=state.page>=pages;bindRows(byId('productSearch')?.value||'');return rows}
async function loadProductsAudited(reset=true){if(reset){state.page=1;state.selected.clear()}const q=encodeURIComponent(byId('productSearch')?.value||''),low=byId('lowOnly')?.checked?'1':'',active=byId('productActive')?.value||'1',sort=byId('productSort')?.value||'name',dir=byId('productSortDir')?.dataset.dir||'asc';let serverSort=sort;if((S.priceMode||'net')==='gross'&&sort==='purchase')serverSort='purchase_gross';if((S.priceMode||'net')==='gross'&&sort==='catalog')serverSort='catalog_gross';const d=await api(`/api/products?q=${q}&low=${low}&active=${encodeURIComponent(active)}&sort=${serverSort}&dir=${dir}`);S.products=d.products||[];if(byId('productsLabel'))byId('productsLabel').textContent=`${S.products.length} indeksów`;renderPage();refreshMoveProducts?.();refreshAltProductSelects?.();sortLabel()}
loadProducts=loadProductsAudited;loadProductsSorted=loadProductsAudited;

function bindProductControls(){
  if(byId('productSearch'))byId('productSearch').oninput=()=>{clearTimeout(window.__auditSearch);window.__auditSearch=setTimeout(()=>loadProductsAudited(true),140)};
  if(byId('productActive'))byId('productActive').onchange=()=>loadProductsAudited(true);
  if(byId('lowOnly'))byId('lowOnly').onchange=()=>loadProductsAudited(true);
  if(byId('productSort'))byId('productSort').onchange=()=>loadProductsAudited(true);
  if(byId('productSortDir'))byId('productSortDir').onclick=()=>{const b=byId('productSortDir');b.dataset.dir=b.dataset.dir==='desc'?'asc':'desc';sortLabel();loadProductsAudited(true)};
  document.querySelectorAll('[data-sort-key]').forEach(b=>b.onclick=()=>{const k=b.dataset.sortKey;if(byId('productSort').value===k)byId('productSortDir').dataset.dir=byId('productSortDir').dataset.dir==='asc'?'desc':'asc';else{byId('productSort').value=k;byId('productSortDir').dataset.dir='asc'};loadProductsAudited(true)});
  if(byId('productPerPage')){state.perPage=+byId('productPerPage').value||100;byId('productPerPage').onchange=()=>{state.perPage=+byId('productPerPage').value||100;state.page=1;renderPage()}};
  if(byId('productPrevPage'))byId('productPrevPage').onclick=()=>{if(state.page>1){state.page--;renderPage()}};
  if(byId('productNextPage'))byId('productNextPage').onclick=()=>{const pages=Math.max(1,Math.ceil((S.products?.length||0)/state.perPage));if(state.page<pages){state.page++;renderPage()}};
  if(byId('selectAllProducts'))byId('selectAllProducts').onchange=e=>{document.querySelectorAll('.product-select').forEach(x=>{x.checked=e.target.checked;e.target.checked?state.selected.add(+x.value):state.selected.delete(+x.value)});selectionUi()};
  if(byId('selectAllVisibleProducts'))byId('selectAllVisibleProducts').onclick=()=>{document.querySelectorAll('.product-select').forEach(x=>{x.checked=true;state.selected.add(+x.value)});selectionUi()};
  if(byId('selectAllResultsProducts'))byId('selectAllResultsProducts').onclick=()=>{(S.products||[]).forEach(p=>state.selected.add(+p.id));renderPage();toast(`Zaznaczono ${state.selected.size} pozycji`)};
  if(byId('clearProductSelection'))byId('clearProductSelection').onclick=()=>{state.selected.clear();renderPage()};
  if(byId('deleteSelectedProducts'))byId('deleteSelectedProducts').onclick=async()=>{const ids=[...state.selected];if(!ids.length)return;if(!confirm(`Trwale usunąć ${ids.length} zaznaczonych pozycji?\nPrzed usunięciem zostanie wykonana kopia bazy.`))return;try{const r=await api('/api/products/bulk-delete',{method:'POST',body:JSON.stringify({ids,confirm:'USUN'})});state.selected.clear();toast(`Usunięto ${r.deleted} pozycji · kopia: ${r.backup_filename}`);await Promise.all([loadProductsAudited(true),loadSummaryAudited(),loadMovements?.(),loadDocuments?.()])}catch(e){toast('Nie udało się usunąć zaznaczonych pozycji')}};
  if(byId('exportSelectedB2b'))byId('exportSelectedB2b').onclick=exportB2bFile;
}

async function exportB2bFile(){const ids=[...state.selected];if(!ids.length)return toast('Zaznacz części do eksportu');try{const r=await fetch('/api/b2b/upload-xlsx',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':S.csrf},body:JSON.stringify({ids})});if(!r.ok){const d=await r.json().catch(()=>({}));throw new Error(d.error||'Błąd eksportu')}const blob=await r.blob(),a=document.createElement('a');a.href=URL.createObjectURL(blob);const cd=r.headers.get('Content-Disposition')||'',m=cd.match(/filename="?([^";]+)"?/);a.download=m?.[1]||'B2BConnectUpload.xlsx';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1500);toast(`Plik B2B utworzony: ${ids.length} pozycji`)}catch(e){toast('Nie udało się utworzyć pliku B2B')}}

async function loadSummaryAudited(){const d=await api('/api/summary');byId('kProducts').textContent=d.kpi.products_count;byId('kQty').textContent=(+d.kpi.qty_total).toFixed(2);byId('kPurchase').textContent=money(d.kpi.purchase_value);byId('kLow').textContent=d.kpi.low_count;byId('lowBody').innerHTML=d.low.length?d.low.map(p=>`<tr class="dashboard-product-row" data-low-product="${p.id}" tabindex="0"><td><button class="code-copy" data-copy-code="${esc(p.oem_no||p.sku||'')}">${esc(p.sku||p.oem_no||'—')}</button></td><td><b>${esc(p.name)}</b></td><td class="low">${(+p.stock_qty).toFixed(2)}</td><td>${(+p.min_qty).toFixed(2)}</td><td>${esc(p.location_code||'—')}</td></tr>`).join(''):'<tr><td colspan="5">Brak towarów wymagających zamówienia.</td></tr>';byId('monthMoves').innerHTML=d.month.length?d.month.map(x=>`<div class="moveitem"><b>${esc(x.move_type)}</b><span>${x.cnt} dokumentów · ${money(x.value)}</span></div>`).join(''):'<div class="hint">Brak ruchów w tym miesiącu.</div>';document.querySelectorAll('[data-low-product]').forEach(r=>{const open=()=>openProductDetail(+r.dataset.lowProduct);r.onclick=e=>{if(!e.target.closest('button'))open()};r.onkeydown=e=>{if(e.key==='Enter')open()}});document.querySelectorAll('#lowBody [data-copy-code]').forEach(b=>b.onclick=e=>{e.stopPropagation();copyCode(b.dataset.copyCode)})}
loadSummary=loadSummaryAudited;
if(byId('lowStockCard'))byId('lowStockCard').onclick=()=>{page('products');byId('lowOnly').checked=true;loadProductsAudited(true)};

// RESET — jeden handler, bez prompt() i bez starych nakładek.
if(byId('clearDatabaseBtn'))byId('clearDatabaseBtn').onclick=()=>{byId('databaseResetPhrase').value='';byId('databaseResetModal').classList.add('show');setTimeout(()=>byId('databaseResetPhrase').focus(),40)};
if(byId('databaseResetConfirm'))byId('databaseResetConfirm').onclick=async()=>{const phrase=byId('databaseResetPhrase').value.trim();if(phrase!=='WYCZYSC BAZE')return toast('Wpisz dokładnie: WYCZYSC BAZE');const b=byId('databaseResetConfirm');b.disabled=true;try{const r=await api('/api/database/reset',{method:'POST',body:JSON.stringify({confirm:phrase})});byId('databaseResetModal').classList.remove('show');state.selected.clear();S.products=[];toast(`Baza wyczyszczona · kopia: ${r.backup_filename}`);await Promise.all([loadSuppliers(),loadLocations(),loadContractors(),loadProductsAudited(true),loadMovements(),loadDocuments(),loadSummaryAudited(),loadTools()]);page('dashboard')}catch(e){toast(`Reset nieudany: ${e.code||e.message||'błąd'}`)}finally{b.disabled=false}};

// NARZĘDZIA
function toolOptions(){if(byId('toolLocation'))byId('toolLocation').innerHTML='<option value="">— brak —</option>'+S.locations.map(x=>`<option value="${x.id}">${esc(x.code)} · ${esc(x.name||'')}</option>`).join('');if(byId('toolSupplier'))byId('toolSupplier').innerHTML='<option value="">— brak —</option>'+S.suppliers.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}
function eurCalc(){const eur=+byId('toolPriceEur')?.value||0,rate=+byId('toolEurRate')?.value||0;const pln=eur>0&&rate>0?eur*rate:+byId('toolPricePln')?.value||0;if(byId('toolCalculatedPln'))byId('toolCalculatedPln').value=pln?pln.toFixed(2):''}
function toolQtyText(v){const n=Number(v);if(!Number.isFinite(n))return '1';return Number.isInteger(n)?String(n):n.toLocaleString('pl-PL',{maximumFractionDigits:2})}
function euroMoney(v){const n=Number(v)||0;return n.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2})+' €'}
function renderToolsPage(){
  if(!byId('toolsGrid'))return;
  const tools=state.tools||[];
  const per=Math.max(1,Number(state.toolPerPage||byId('toolPerPage')?.value||50));
  const pages=Math.max(1,Math.ceil(tools.length/per));
  state.toolPage=Math.max(1,Math.min(Number(state.toolPage||1),pages));
  state.toolPerPage=per;
  const start=(state.toolPage-1)*per,end=Math.min(tools.length,start+per),visible=tools.slice(start,end);
  const fallbackIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" aria-hidden="true"><path d="M8 7h8l2 3v10H6V10l2-3Zm0 0V5a4 4 0 0 1 8 0v2M6 13h12"/></svg>';
  byId('toolsGrid').innerHTML=visible.length?visible.map(t=>`
    <article class="tool-card" data-tool-id="${Number(t.id)}" tabindex="0" title="Kliknij, aby otworzyć szybki podgląd">
      <div class="tool-photo">${t.image_data?`<img src="${esc(t.image_data)}" alt="${esc(t.name)}" loading="lazy">`:fallbackIcon}</div>
      <div class="tool-card-body">
        <div class="tool-identity"><h4>${esc(t.name)}</h4><p>${esc([t.manufacturer,t.model].filter(Boolean).join(' · ')||t.category||'Wyposażenie warsztatu')}</p><div class="tool-code">${esc(t.catalog_no||'Bez numeru katalogowego')}</div></div>
        <div class="tool-details"><span><b>Lokalizacja</b> ${esc(t.location_code||'—')}</span><span><b>Faktura</b> ${esc(t.invoice_no||'—')}</span><span class="tool-serial"><b>S/N</b> ${esc(t.serial_no||'—')}</span></div>
        <div class="tool-qty"><strong>${toolQtyText(t.quantity??1)}</strong><small>szt.</small></div>
        <div class="tool-cost"><strong>${money(t.purchase_price_pln)}</strong><small>${Number(t.purchase_price_eur)>0?`${euroMoney(t.purchase_price_eur)} / szt. · kurs ${Number(t.eur_rate||0).toFixed(4)}`:'Zakup PLN'}</small></div>
        <div class="tool-meta" aria-hidden="true" hidden><span><b>Nr kat.</b> ${esc(t.catalog_no||'—')}</span></div>
        <div class="tool-actions"><button type="button" class="btn mini" data-tool-preview="${Number(t.id)}">Podgląd</button><button type="button" class="btn mini" data-tool-print="${Number(t.id)}" title="Drukuj kartę tylko tego narzędzia">Drukuj</button><button type="button" class="btn mini" data-tool-edit="${Number(t.id)}">Edytuj</button><button type="button" class="btn mini danger" data-tool-del="${Number(t.id)}" title="Usuń z kartoteki">Usuń</button></div>
      </div>
    </article>`).join(''):'<div class="empty-state tools-empty">Nie znaleziono narzędzi. Zmień filtr lub dodaj nowe narzędzie.</div>';
  if(byId('toolPageInfo'))byId('toolPageInfo').textContent=`Strona ${state.toolPage} z ${pages} · ${tools.length} pozycji${tools.length?` · ${start+1}–${end}`:''}`;
  if(byId('toolPrevPage'))byId('toolPrevPage').disabled=state.toolPage<=1;
  if(byId('toolNextPage'))byId('toolNextPage').disabled=state.toolPage>=pages;
  document.querySelectorAll('[data-tool-preview]').forEach(b=>b.onclick=e=>{e.stopPropagation();openToolPreview(+b.dataset.toolPreview)});
  document.querySelectorAll('[data-tool-print]').forEach(b=>b.onclick=e=>{e.stopPropagation();printToolCard(+b.dataset.toolPrint)});
  document.querySelectorAll('[data-tool-edit]').forEach(b=>b.onclick=e=>{e.stopPropagation();openTool(+b.dataset.toolEdit)});
  document.querySelectorAll('[data-tool-del]').forEach(b=>b.onclick=e=>{e.stopPropagation();deleteTool(+b.dataset.toolDel)});
  document.querySelectorAll('[data-tool-id]').forEach(card=>{
    card.onclick=e=>{if(!e.target.closest('button,input,select,a'))openToolPreview(+card.dataset.toolId)};
    card.onkeydown=e=>{if((e.key==='Enter'||e.key===' ')&&!e.target.closest('button,input,select,a')){e.preventDefault();openToolPreview(+card.dataset.toolId)}};
  });
}
async function loadTools(resetPage=false){
  if(!byId('toolsGrid'))return;
  if(resetPage)state.toolPage=1;
  const q=encodeURIComponent(byId('toolSearch')?.value||'');
  const sort=byId('toolSort')?.value||'name',dir=byId('toolSortDir')?.dataset.dir||'asc';
  try{
    const d=await api(`/api/tools?q=${q}&sort=${sort}&dir=${dir}`);
    state.tools=d.tools||[];
    const tools=state.tools;
    const totalQty=tools.reduce((a,t)=>a+(Number(t.quantity)||1),0);
    const totalPln=tools.reduce((a,t)=>a+(Number(t.purchase_price_pln)||0)*(Number(t.quantity)||1),0);
    const totalEur=tools.reduce((a,t)=>a+(Number(t.purchase_price_eur)||0)*(Number(t.quantity)||1),0);
    if(byId('toolsLabel'))byId('toolsLabel').textContent=`${tools.length} pozycji · ${toolQtyText(totalQty)} szt. łącznie`;
    if(byId('toolOverviewCount'))byId('toolOverviewCount').textContent=String(tools.length);
    if(byId('toolOverviewQty'))byId('toolOverviewQty').textContent=toolQtyText(totalQty);
    if(byId('toolOverviewValue'))byId('toolOverviewValue').textContent=money(totalPln);
    if(byId('toolOverviewEurValue'))byId('toolOverviewEurValue').textContent=euroMoney(totalEur);
    renderToolsPage();
  }catch(e){
    byId('toolsGrid').innerHTML='<div class="empty-state tools-empty">Nie udało się pobrać kartoteki narzędzi.</div>';
  }
}
function toolPreviewRows(t){
  const qty=Number(t.quantity)||1,eur=Number(t.purchase_price_eur)||0,pln=Number(t.purchase_price_pln)||0;
  return [
    ['Numer katalogowy',t.catalog_no||'—'],['Numer seryjny',t.serial_no||'—'],['Kategoria',t.category||'—'],['Producent / model',[t.manufacturer,t.model].filter(Boolean).join(' · ')||'—'],
    ['Lokalizacja',t.location_code||t.location_name||'—'],['Ilość',toolQtyText(qty)+' szt.'],['Dostawca',t.supplier_name||'—'],['Faktura',t.invoice_no||'—'],['Data zakupu',t.purchase_date||'—'],
    ['Cena zakupu EUR / szt.',eur?euroMoney(eur):'—'],['Kurs EUR/PLN',Number(t.eur_rate)>0?Number(t.eur_rate).toFixed(4):'—'],['Cena zakupu PLN / szt.',money(pln)],
    ['Wartość EUR',eur?euroMoney(eur*qty):'—'],['Wartość PLN',money(pln*qty)]
  ];
}
function openToolPreview(id){
  const t=(state.tools||[]).find(x=>+x.id===+id);if(!t)return;
  state.previewToolId=+id;
  const rows=toolPreviewRows(t);
  const img=t.image_data?`<img src="${esc(t.image_data)}" alt="${esc(t.name)}">`:'<div class="tool-preview-placeholder">MB<br><span>NARZĘDZIE</span></div>';
  byId('toolPreviewContent').innerHTML=`<div class="tool-preview-hero"><div class="tool-preview-image">${img}</div><div class="tool-preview-title"><span>MB AUTO SERWIS · KARTOTEKA NARZĘDZI</span><h2>${esc(t.name)}</h2><p>${esc([t.manufacturer,t.model].filter(Boolean).join(' · ')||t.category||'Wyposażenie warsztatu')}</p><div class="tool-preview-code">${esc(t.catalog_no||'Bez numeru katalogowego')}</div></div></div><div class="tool-preview-data">${rows.map(([k,v])=>`<div><small>${esc(k)}</small><strong>${esc(v)}</strong></div>`).join('')}</div>${t.notes?`<div class="tool-preview-notes"><small>NOTATKI</small><p>${esc(t.notes)}</p></div>`:''}`;
  const edit=byId('toolPreviewEdit');if(edit){edit.onclick=()=>{byId('toolPreviewModal').classList.remove('show');openTool(+id)}}
  const pr=byId('toolPreviewPrint');if(pr)pr.onclick=()=>printToolCard(id);
  byId('toolPreviewModal').classList.add('show');
}
function printToolCard(id){
  const t=(state.tools||[]).find(x=>+x.id===+id);if(!t)return;
  const rows=toolPreviewRows(t),qty=Number(t.quantity)||1;
  const img=t.image_data?`<img src="${esc(t.image_data)}" alt="">`:'<div class="no-photo">BRAK ZDJĘCIA</div>';
  const html=`<div class="print-card"><div class="header"><div class="brand">MB AUTO SERWIS<small>KARTA NARZĘDZIA</small></div><div class="date">Wydruk: ${new Date().toLocaleString('pl-PL')}</div></div><div class="hero"><div class="photo">${img}</div><div class="title"><h1>${esc(t.name)}</h1><p>${esc([t.manufacturer,t.model,t.category].filter(Boolean).join(' · '))}</p><div class="code">${esc(t.catalog_no||'—')}</div><p>Ilość: <b>${toolQtyText(qty)} szt.</b></p></div></div><div class="grid">${rows.map(([k,v])=>`<div class="row"><small>${esc(k)}</small><strong>${esc(v)}</strong></div>`).join('')}</div>${t.notes?`<div class="notes"><small>Notatki</small><p>${esc(t.notes)}</p></div>`:''}<div class="footer"><span>MB Auto Serwis · ewidencja wyposażenia</span><span>ID ${Number(t.id)}</span></div></div>`;
  const css=`#printRoot{font-family:Arial,Helvetica,sans-serif;color:#15191d;font-size:9pt;width:190mm!important;max-width:190mm!important;height:auto!important;max-height:277mm!important;overflow:hidden!important;margin:0 auto!important}.print-card{width:190mm!important;max-width:190mm!important;margin:0 auto!important;break-inside:avoid!important;page-break-inside:avoid!important;page-break-after:avoid!important;overflow:hidden!important}.header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:1.5px solid #171b1f;padding-bottom:3.5mm}.brand{font-size:14pt;font-weight:800;letter-spacing:.02em}.brand small{display:block;margin-top:1mm;font-size:6.8pt;letter-spacing:.15em;color:#6b737a}.date{font-size:7pt;color:#687078}.hero{display:grid;grid-template-columns:42mm 1fr;gap:6mm;padding:5mm 0 4mm}.photo{height:30mm;border:1px solid #d9dde0;border-radius:2.5mm;display:grid;place-items:center;overflow:hidden;background:#f6f7f8}.photo img{max-width:100%;max-height:100%;object-fit:contain}.no-photo{font-size:7pt;color:#8a9298}.title h1{font-size:15pt;line-height:1.08;margin:0 0 1.5mm;max-height:12mm;overflow:hidden}.title p{margin:1mm 0;color:#555;font-size:8pt}.code{font-family:Consolas,monospace;font-size:9.5pt;font-weight:700;padding:1.6mm 2.2mm;background:#f1f3f4;border-radius:2mm;display:inline-block}.grid{display:grid;grid-template-columns:1fr 1fr;border-top:1px solid #d9dde0;border-left:1px solid #d9dde0}.row{padding:1.8mm 2.6mm;border-right:1px solid #d9dde0;border-bottom:1px solid #d9dde0;min-height:9.2mm;break-inside:avoid!important}.row small{display:block;color:#777f86;font-size:6pt;text-transform:uppercase;letter-spacing:.07em;margin-bottom:.6mm}.row strong{display:block;font-size:8.3pt;line-height:1.15;max-height:7mm;overflow:hidden}.notes{margin-top:3mm;padding:2.5mm 3mm;background:#f6f7f8;border-radius:2.5mm;max-height:18mm;overflow:hidden}.notes small{font-size:6pt;color:#777;text-transform:uppercase}.notes p{margin:.8mm 0 0;font-size:8pt;line-height:1.25;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.footer{margin-top:4mm;border-top:1px solid #ddd;padding-top:1.8mm;font-size:6.8pt;color:#777;display:flex;justify-content:space-between;break-inside:avoid!important}@media print{html,body,#printRoot,.print-card{width:190mm!important;max-width:190mm!important}#printRoot,.print-card{break-inside:avoid!important;page-break-inside:avoid!important;page-break-after:avoid!important}}`
  window.mbasPrintIsolated({title:`Karta narzędzia — ${t.name}`,html,css,page:'A4 portrait',margin:'10mm'});
}
window.loadTools=loadTools;window.openToolPreview=openToolPreview;window.printToolCard=printToolCard;
function openTool(id=null){toolOptions();byId('toolForm').reset();byId('toolId').value='';byId('toolImageData').value='';byId('toolImagePreview').innerHTML='';byId('toolQty').value=1;byId('toolModalTitle').textContent='Nowe narzędzie';if(id){const t=state.tools.find(x=>+x.id===+id);if(!t)return;byId('toolModalTitle').textContent='Edycja narzędzia';byId('toolId').value=t.id;const map={toolName:'name',toolCategory:'category',toolManufacturer:'manufacturer',toolModel:'model',toolCatalog:'catalog_no',toolSerial:'serial_no',toolLocation:'location_id',toolQty:'quantity',toolPricePln:'purchase_price_pln',toolPriceEur:'purchase_price_eur',toolEurRate:'eur_rate',toolEurRateDate:'eur_rate_date',toolEurRateTable:'eur_rate_table',toolInvoice:'invoice_no',toolSupplier:'supplier_id',toolPurchaseDate:'purchase_date',toolNotes:'notes'};for(const [id2,k] of Object.entries(map))byId(id2).value=t[k]??'';byId('toolImageData').value=t.image_data||'';if(t.image_data)byId('toolImagePreview').innerHTML=`<img src="${esc(t.image_data)}" alt="podgląd">`};if(byId('toolNbpState'))byId('toolNbpState').textContent=t.eur_rate_date&&t.eur_rate?`NBP: ${(+t.eur_rate).toFixed(4)} PLN · tabela ${t.eur_rate_table||'A'} · ${t.eur_rate_date}`:'Po wyborze daty kurs EUR pobierze się automatycznie z NBP.';eurCalc();byId('toolModal').classList.add('show');setTimeout(()=>byId('toolName').focus(),40)}
async function deleteTool(id){const t=state.tools.find(x=>+x.id===+id);if(!confirm(`Usunąć narzędzie${t?.name?' „'+t.name+'”':''} z kartoteki?`))return;try{try{await api('/api/tool/'+id,{method:'DELETE'})}catch(first){if(first?.code==='forbidden')throw first;await api('/api/tool/'+id+'/delete',{method:'POST',body:'{}'})}toast('Narzędzie usunięte');await loadTools();if(typeof loadToolReport150==='function')await loadToolReport150()}catch(e){toast(e?.code==='forbidden'?'Brak uprawnienia do usuwania narzędzi':`Nie udało się usunąć narzędzia (${e?.code||'błąd'})`)} }
if(byId('newToolBtn'))byId('newToolBtn').onclick=()=>openTool();
if(byId('newToolSide'))byId('newToolSide').onclick=()=>{page('tools');openTool();};
if(byId('toolSearch'))byId('toolSearch').oninput=()=>{clearTimeout(window.__toolSearch);window.__toolSearch=setTimeout(()=>loadTools(true),140)};
if(byId('toolSort'))byId('toolSort').onchange=()=>loadTools(true);
if(byId('toolSortDir'))byId('toolSortDir').onclick=()=>{const b=byId('toolSortDir');b.dataset.dir=b.dataset.dir==='asc'?'desc':'asc';b.textContent=b.dataset.dir==='asc'?'A → Z':'Z → A';loadTools(true)};
if(byId('toolPerPage')){state.toolPerPage=+byId('toolPerPage').value||50;byId('toolPerPage').onchange=()=>{state.toolPerPage=+byId('toolPerPage').value||50;state.toolPage=1;renderToolsPage()}};
if(byId('toolPrevPage'))byId('toolPrevPage').onclick=()=>{if((state.toolPage||1)>1){state.toolPage--;renderToolsPage()}};
if(byId('toolNextPage'))byId('toolNextPage').onclick=()=>{const pages=Math.max(1,Math.ceil((state.tools?.length||0)/(state.toolPerPage||50)));if((state.toolPage||1)<pages){state.toolPage++;renderToolsPage()}};
['toolPriceEur','toolEurRate','toolPricePln'].forEach(id=>byId(id)?.addEventListener('input',eurCalc));
if(byId('toolImageFile'))byId('toolImageFile').onchange=e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>3_500_000){e.target.value='';return toast('Zdjęcie jest za duże — maks. 3,5 MB')}const fr=new FileReader();fr.onload=()=>{state.toolImage=String(fr.result||'');byId('toolImageData').value=state.toolImage;byId('toolImagePreview').innerHTML=`<img src="${esc(state.toolImage)}" alt="podgląd">`};fr.readAsDataURL(f)};
if(byId('toolForm'))byId('toolForm').onsubmit=async e=>{e.preventDefault();const d={name:byId('toolName').value,category:byId('toolCategory').value,manufacturer:byId('toolManufacturer').value,model:byId('toolModel').value,catalog_no:byId('toolCatalog').value,serial_no:byId('toolSerial').value,location_id:byId('toolLocation').value,quantity:byId('toolQty').value,purchase_price_pln:byId('toolPricePln').value,purchase_price_eur:byId('toolPriceEur').value,eur_rate:byId('toolEurRate').value,invoice_no:byId('toolInvoice').value,supplier_id:byId('toolSupplier').value,purchase_date:byId('toolPurchaseDate').value,eur_rate_date:byId('toolEurRateDate').value,eur_rate_table:byId('toolEurRateTable').value,image_data:byId('toolImageData').value,notes:byId('toolNotes').value};const id=byId('toolId').value;try{await api(id?'/api/tool/'+id:'/api/tool',{method:id?'PUT':'POST',body:JSON.stringify(d)});byId('toolModal').classList.remove('show');toast(id?'Narzędzie zapisane':'Narzędzie dodane');loadTools(false)}catch(e2){toast('Nie udało się zapisać narzędzia')}};

// DIAGRAM — wspólne płótno + automatyczne hotspoty + ręczne ustawianie pozycji.
async function saveDiagramMarker(product,x,y,position){
  return await api(`/api/product/${product.id}/diagram-marker`,{method:'POST',body:JSON.stringify({x,y,diagram_position:position||product.diagram_position||'',oem_no:product.oem_no||'',name:product.name||'',source_url:product.source_url||''})});
}
function diagramHotspotsForRender(d,p){
  const pos=String(p.diagram_position||'').trim(),oem=norm(p.oem_no||p.sku||'');
  const hs=(d.diagram_hotspots||[]).filter(h=>Number.isFinite(+h.diagram_marker_x)&&Number.isFinite(+h.diagram_marker_y)&&+h.diagram_marker_x>=0&&+h.diagram_marker_x<=1&&+h.diagram_marker_y>=0&&+h.diagram_marker_y<=1).map(h=>({...h}));
  hs.forEach(h=>{const hp=String(h.diagram_position||'').trim(),ho=norm(h.oem_no||h.sku||'');h.__current=+(h.product_id||h.id||0)===+p.id || (!!pos&&hp===pos&&(!ho||!oem||ho===oem));});
  const hasCurrent=hs.some(h=>h.__current);
  if(!hasCurrent&&Number.isFinite(+p.diagram_marker_x)&&Number.isFinite(+p.diagram_marker_y))hs.unshift({product_id:p.id,id:p.id,oem_no:p.oem_no,sku:p.sku,name:p.name,diagram_position:p.diagram_position,diagram_marker_x:+p.diagram_marker_x,diagram_marker_y:+p.diagram_marker_y,__current:true});
  return hs;
}
function renderStableDiagram(){
  const d=S.detailProduct,p=d?.product,wrap=byId('detailImageWrap');if(!p||!wrap)return;
  if(!p.preview_image){wrap.className='product-image-empty';wrap.innerHTML=`Brak rysunku z Mercedes B2B / XENTRY${p.diagram_position?`<br><b>Pozycja: ${esc(p.diagram_position)}</b>`:''}`;return}
  const hs=diagramHotspotsForRender(d,p),initialPos=String(p.diagram_position||'').trim();
  wrap.className='product-image-wrap stable-diagram';
  wrap.innerHTML=`<div class="diagram-toolbar"><div class="diagram-left-tools"><button class="btn mini" data-z="out">−</button><span class="diagram-zoom-value">Dopasuj</span><button class="btn mini" data-z="in">＋</button><button class="btn mini" data-z="fit">Dopasuj</button><button class="btn mini" data-z="one">100%</button></div><div class="diagram-marker-tools"><label>Pozycja <input class="diagram-position-input" value="${esc(initialPos)}" inputmode="numeric" placeholder="np. 25"></label><button class="btn mini danger diagram-mark-btn" data-z="mark">Oznacz na rysunku</button><button class="btn mini hidden" data-z="cancelmark">Anuluj</button></div><small class="diagram-help">Zoom: Ctrl + rolka. Przesuwanie: przeciągnij rysunek.</small></div><div class="diagram-viewport"><div class="diagram-shell"><div class="diagram-content"><img src="${esc(p.preview_image)}" alt="Rysunek Mercedes B2B / XENTRY">${hs.map(h=>{const pid=h.product_id||h.id||'',cur=!!h.__current;const hoem=h.oem_no||h.sku||'';return `<button type="button" class="diagram-hotspot ${cur?'current':''} ${pid?'':'catalog-only'}" data-hx="${+h.diagram_marker_x}" data-hy="${+h.diagram_marker_y}" data-hotspot-oem="${esc(hoem)}" ${pid?`data-hotspot-product="${pid}"`:''}><span class="hotspot-badge">${esc(h.diagram_position||'•')}</span><span class="hotspot-tip"><b>Poz. ${esc(h.diagram_position||'—')} · ${esc(hoem||'—')}</b><span class="hotspot-name">${esc(h.name||'Część Mercedes')}</span>${cur?'<small>Aktualna pozycja tej części</small>':pid?'<small>Kliknij, aby otworzyć kartotekę</small>':'<small>Pozycja katalogowa bez lokalnej kartoteki</small>'}${hoem?`<span class="hotspot-copy" data-copy-hotspot="${esc(hoem)}">Kopiuj numer ${esc(hoem)}</span>`:''}</span></button>`}).join('')}</div></div></div>`;
  const viewport=wrap.querySelector('.diagram-viewport'),shell=wrap.querySelector('.diagram-shell'),content=wrap.querySelector('.diagram-content'),img=content.querySelector('img'),posInput=wrap.querySelector('.diagram-position-input');let zoom=1,baseW=0,baseH=0,markMode=false;
  const layout=(fit=false,native=false)=>{if(!img.naturalWidth)return;const avail=Math.max(300,viewport.clientWidth-100);if(fit||!baseW){const scale=Math.min(1,avail/img.naturalWidth,640/img.naturalHeight);baseW=Math.max(260,Math.round(img.naturalWidth*scale));baseH=Math.max(160,Math.round(img.naturalHeight*scale))}if(native){baseW=Math.min(img.naturalWidth,1900);baseH=Math.round(baseW*img.naturalHeight/img.naturalWidth)}img.style.width=baseW+'px';img.style.height=baseH+'px';content.style.width=baseW+'px';content.style.height=baseH+'px';content.style.transform=`scale(${zoom})`;shell.style.width=(baseW*zoom+100)+'px';shell.style.height=(baseH*zoom+100)+'px';content.style.left='50px';content.style.top='50px';const hotspotNodes=[...content.querySelectorAll('.diagram-hotspot')];hotspotNodes.forEach(h=>{h.style.left=(+h.dataset.hx*100)+'%';h.style.top=(+h.dataset.hy*100)+'%';h.style.setProperty('transform','translate(-50%,-50%)','important')});const groups=[];for(const h of hotspotNodes){const x=+h.dataset.hx*baseW,y=+h.dataset.hy*baseH;let g=groups.find(g=>Math.hypot(x-g.x,y-g.y)<27);if(!g){g={x,y,nodes:[]};groups.push(g)}g.nodes.push(h)}for(const g of groups){if(g.nodes.length<2)continue;const radius=g.nodes.length===2?14:Math.min(32,12+g.nodes.length*2.5);g.nodes.forEach((h,i)=>{const a=(-Math.PI/2)+(i*2*Math.PI/g.nodes.length),dx=Math.round(Math.cos(a)*radius),dy=Math.round(Math.sin(a)*radius);h.style.setProperty('transform',`translate(-50%,-50%) translate(${dx}px,${dy}px)`,'important')})}wrap.querySelector('.diagram-zoom-value').textContent=Math.round(zoom*100)+'%'};
  const setZoom=z=>{zoom=Math.max(.25,Math.min(5,z));layout()};
  const setMarkMode=on=>{markMode=!!on;viewport.classList.toggle('mark-mode',markMode);wrap.querySelector('[data-z="cancelmark"]')?.classList.toggle('hidden',!markMode);wrap.querySelector('[data-z="mark"]')?.classList.toggle('hidden',markMode);const help=wrap.querySelector('.diagram-help');help.textContent=markMode?`Kliknij dokładnie w miejsce pozycji ${posInput.value.trim()||'?'}. Klik zapisze znacznik.`:'Zoom: Ctrl + rolka. Przesuwanie: przeciągnij rysunek.';};
  img.onload=()=>{zoom=1;layout(true);viewport.scrollLeft=Math.max(0,(viewport.scrollWidth-viewport.clientWidth)/2)};if(img.complete&&img.naturalWidth){zoom=1;layout(true)};
  wrap.querySelector('[data-z="in"]').onclick=()=>setZoom(zoom+.2);wrap.querySelector('[data-z="out"]').onclick=()=>setZoom(zoom-.2);wrap.querySelector('[data-z="fit"]').onclick=()=>{zoom=1;baseW=0;layout(true);viewport.scrollLeft=0;viewport.scrollTop=0};wrap.querySelector('[data-z="one"]').onclick=()=>{zoom=1;layout(false,true)};
  wrap.querySelector('[data-z="mark"]').onclick=()=>{const pos=posInput.value.trim();if(!pos)return toast('Wpisz numer pozycji z rysunku, np. 25');setMarkMode(true)};wrap.querySelector('[data-z="cancelmark"]').onclick=()=>setMarkMode(false);
  viewport.onwheel=e=>{if(!e.ctrlKey)return;e.preventDefault();setZoom(zoom+(e.deltaY<0?.12:-.12))};let drag=false,x=0,y=0,sl=0,st=0;viewport.onpointerdown=e=>{if(markMode)return;if(e.target.closest('button,input'))return;drag=true;x=e.clientX;y=e.clientY;sl=viewport.scrollLeft;st=viewport.scrollTop;viewport.setPointerCapture?.(e.pointerId);viewport.classList.add('dragging')};viewport.onpointermove=e=>{if(drag){viewport.scrollLeft=sl-(e.clientX-x);viewport.scrollTop=st-(e.clientY-y)}};viewport.onpointerup=viewport.onpointercancel=()=>{drag=false;viewport.classList.remove('dragging')};
  const saveMarkerFromClick=async e=>{
    if(!markMode)return;
    if(e.target.closest?.('.diagram-hotspot'))return;
    e.preventDefault();e.stopPropagation();
    const r=img.getBoundingClientRect();if(!r.width||!r.height)return;
    const px=(e.clientX-r.left)/r.width,py=(e.clientY-r.top)/r.height;
    if(px<0||px>1||py<0||py>1)return;
    const pos=posInput.value.trim();if(!pos)return toast('Wpisz numer pozycji z rysunku, np. 25');
    const mx=+px.toFixed(6),my=+py.toFixed(6);
    // Natychmiast pokaż punkt, zanim backend odpowie — użytkownik widzi dokładnie gdzie kliknął.
    let preview=content.querySelector('.diagram-hotspot.marker-preview');
    if(!preview){preview=document.createElement('button');preview.type='button';preview.className='diagram-hotspot current marker-preview';preview.innerHTML=`<span class="hotspot-badge">${esc(pos)}</span>`;content.appendChild(preview)}
    preview.dataset.hx=String(mx);preview.dataset.hy=String(my);preview.style.left=(mx*100)+'%';preview.style.top=(my*100)+'%';
    try{
      const saved=await saveDiagramMarker(p,mx,my,pos);
      p.diagram_position=pos;p.diagram_marker_x=mx;p.diagram_marker_y=my;
      if(byId('detailDiagramPosition'))byId('detailDiagramPosition').textContent=pos;
      if(byId('detailFigurePos'))byId('detailFigurePos').textContent='poz. '+pos;
      const al=saved?.auto_location,loc=al?.location;
      if(loc){p.location_id=loc.id;toast(al.created?`Pozycja ${pos} zapisana · utworzono lokalizację ${loc.code}`:`Pozycja ${pos} zapisana · lokalizacja ${loc.code}`)}
      else toast(`Pozycja ${pos} została oznaczona i zapisana`);
      setMarkMode(false);
      const fresh=await api(`/api/product/${p.id}/detail`);S.detailProduct=fresh;renderStableDiagram();
    }catch(err){preview?.remove();const code=err?.code||err?.message||'błąd';toast(code==='forbidden'?'Brak uprawnienia do edycji kartoteki':'Nie udało się zapisać znacznika ('+code+')')}
  };
  // Klik łapiemy bezpośrednio na obrazie. Capture zabezpiecza przed innymi handlerami płótna.
  img.addEventListener('click',saveMarkerFromClick,true);
  wrap.querySelectorAll('[data-copy-hotspot]').forEach(c=>c.onclick=e=>{e.preventDefault();e.stopPropagation();copyCode(c.dataset.copyHotspot)});
  wrap.querySelectorAll('[data-hotspot-product]').forEach(b=>b.onclick=e=>{if(e.target.closest('[data-copy-hotspot]'))return;e.stopPropagation();const id=+b.dataset.hotspotProduct;if(id&&id!==+p.id)openProductDetail(id)});
}
const originalOpenProductDetail=openProductDetail;
openProductDetail=async function(id){await originalOpenProductDetail(id);const p=S.detailProduct?.product;if(byId('detailIcCard'))byId('detailIcCard').classList.add('hidden');if(byId('detailEnrichB2b'))byId('detailEnrichB2b').onclick=async()=>{const id=+p?.id;if(!id)return;const b=byId('detailEnrichB2b');b.disabled=true;try{await api(`/api/product/${id}/mercedes-enrich/request`,{method:'POST',body:JSON.stringify({force:true})});toast('Zlecono wyszukanie w Parts Information i B2B');setTimeout(()=>openProductDetail(id),2500)}catch(e){toast('Nie udało się zlecić wyszukiwania Mercedes')}finally{b.disabled=false}};if(byId('mbAvRefresh')){byId('mbAvRefresh').classList.remove('hidden');byId('mbAvRefresh').removeAttribute('aria-hidden')}renderStableDiagram();if(byId('detailAlts')){const local=S.detailProduct?.alternatives||[], mr=S.detailProduct?.mercedes_relations||[];byId('detailAlts').innerHTML=(local.length||mr.length)?[...local.map(a=>`<div class="listitem"><div><b>${esc(a.sku||a.oem_no||'—')}</b><br><small>${esc(a.name||'')}</small></div></div>`),...mr.map(r=>`<div class="listitem"><div><b>${esc(r.related_oem||'—')}</b><br><small>${esc(r.relation_type==='SUBSTITUTE'?'Zamiennik Mercedes':r.relation_type==='REPLACED_BY'?'Nowszy numer Mercedes':r.relation_type==='REPLACES'?'Poprzedni numer Mercedes':'Numer powiązany')}</small></div></div>`)].join(''):'<div class="hint">Brak zamienników.</div>';}const rel=S.detailProduct?.mercedes_relations||[];if(rel.length&&byId('detailAliases')){const exists=byId('detailAliases').querySelector('.audited-relations');if(!exists){const d=document.createElement('div');d.className='audited-relations';d.innerHTML='<small>Zamienniki Mercedes:</small> '+rel.map(r=>`<button class="alias-pill substitute" data-rel="${esc(r.related_oem)}">${esc(r.related_oem)}</button>`).join(' ');byId('detailAliases').appendChild(d);d.querySelectorAll('[data-rel]').forEach(b=>b.onclick=()=>{byId('productDetailModal').classList.remove('show');page('products');byId('productSearch').value=b.dataset.rel;loadProductsAudited(true)})}}};

// Zamienniki — tylko lokalne + relacje Mercedes B2B. Inter Cars nie jest częścią kartoteki.
async function loadMercedesAlternativesAudited(){
  const pid=+(byId('altBaseProduct')?.value||0);
  if(!pid){if(byId('alternativesBody'))byId('alternativesBody').innerHTML='<div class="hint">Wybierz część bazową.</div>';if(byId('externalAlternatives'))byId('externalAlternatives').innerHTML='';return}
  try{
    const d=await api('/api/product/'+pid+'/detail');
    if(byId('alternativesBody')){
      const local=d.alternatives||[];
      byId('alternativesBody').innerHTML=local.length?local.map(a=>`<div class="listitem"><div><b>${esc(a.sku||a.oem_no||'—')}</b><br><small>${esc(a.name||'')}</small></div></div>`).join(''):'<div class="hint">Brak lokalnych zamienników.</div>';
    }
    if(byId('externalAlternatives')){
      const rel=d.mercedes_relations||[];
      byId('externalAlternatives').innerHTML=rel.length?rel.map(r=>`<div class="listitem"><div><b>${esc(r.related_oem||'—')}</b><br><small>${esc(r.relation_type==='SUBSTITUTE'?'Zamiennik Mercedes':r.relation_type==='REPLACED_BY'?'Nowszy numer Mercedes':r.relation_type==='REPLACES'?'Poprzedni numer Mercedes':'Numer powiązany Mercedes')}</small></div><button class="btn mini" data-rel-search="${esc(r.related_oem||'')}">Pokaż w kartotece</button></div>`).join(''):'<div class="hint">Brak zamienników Mercedes zapisanych z B2B.</div>';
      byId('externalAlternatives').querySelectorAll('[data-rel-search]').forEach(b=>b.onclick=()=>{page('products');byId('productSearch').value=b.dataset.relSearch;loadProductsAudited(true)});
    }
  }catch(e){if(byId('externalAlternatives'))byId('externalAlternatives').innerHTML='<div class="hint">Nie udało się wczytać zamienników.</div>'}
}
loadAlternatives=loadMercedesAlternativesAudited;
if(byId('refreshAlternatives'))byId('refreshAlternatives').onclick=loadMercedesAlternativesAudited;
if(byId('altBaseProduct'))byId('altBaseProduct').onchange=loadMercedesAlternativesAudited;

// Uporządkowanie starego Inter Cars w UI.
document.querySelectorAll('.ic-search-card,.ic-detail-card').forEach(x=>x.classList.add('hidden'));

// Rebind zamknięć modali dla nowo dodanego okna narzędzi.
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>byId(b.dataset.close)?.classList.remove('show'));

bindProductControls();sortLabel();toolOptions();
// Jeśli aplikacja zdążyła się zalogować przed załadowaniem audytu, odśwież aktywny widok.
setTimeout(()=>{if(!byId('app')?.classList.contains('hidden')){loadSummaryAudited().catch(()=>{});if(!byId('productsPage')?.classList.contains('hidden'))loadProductsAudited(false).catch(()=>{})}},80);
})();
