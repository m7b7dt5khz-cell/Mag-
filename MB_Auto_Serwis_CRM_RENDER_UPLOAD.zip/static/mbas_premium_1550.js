/* MB Auto Serwis CRM 15.5.4 — premium shell enhancements */
(()=>{
  'use strict';
  const root=document.documentElement;
  const THEME_KEY='mbas_theme';
  const REV_KEY='mbas_ui_rev';
  const REV='1554';
  const topTheme=document.getElementById('topThemeBtn');
  const themeBtn=document.getElementById('themeToggle');

  function current(){return root.getAttribute('data-theme')==='dark'?'dark':'light'}
  function syncThemeLabels(){
    const dark=current()==='dark';
    if(topTheme){topTheme.setAttribute('aria-label',dark?'Włącz jasny motyw':'Włącz ciemny motyw');topTheme.title=dark?'Włącz jasny motyw':'Włącz ciemny motyw'}
    if(themeBtn){themeBtn.textContent=dark?'Motyw: Ciemny':'Motyw: Jasny';themeBtn.title=dark?'Przełącz na jasny motyw':'Przełącz na ciemny motyw';themeBtn.setAttribute('aria-pressed',dark?'true':'false')}
  }
  const obs=new MutationObserver(syncThemeLabels);obs.observe(root,{attributes:true,attributeFilter:['data-theme']});
  try{localStorage.setItem(REV_KEY,REV)}catch(e){}
  document.addEventListener('DOMContentLoaded',()=>{
    syncThemeLabels();
    document.querySelectorAll('.card, .btn, .firm-nav button').forEach(el=>el.classList.add('mbas-premium-ready'));
  });
})();
