/* MB Auto Serwis 13.1 — users, permissions, pricing, VAT, global markup/margin */
S.user=S.user||null;
S.priceMode=localStorage.getItem('mb_price_mode')||'net';
S.userPermissionDefs=[];
S.pricingSettings={vat_rate:23,pricing_mode:'MARKUP',pricing_pct:0};

function can125(perm){
  if(!S.user)return false;
  if(S.user.role==='ADMIN')return true;
  const p=S.user.permissions||[];return p.includes('*')||p.includes(perm);
}
function vat125(v){return (v===''||v===null||v===undefined||Number.isNaN(Number(v)))?23:Number(v)}
function price125(net,vat){const n=Number(net)||0,v=vat125(vat);return +(S.priceMode==='gross'?n*(1+v/100):n).toFixed(2)}
function priceModeLabel125(){return S.priceMode==='gross'?'brutto':'netto'}
function pricingMode125(v){return String(v||'MARKUP').toUpperCase()==='MARGIN'?'MARGIN':'MARKUP'}
function pricingName125(v){return pricingMode125(v)==='MARGIN'?'marża':'narzut'}
function calcSell125(buy,pct,mode){buy=Number(buy)||0;pct=Number(pct)||0;mode=pricingMode125(mode);if(buy<=0)return 0;if(mode==='MARGIN'){pct=Math.max(-100,Math.min(99.99,pct));return buy/(1-pct/100)}return buy*(1+pct/100)}
function pctFromSell125(buy,sell,mode){buy=Number(buy)||0;sell=Number(sell)||0;mode=pricingMode125(mode);if(buy<=0||sell<=0)return 0;return mode==='MARGIN'?((sell-buy)/sell)*100:(sell/buy-1)*100}

const _showAuth125=showAuth;
showAuth=function(setup){
  _showAuth125(setup);
  if($('username')){$('username').value=setup?'admin':($('username').value||'admin');$('username').readOnly=!!setup;}
  $('authText').textContent=setup?'Pierwsze uruchomienie — utwórz konto administratora':'Zaloguj do systemu magazynowego';
};

$('authForm').onsubmit=async e=>{
  e.preventDefault();const password=$('password').value,username=($('username')?.value||'admin').trim();
  try{
    let d;
    if(S.setup){if(password.length<10)return toast('Hasło: minimum 10 znaków');if(password!==$('password2').value)return toast('Hasła nie są identyczne');d=await api('/api/setup',{method:'POST',body:JSON.stringify({username,password})});}
    else d=await api('/api/login',{method:'POST',body:JSON.stringify({username,password})});
    S.csrf=d.csrf;S.user=d.user||null;showApp();await loadAll();applyPermissions125();
  }catch(err){toast(err.code==='invalid_login'?'Nieprawidłowy login lub hasło':err.code==='too_many_attempts'?'Za dużo prób logowania. Spróbuj później.':'Błąd logowania');}
};

async function refreshSession125(){
  try{const d=await api('/api/session');if(d.logged_in){S.csrf=d.csrf;S.user=d.user||null;applyPermissions125();}}
  catch(_){ }
}

function applyPermissions125(){
  if(!S.user)return;
  if($('currentUserBadge'))$('currentUserBadge').textContent=`${S.user.display_name||S.user.username} · ${S.user.role==='ADMIN'?'Administrator':'Pracownik'}`;
  if($('usersNav'))$('usersNav').classList.toggle('hidden',!can125('users_admin'));
  const hide=(id,allowed)=>{const e=$(id);if(e)e.classList.toggle('hidden',!allowed)};
  hide('newProductTop',can125('products_edit'));hide('newProductSide',can125('products_edit'));hide('newMovementTop',can125('stock_edit'));hide('newMovementSide',can125('stock_edit'));hide('newToolSide',can125('tools_edit'));hide('backupSide',can125('data_admin'));
  hide('deleteSelectedProducts',can125('products_edit'));hide('pricingSettingsBtn',can125('products_edit'));hide('clearDatabaseBtn',can125('data_admin'));hide('exportSelectedB2b',can125('b2b_import'));
  if($('detailEdit'))$('detailEdit').classList.toggle('hidden',!can125('products_edit'));
  document.querySelectorAll('.diagram-marker-tools').forEach(e=>e.classList.toggle('hidden',!can125('products_edit')));
  if($('detailArchive'))$('detailArchive').classList.toggle('perm-hidden',!can125('products_edit'));
  ['detailOutRw','detailOutWz','detailInPz'].forEach(id=>{if($(id))$(id).classList.toggle('hidden',!can125('stock_edit'))});
  if($('newToolBtn'))$('newToolBtn').classList.toggle('hidden',!can125('tools_edit'));

  // Read-only employee: keep search/view screens clean. The backend still enforces
  // permissions independently; these hides are only the user-facing layer.
  const cardByForm=(id,allowed)=>{const f=$(id);const c=f?.closest('.card');if(c)c.classList.toggle('hidden',!allowed)};
  cardByForm('supplierForm',can125('suppliers_edit'));
  cardByForm('locationForm',can125('locations_edit'));
  cardByForm('nipForm',can125('contractors_edit'));
  hide('linkLocalAlt',can125('substitutes_edit'));
  if($('documentEditPanel'))$('documentEditPanel').classList.toggle('hidden',!can125('documents_edit'));
  ['saveIntegrations','testInterCars','syncInterCarsAll'].forEach(id=>hide(id,can125('integrations_edit')));
  document.querySelectorAll('[data-location-edit],[data-location-del]').forEach(e=>e.classList.toggle('hidden',!can125('locations_edit')));
  document.querySelectorAll('[data-supplier-edit],[data-supplier-del]').forEach(e=>e.classList.toggle('hidden',!can125('suppliers_edit')));
  document.querySelectorAll('[data-contractor-edit],[data-contractor-del]').forEach(e=>e.classList.toggle('hidden',!can125('contractors_edit')));
}

const _page125=page;
page=function(p){
  if(p==='users'){
    ['dashboard','products','movements','documents','alternatives','integrations','b2b','suppliers','locations','contractors','tools','users'].forEach(x=>{const e=$(x+'Page');if(e)e.classList.toggle('hidden',x!==p)});
    document.querySelectorAll('nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===p));$('title').textContent='Użytkownicy i uprawnienia';loadUsers125();return;
  }
  if(p==='tools'){
    ['dashboard','products','movements','documents','alternatives','integrations','b2b','suppliers','locations','contractors','tools','users'].forEach(x=>{const e=$(x+'Page');if(e)e.classList.toggle('hidden',x!==p)});
    document.querySelectorAll('nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===p));$('title').textContent='Kartoteka narzędzi';if(typeof window.loadTools==='function')window.loadTools(true);if(typeof window.loadToolReport150==='function')setTimeout(window.loadToolReport150,60);return;
  }
  _page125(p);const u=$('usersPage'),t=$('toolsPage');if(u)u.classList.add('hidden');if(t&&p!=='tools')t.classList.add('hidden');
  if(p==='b2b')loadExportHistory125();applyPermissions125();
};
document.querySelectorAll('nav [data-page]').forEach(b=>b.onclick=()=>page(b.dataset.page));

async function loadUsers125(){
  if(!can125('users_admin'))return;
  try{
    const [d,a]=await Promise.all([api('/api/users'),api('/api/audit')]);S.userPermissionDefs=d.available_permissions||[];
    $('usersList').innerHTML=(d.users||[]).map(u=>`<div class="user-card"><div><b>${esc(u.display_name||u.username)}</b><span>@${esc(u.username)} · ${u.role==='ADMIN'?'Administrator':'Pracownik'}</span><small>${u.active?'Aktywny':'ZABLOKOWANY'}${u.last_login?` · ostatnie logowanie ${esc(String(u.last_login).replace('T',' ').slice(0,16))}`:''}</small></div><button class="btn mini" data-user-edit="${u.id}">Ustawienia</button></div>`).join('')||'<div class="hint">Brak użytkowników.</div>';
    $('usersList').querySelectorAll('[data-user-edit]').forEach(b=>b.onclick=()=>openUser125((d.users||[]).find(x=>+x.id===+b.dataset.userEdit)));
    $('auditList').innerHTML=(a.events||[]).slice(0,100).map(x=>`<div class="audit-row"><b>${esc(x.username||'system')}</b><span>${esc(x.method)} ${esc(x.path)}</span><small>${esc(String(x.created_at||'').replace('T',' ').slice(0,19))} · ${esc(x.outcome||'')}</small></div>`).join('')||'<div class="hint">Brak operacji.</div>';
  }catch(e){toast('Nie udało się pobrać użytkowników');}
}
function renderPermissions125(selected=[]){
  const box=$('userPermissions');if(!box)return;box.innerHTML=S.userPermissionDefs.map(([key,label])=>`<label class="permission-item"><input type="checkbox" value="${esc(key)}" ${selected.includes(key)||selected.includes('*')?'checked':''}><span>${esc(label)}</span></label>`).join('');
  const admin=$('userRole').value==='ADMIN';box.querySelectorAll('input').forEach(x=>{x.disabled=admin;if(admin)x.checked=true});
}
function openUser125(u=null){
  $('userForm').reset();$('userId').value=u?.id||'';$('userModalTitle').textContent=u?'Ustawienia użytkownika':'Nowy użytkownik';$('userLogin').value=u?.username||'';$('userLogin').readOnly=!!u;$('userDisplay').value=u?.display_name||'';$('userRole').value=u?.role||'EMPLOYEE';$('userActive').value=u?(u.active?'1':'0'):'1';$('userPassword').value='';$('userPassword').required=!u;$('resetUserPasswordBtn').classList.toggle('hidden',!u);renderPermissions125(u?.permissions||[]);$('userModal').classList.add('show');
}
$('newUserBtn')?.addEventListener('click',()=>openUser125());
$('userRole')?.addEventListener('change',()=>renderPermissions125([...document.querySelectorAll('#userPermissions input:checked')].map(x=>x.value)));
$('userForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const id=$('userId').value;const permissions=[...document.querySelectorAll('#userPermissions input:checked')].map(x=>x.value);const data={username:$('userLogin').value.trim(),display_name:$('userDisplay').value.trim(),role:$('userRole').value,active:$('userActive').value==='1',permissions,password:$('userPassword').value};
  try{
    if(id){await api('/api/user/'+id,{method:'PUT',body:JSON.stringify(data)});if(data.password)await api(`/api/user/${id}/password`,{method:'POST',body:JSON.stringify({password:data.password})});}
    else await api('/api/users',{method:'POST',body:JSON.stringify(data)});
    $('userModal').classList.remove('show');toast(id?'Użytkownik zaktualizowany':'Użytkownik utworzony');await loadUsers125();
  }catch(err){toast(err.code==='duplicate_username'?'Taki login już istnieje':err.code==='cannot_disable_self'?'Nie możesz zablokować własnego konta':err.code==='password_too_short'?'Hasło musi mieć minimum 10 znaków':'Nie udało się zapisać użytkownika');}
});
$('resetUserPasswordBtn')?.addEventListener('click',()=>{$('userPassword').focus();toast('Wpisz nowe hasło i kliknij „Zapisz użytkownika”')});

$('changePasswordBtn')?.addEventListener('click',()=>{$('changePasswordForm').reset();$('changePasswordModal').classList.add('show')});
$('changePasswordForm')?.addEventListener('submit',async e=>{e.preventDefault();if($('newPassword').value!==$('newPassword2').value)return toast('Nowe hasła nie są identyczne');try{await api('/api/account/password',{method:'POST',body:JSON.stringify({current_password:$('currentPassword').value,new_password:$('newPassword').value})});$('changePasswordModal').classList.remove('show');toast('Hasło zostało zmienione')}catch(err){toast(err.code==='wrong_password'?'Obecne hasło jest nieprawidłowe':'Nie udało się zmienić hasła')}});

// ----- ceny netto/brutto + marża -----
if($('priceMode')){$('priceMode').value=S.priceMode;$('priceMode').onchange=()=>{S.priceMode=$('priceMode').value;localStorage.setItem('mb_price_mode',S.priceMode);if(typeof loadProducts==='function')loadProducts();if(S.detailProduct)refreshDetailPrice125(S.detailProduct.product)}}
const _stableRow125=stableProductRow;
stableProductRow=function(p,raw){
  const nq=normCode(raw),vals=[p.sku,p.oem_no,p.barcode,...String(p.aliases||'').split(',')].map(normCode),exact=nq&&vals.includes(nq),checked=S.selectedProductIds.has(+p.id)?'checked':'';
  const buy=price125(p.purchase_price,p.vat_rate),sell=price125(p.sell_price_net||p.sale_price,p.vat_rate),edit=can125('products_edit')?`<button class="btn mini" data-edit="${p.id}">Edytuj</button>`:'';
  const ptype=pricingName125(p.pricing_mode),vat=vat125(p.vat_rate);
  return `<tr class="${p.active?'':'archived-row'} ${raw?'search-hit':''} ${exact?'search-exact':''}" data-product-row="${p.id}"><td><input type="checkbox" class="product-select" value="${p.id}" ${checked}></td><td>${p.sku?`<button class="code-copy" data-copy-code="${esc(p.sku)}">${esc(p.sku)}</button>`:'—'}</td><td>${p.oem_no?`<button class="code-copy primary-code" data-copy-code="${esc(p.oem_no)}">${esc(p.oem_no)}</button>`:'—'}${p.latest_oem&&normCode(p.latest_oem)!==normCode(p.oem_no)?`<br><span class="latest-oem-mini">Nowszy: ${esc(p.latest_oem)}</span>`:''}${p.aliases?`<br><small>${esc(p.aliases)}</small>`:''}</td><td><b>${esc(p.name)}</b><br><small>${esc(p.category||'')}</small></td><td>${esc(p.location_code||'—')}</td><td class="${(+p.stock_qty)<=(+p.min_qty)?'low':'ok'}">${(+p.stock_qty).toFixed(2)} ${esc(p.unit)}</td><td>${(+p.min_qty).toFixed(2)}</td><td>${mbListStatus(p)}</td><td>${money(buy)}<br><small>${priceModeLabel125()}${S.priceMode==='gross'?` · VAT ${vat.toFixed(1)}%`:''}</small></td><td><b>${money(sell)}</b><br><small>${priceModeLabel125()} · ${ptype} ${(+p.margin_pct||0).toFixed(1)}%${S.priceMode==='gross'?` · VAT ${vat.toFixed(1)}%`:''}</small></td><td>${esc(p.supplier_name||'—')}</td><td class="row-actions"><button class="btn mini" data-open-product="${p.id}">Otwórz</button>${edit}</td></tr>`;
};
// Nagłówki tabel cen
try{const hs=[...document.querySelectorAll('#productsPage th')];const pth=hs.find(x=>x.textContent.includes('Cena zakupu'));const sth=hs.find(x=>x.textContent.includes('Cena katalogowa'));if(pth)pth.textContent='Cena zakupu';if(sth)sth.textContent='Cena sprzedaży';}catch(_){ }

function updatePricingLabels125(){const mode=pricingMode125($('pricing_mode')?.value);if($('pricingPctLabel'))$('pricingPctLabel').textContent=mode==='MARGIN'?'Marża %':'Narzut %'}
function recalcPrices125(source){
  const buy=+$('purchase_price').value||0,vat=vat125($('vat_rate').value),mode=pricingMode125($('pricing_mode')?.value);let pct=+$('margin_pct').value||0,sell=+$('sell_price_net').value||0;
  if(source==='margin'||source==='buy'||source==='mode'){sell=Math.max(0,calcSell125(buy,pct,mode));$('sell_price_net').value=sell.toFixed(2)}
  if(source==='sell'&&buy>0){pct=pctFromSell125(buy,sell,mode);$('margin_pct').value=pct.toFixed(2)}
  $('sell_price_gross').value=(sell*(1+vat/100)).toFixed(2);
  updatePricingLabels125();
}
['purchase_price','margin_pct'].forEach(id=>$(id)?.addEventListener('input',()=>recalcPrices125(id==='margin_pct'?'margin':'buy')));$('pricing_mode')?.addEventListener('change',()=>recalcPrices125('mode'));$('sell_price_net')?.addEventListener('input',()=>recalcPrices125('sell'));$('vat_rate')?.addEventListener('input',()=>recalcPrices125('vat'));$('sell_price_gross')?.addEventListener('input',()=>{const vat=vat125($('vat_rate').value),g=+$('sell_price_gross').value||0;$('sell_price_net').value=(g/(1+vat/100)).toFixed(2);recalcPrices125('sell')});

const _openProduct125=openProduct;
openProduct=function(id=null){
  _openProduct125(id);const p=id?S.products.find(x=>+x.id===+id):null;const ps=S.pricingSettings||{vat_rate:23,pricing_mode:'MARKUP',pricing_pct:0};$('pricing_mode').value=pricingMode125(p?.pricing_mode||ps.pricing_mode);$('margin_pct').value=p?.margin_pct??ps.pricing_pct??0;$('vat_rate').value=p?.vat_rate??ps.vat_rate??23;$('sell_price_net').value=p?.sell_price_net??(p?.sale_price||0);$('productForm').dataset.expectedUpdatedAt=p?.updated_at||'';recalcPrices125(id?'vat':'margin');
};
$('productForm').onsubmit=async e=>{
  e.preventDefault();const d={};['sku','oem_no','barcode','name','category','supplier_id','location_id','min_qty','purchase_price','sale_price','pricing_mode','margin_pct','vat_rate','sell_price_net','unit','diagram_position'].forEach(k=>d[k]=$(k).value);d.aliases=$('productAliasesInput').value;d.notes=$('product_notes').value;d.expected_updated_at=$('productForm').dataset.expectedUpdatedAt||'';
  try{const id=$('productId').value;const r=id?await api('/api/product/'+id,{method:'PUT',body:JSON.stringify(d)}):await api('/api/product',{method:'POST',body:JSON.stringify(d)});$('productModal').classList.remove('show');toast('Część zapisana');await Promise.all([loadProducts(),loadSummary()]);if(!id&&r.id)setTimeout(()=>openProductDetail(r.id),250)}catch(err){toast(err.code==='edit_conflict'?'Ktoś zmienił tę kartotekę w międzyczasie. Otwórz ją ponownie.':err.code==='forbidden'?'Brak uprawnienia do edycji kartoteki':err.code==='duplicate_code'?'SKU/OEM/kod już istnieje':'Nie udało się zapisać')}
};

function refreshDetailPrice125(p){if(!p)return;const mode=priceModeLabel125(),ptype=pricingName125(p.pricing_mode),vat=vat125(p.vat_rate);if($('detailMargin')){ $('detailMargin').textContent=`${(+p.margin_pct||0).toFixed(1)}%`; const lab=$('detailMargin').parentElement?.querySelector('small'); if(lab)lab.textContent=ptype==='marża'?'Marża':'Narzut'; }if($('detailBuy'))$('detailBuy').textContent=money(price125(p.purchase_price,vat));if($('detailSale'))$('detailSale').textContent=money(price125(p.sale_price,vat));if($('detailSell'))$('detailSell').textContent=money(price125(p.sell_price_net||p.sale_price,vat));['detailPriceModeLabel','detailBuyModeLabel','detailCatalogModeLabel'].forEach(id=>{if($(id))$(id).textContent=mode});const meta=$('detailMeta');if(meta){meta.querySelectorAll('.pricing-meta-125').forEach(x=>x.remove());meta.insertAdjacentHTML('beforeend',`<div class="pricing-meta-125"><b>VAT:</b> ${vat.toFixed(1)}%</div><div class="pricing-meta-125"><b>${ptype==='marża'?'Marża':'Narzut'}:</b> ${(+p.margin_pct||0).toFixed(1)}%</div><div class="pricing-meta-125"><b>Sprzedaż netto:</b> ${money(+p.sell_price_net||0)}</div><div class="pricing-meta-125"><b>Sprzedaż brutto:</b> ${money((+p.sell_price_net||0)*(1+vat/100))}</div>`)}}
function renderLatestNumber125(d){const box=$('detailLatestNumber');if(!box)return;const p=d?.product,latest=String(d?.latest_oem||'').trim();if(!p||!latest||normCode(latest)===normCode(p.oem_no||p.sku||'')){box.classList.add('hidden');box.innerHTML='';return}box.classList.remove('hidden');box.innerHTML=`<span>NAJNOWSZY NUMER WG MERCEDES</span><button type="button" class="latest-oem-code" data-copy-code="${esc(latest)}">${esc(latest)}</button><small>Ten numer występuje w Parts Information jako nowszy numer zastępujący aktualną kartotekę.</small>`;box.querySelector('[data-copy-code]')?.addEventListener('click',()=>copyCode(latest));}
const _detail125=openProductDetail;
openProductDetail=async function(id){await _detail125(id);refreshDetailPrice125(S.detailProduct?.product);renderLatestNumber125(S.detailProduct);applyPermissions125();};

async function loadPricingSettings131(){
  try{const r=await api('/api/pricing/settings');S.pricingSettings=r.settings||S.pricingSettings;return S.pricingSettings}catch(_){return S.pricingSettings}
}
function updateGlobalPricingExample131(){
  const vat=vat125($('globalVatRate')?.value),mode=pricingMode125($('globalPricingMode')?.value),pct=+$('globalPricingPct')?.value||0,buy=100,sell=calcSell125(buy,pct,mode),gross=sell*(1+vat/100);
  if($('globalPricingPctLabel'))$('globalPricingPctLabel').textContent=mode==='MARGIN'?'Marża %':'Narzut %';
  if($('globalPricingExample'))$('globalPricingExample').textContent=`Przykład dla zakupu 100,00 zł netto`;
  if($('globalPricingFormula'))$('globalPricingFormula').textContent=`${mode==='MARGIN'?'Marża':'Narzut'} ${pct.toFixed(1)}% → sprzedaż ${sell.toFixed(2)} zł netto → ${gross.toFixed(2)} zł brutto przy VAT ${vat.toFixed(1)}%.`;
}
async function openPricingSettings131(){
  const ps=await loadPricingSettings131();$('globalVatRate').value=ps.vat_rate??23;$('globalPricingMode').value=pricingMode125(ps.pricing_mode);$('globalPricingPct').value=ps.pricing_pct??0;updateGlobalPricingExample131();$('pricingSettingsModal').classList.add('show');
}
$('pricingSettingsBtn')?.addEventListener('click',openPricingSettings131);
['globalVatRate','globalPricingPct'].forEach(id=>$(id)?.addEventListener('input',updateGlobalPricingExample131));$('globalPricingMode')?.addEventListener('change',updateGlobalPricingExample131);
async function savePricing131(applyAll){
  const data={vat_rate:+$('globalVatRate').value||0,pricing_mode:$('globalPricingMode').value,pricing_pct:+$('globalPricingPct').value||0,apply_all:!!applyAll,active_only:$('globalPricingActiveOnly').checked};
  if(data.pricing_mode==='MARGIN'&&data.pricing_pct>=100)return toast('Marża musi być mniejsza niż 100%');
  try{const r=await api('/api/pricing/settings',{method:'POST',body:JSON.stringify(data)});S.pricingSettings=r.settings||data;$('pricingSettingsModal').classList.remove('show');if(applyAll)toast(`Przeliczono ${r.updated||0} części. Bez ceny zakupu: ${r.skipped_no_purchase_price||0}.`);else toast('Domyślne ustawienia cen zostały zapisane');await loadProducts();if(S.detailProduct)await openProductDetail(S.detailProduct.product.id)}catch(err){toast(err.code==='forbidden'?'Brak uprawnień do zmiany cen':err.code==='margin_too_high'?'Marża musi być mniejsza niż 100%':'Nie udało się zapisać ustawień cen')}
}
$('savePricingDefaultsBtn')?.addEventListener('click',()=>savePricing131(false));$('applyPricingAllBtn')?.addEventListener('click',()=>{const mode=$('globalPricingMode').value==='MARGIN'?'marżę':'narzut',pct=+$('globalPricingPct').value||0,vat=+$('globalVatRate').value||0;if(confirm(`Ustawić dla wszystkich ${$('globalPricingActiveOnly').checked?'aktywnych ':''}części VAT ${vat}% oraz ${mode} ${pct}% i przeliczyć ceny sprzedaży?`))savePricing131(true)});
setTimeout(loadPricingSettings131,180);

async function loadExportHistory125(){
  if(!$('b2bExportHistory'))return;try{const d=await api('/api/b2b/export-history');$('b2bExportFolder').textContent=d.folder||'';$('b2bExportHistory').innerHTML=(d.exports||[]).map(x=>`<div class="b2b-card"><div><b>${esc(x.file_name)}</b><small>${esc(String(x.created_at||'').replace('T',' ').slice(0,19))} · ${x.item_count} pozycji · ${esc(x.username||'')}</small></div><span>${esc(x.vin||'')}</span></div>`).join('')||'<div class="hint">Brak eksportów.</div>'}catch(_){ }
}

// odśwież użytkownika po uruchomieniu starego boot()
setTimeout(refreshSession125,100);


// Re-apply visibility after lists recreate edit/delete buttons.
for(const fnName of ['loadSuppliers','loadLocations','loadContractors']){
  const original=globalThis[fnName];
  if(typeof original==='function')globalThis[fnName]=async function(...args){const r=await original.apply(this,args);applyPermissions125();return r};
}
