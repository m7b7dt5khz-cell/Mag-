// MB Auto Serwis 15.2.4 — Bridge auto-start + zbiorcze dokumenty magazynowe.
(function(){
'use strict';
const PI_URL='https://aftersales.mercedes-benz.com/xhpi/ng/';
const B2B_URL='https://b2bconnect.mercedes-benz.com/pl/catalog';
const TOOL_URL='https://b2bconnect.mercedes-benz.com/pl/shop/workshop-equipment/search-equipment';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let _portalOpenLock={};
async function mercedesPortalOnline(kind){
  try{
    const d=await api('/api/quick-catalog');const ps=d.portals||[];
    if(kind==='PI')return ps.some(p=>String(p.source||'').toUpperCase()==='PARTSINFO'&&p.online);
    return ps.some(p=>['B2B','XENTRY'].includes(String(p.source||'').toUpperCase())&&p.online);
  }catch(_){return false}
}
async function portalOpen(url,kind){
  // 15.6.1: najpierw używamy heartbeat serwera. W desktopowym WebView rozszerzenie Chrome
  // nie jest wstrzyknięte do okna CRM, więc oczekiwanie na postMessage kończyło się timeoutem
  // i każde kliknięcie mogło otwierać kolejną kartę.
  if(await mercedesPortalOnline(kind))return {reused:true};
  try{const exact=await window.mbEnsureMercedesPortal?.(kind,url);if(exact?.ok)return exact}catch(_){}
  if(await mercedesPortalOnline(kind))return {reused:true};
  const now=Date.now();if(_portalOpenLock[kind]&&now-_portalOpenLock[kind]<18000)return {opening:true};_portalOpenLock[kind]=now;
  try{await api('/api/system/open-chrome',{method:'POST',body:JSON.stringify({url})});return {opened:true}}
  catch(e){toast(e?.code==='chrome_not_found'?'Nie znaleziono Google Chrome':'Nie udało się otworzyć Chrome');return {error:true}}
}
async function openMercedesDataPortals(){
  const [pi,bb]=await Promise.all([portalOpen(PI_URL,'PI'),portalOpen(B2B_URL,'B2B')]);
  return !pi?.error&&!bb?.error;
}
async function openMercedesToolPortal(){
  // Każda aktywna karta B2B jest wystarczająca — Bridge przenawiguje JĄ, zamiast tworzyć nową.
  const r=await portalOpen(TOOL_URL,'B2B');return !r?.error;
}
window.mbOpenMercedesDataPortals=openMercedesDataPortals;

// Narzędzia: otwórz właściwy widok B2B ZANIM zlecenie trafi do kolejki.
if(typeof queueToolB2B1523==='function'){
  const _queueTool=queueToolB2B1523;
  queueToolB2B1523=async function(catalogNo,toolId=0){await openMercedesToolPortal();await sleep(150);return _queueTool(catalogNo,toolId)};
}

// Karta produktu: jedno kliknięcie uruchamia oba portale i świeżą kolejkę.
if(typeof openProductDetail==='function'){
  const _openDetail1524=openProductDetail;
  openProductDetail=async function(id){
    await _openDetail1524(id);
    const btn=$('detailEnrichB2b');
    if(btn){btn.onclick=async()=>{
      const pid=+(S.detailProduct?.product?.id||id||0);if(!pid)return;
      await openMercedesDataPortals();btn.disabled=true;
      const before=typeof detailSignature==='function'?detailSignature(S.detailProduct):'';
      try{
        await api(`/api/product/${pid}/mercedes-enrich/request`,{method:'POST',body:JSON.stringify({force:true})});
        toast('Mercedes: uruchomiono Parts Information + B2B');
        for(let i=0;i<120;i++){
          await sleep(2000);
          const nd=await api(`/api/product/${pid}/detail`).catch(()=>null);if(!nd)continue;
          const pi=String(nd?.partsinfo_request?.status||'').toUpperCase();
          const bb=String(nd?.b2b_request?.status||'').toUpperCase();
          const sig=typeof detailSignature==='function'?detailSignature(nd):JSON.stringify([nd?.product?.updated_at,nd?.product?.name,nd?.product?.preview_image]);
          if(sig!==before){try{if(typeof refreshCatalog150==='function')await refreshCatalog150();else if(typeof loadProductsSorted==='function')await loadProductsSorted(false)}catch(_){};if($('productDetailModal')?.classList.contains('show'))await _openDetail1524(pid)}
          if(['DONE','ERROR'].includes(pi)&&['DONE','ERROR'].includes(bb)){if(pi==='ERROR'||bb==='ERROR')toast('Mercedes zakończył pobieranie z błędem — sprawdź status na karcie');else toast('Dane Mercedes zostały uzupełnione');break}
        }
        try{if(typeof refreshCatalog150==='function')await refreshCatalog150();else if(typeof loadProductsSorted==='function')await loadProductsSorted(false)}catch(_){}
      }catch(e){toast('Nie udało się uruchomić integracji Mercedes')}finally{btn.disabled=false}
    }}
  };
}

function bulkRowState(row,status,text){
  if(!row)return;row.classList.remove('queued','done','error');row.classList.add(status);const ic=row.querySelector('span'),sm=row.querySelector('small');if(ic)ic.textContent=status==='done'?'✓':status==='error'?'!':'…';if(sm)sm.textContent=text;
}
async function runBulkMercedes1524(ids=[],onlyMissing=false){
  await openMercedesDataPortals();
  bulkMercedesOpen();if($('bulkMercedesItems'))$('bulkMercedesItems').innerHTML='';bulkMercedesSetProgress(0,1,'Zlecanie pobierania danych Mercedes…');
  try{
    // Kliknięcie użytkownika zawsze tworzy świeże zlecenia. Eliminuje stare WORKING po zamkniętej karcie.
    const r=await api('/api/products/mercedes-enrich-many',{method:'POST',body:JSON.stringify({ids,only_missing:onlyMissing,force:true})});
    const items=r.items||[],skipped=r.skipped_items||[];
    if($('bulkMercedesItems'))$('bulkMercedesItems').innerHTML=items.map(x=>bulkMercedesRow(x)).join('')+skipped.map(x=>bulkMercedesRow({id:x.id,oem:'ID '+x.id},'error')).join('');
    if(!items.length){bulkMercedesSetProgress(0,1,'Brak pozycji wymagających uzupełnienia');toast('Brak pozycji wymagających uzupełnienia');return}
    bulkMercedesSetProgress(0,items.length,`Zlecono ${items.length} pozycji. Portale Mercedes zostały uruchomione.`);
    const wanted=new Set(items.map(x=>+x.id));
    for(let round=0;round<150;round++){
      await sleep(2000);
      const d=await api('/api/products?active=1&sort=name&dir=asc');const map=new Map((d.products||[]).map(p=>[+p.id,p]));let finished=0,success=0,errors=0;
      wanted.forEach(id=>{
        const p=map.get(id),row=document.querySelector(`[data-bulk-product="${id}"]`);if(!p||!row)return;
        const pi=String(p.pi_request_status||'').toUpperCase(),bb=String(p.b2b_request_status||'').toUpperCase();
        const piEnd=['DONE','ERROR'].includes(pi),bbEnd=['DONE','ERROR'].includes(bb);const terminal=piEnd&&bbEnd;
        const image=!!p.preview_image;const nm=String(p.name||'').trim();const goodName=!!nm&&!['do weryfikacji','część mercedes','czesc mercedes'].includes(nm.toLowerCase())&&!/^Mercedes-Benz OEM /i.test(nm);
        if(terminal){finished++;if(pi==='ERROR'&&bb==='ERROR'){errors++;bulkRowState(row,'error',`Błąd PI i B2B · ${p.pi_request_error||''} ${p.b2b_request_error||''}`.trim())}else{success++;const bits=[goodName?'nazwa ✓':'nazwa —',image?'zdjęcie/rysunek ✓':'brak zdjęcia w katalogu'];if(pi==='ERROR')bits.push('PI błąd');if(bb==='ERROR')bits.push('B2B błąd');bulkRowState(row,'done',bits.join(' · '))}}
        else bulkRowState(row,'queued',`PI ${pi||'oczekuje'} · B2B ${bb||'oczekuje'} · ${goodName?'nazwa ✓':'nazwa…'} · ${image?'obraz ✓':'obraz…'}`);
      });
      bulkMercedesSetProgress(finished,wanted.size,finished===wanted.size?`Zakończono ${finished}/${wanted.size} · poprawnie ${success} · błędy ${errors}`:`Przetworzono ${finished}/${wanted.size} · Mercedes pracuje…`);
      try{if(typeof loadProductsSorted==='function')await loadProductsSorted(false);else if(typeof loadProductsAudited==='function')await loadProductsAudited(false)}catch(_){}
      if(finished===wanted.size)break;
    }
  }catch(e){bulkMercedesSetProgress(0,1,'Nie udało się uruchomić zbiorczego pobierania');toast('Błąd zbiorczego pobierania danych Mercedes')}
}
runBulkMercedes=runBulkMercedes1524;
if($('bulkMercedesSelected'))$('bulkMercedesSelected').onclick=()=>runBulkMercedes1524([...S.selectedProductIds],false);
if($('bulkMercedesMissing'))$('bulkMercedesMissing').onclick=()=>runBulkMercedes1524([],true);

// Dokument z zaznaczonych pozycji kartoteki.
function docSelectedIds(){return [...(S.selectedProductIds||new Set())].map(Number).filter(Boolean)}
async function openBulkDocument(){
  const ids=docSelectedIds();if(!ids.length){toast('Zaznacz co najmniej jedną pozycję');return}
  const d=await api('/api/products?active=1&sort=name&dir=asc');const map=new Map((d.products||[]).map(p=>[+p.id,p]));const rows=ids.map(id=>map.get(id)).filter(Boolean);
  if(!rows.length){toast('Nie znaleziono zaznaczonych pozycji');return}
  $('bulkDocDate').value=new Date().toISOString().slice(0,10);$('bulkDocRef').value='';$('bulkDocMoto').value='';$('bulkDocNotes').value='';$('bulkDocType').value='RW';$('bulkDocCount').textContent=rows.length+' poz.';
  $('bulkDocItems').innerHTML=rows.map(p=>`<div class="bulk-doc-line" data-doc-product="${p.id}"><div><b>${esc(p.name||'Bez nazwy')}</b><span class="code">${esc(p.oem_no||p.sku||p.barcode||('ID '+p.id))}</span></div><div class="stock">stan ${(+p.stock_qty||0).toFixed(2)} ${esc(p.unit||'szt.')}</div><div><input type="number" min="0.01" step="0.01" value="1" data-doc-qty="${p.id}" aria-label="Ilość"></div></div>`).join('');
  $('bulkDocHint').textContent='Dla RW/WZ system nie pozwoli wydać więcej niż aktualny stan. PZ zwiększa stan.';$('bulkDocumentModal').classList.add('show');
}
if($('bulkDocumentBtn'))$('bulkDocumentBtn').onclick=openBulkDocument;
if($('bulkDocumentForm'))$('bulkDocumentForm').onsubmit=async e=>{
  e.preventDefault();const btn=e.submitter||e.target.querySelector('button[type=submit]');if(btn)btn.disabled=true;
  try{
    const items=[...$('bulkDocItems').querySelectorAll('[data-doc-product]')].map(r=>({product_id:+r.dataset.docProduct,quantity:+r.querySelector('[data-doc-qty]').value||0})).filter(x=>x.product_id&&x.quantity>0);
    const payload={doc_type:$('bulkDocType').value,doc_date:$('bulkDocDate').value,reference_no:$('bulkDocRef').value,motowarsztat_order_no:$('bulkDocMoto').value,notes:$('bulkDocNotes').value,items};
    const r=await api('/api/document/create-from-products',{method:'POST',body:JSON.stringify(payload)});$('bulkDocumentModal').classList.remove('show');toast(`Wystawiono ${r.document_no} · ${r.lines} poz.`);S.selectedProductIds.clear();try{stableSelectionUi()}catch(_){};try{if(typeof loadProductsSorted==='function')await loadProductsSorted(false);else await loadProducts()}catch(_){};try{await loadDocuments()}catch(_){}
  }catch(err){if(err?.code==='insufficient_stock')toast(`Za mały stan magazynowy: ${err.product||''}`);else toast('Nie udało się wystawić dokumentu')}finally{if(btn)btn.disabled=false}
};

const _sel1524=stableSelectionUi;
stableSelectionUi=function(){_sel1524();if($('bulkDocumentBtn'))$('bulkDocumentBtn').disabled=!docSelectedIds().length};stableSelectionUi();

// Domknij obsługę nowych elementów modalnych.
document.querySelectorAll('[data-close="bulkDocumentModal"]').forEach(b=>b.onclick=()=>$('bulkDocumentModal')?.classList.remove('show'));
})();
