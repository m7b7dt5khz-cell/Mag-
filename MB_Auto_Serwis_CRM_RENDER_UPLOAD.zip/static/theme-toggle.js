(() => {
  'use strict';
  const KEY = 'mbas_theme';
  const root = document.documentElement;
  let restoring = false;

  function validTheme(value){ return value === 'dark' || value === 'light'; }
  function readLocalTheme(){
    try { const value = localStorage.getItem(KEY); if (validTheme(value)) return value; } catch (_) {}
    return null;
  }
  function writeLocalTheme(theme){
    try { localStorage.setItem(KEY, theme); } catch (_) {}
  }
  function syncButton(theme){
    const btn = document.getElementById('themeToggle');
    if (!btn) return;
    const isDark = theme === 'dark';
    btn.textContent = isDark ? 'Motyw: Ciemny' : 'Motyw: Jasny';
    btn.setAttribute('aria-pressed', isDark ? 'true' : 'false');
    btn.title = isDark ? 'Przełącz na jasny motyw' : 'Przełącz na ciemny motyw';
  }
  async function saveServerTheme(theme){
    try {
      await fetch('/api/ui-preferences', {
        method:'POST', cache:'no-store', keepalive:true,
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({theme})
      });
    } catch (_) {}
  }
  function applyTheme(theme, persist = true){
    const next = theme === 'dark' ? 'dark' : 'light';
    root.setAttribute('data-theme', next);
    syncButton(next);
    if (persist && !restoring){ writeLocalTheme(next); saveServerTheme(next); }
  }
  async function restoreTheme(){
    restoring = true;
    try {
      const local = readLocalTheme();
      if (validTheme(local)) applyTheme(local, false);
      const r = await fetch('/api/ui-preferences', {cache:'no-store'});
      const d = await r.json();
      const server = d && d.preferences && d.preferences.theme;
      if (validTheme(server)) { applyTheme(server, false); writeLocalTheme(server); }
    } catch (_) {
      const local = readLocalTheme();
      if (validTheme(local)) applyTheme(local, false);
    } finally { restoring = false; syncButton(root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'); }
  }

  const local = readLocalTheme();
  if (validTheme(local)) applyTheme(local, false);
  restoreTheme();

  document.addEventListener('DOMContentLoaded', () => {
    syncButton(root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');
    document.getElementById('themeToggle')?.addEventListener('click', () => {
      applyTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', true);
    });
  });

  window.MBAutoTheme = { apply: applyTheme, current: () => root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light', restore: restoreTheme };
})();
