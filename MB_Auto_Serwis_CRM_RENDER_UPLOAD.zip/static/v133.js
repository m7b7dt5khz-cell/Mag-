/* MB Auto Serwis 13.3 — szybkie katalogowanie części */
(()=>{
'use strict';
const QC={entries:[],timer:null};
const e=id=>document.getElementById(id);
const fmtDate=v=>String(v||'').replace('T',' ').slice(0,16)||'—';
const stateLabel=s=>({READY:'Gotowe',VERIFY:'Do weryfikacji',WORKING:'W trakcie',QUEUED:'Oczekuje',PARTIAL:'Częściowo',NEW:'Nowa'}[s]||s||'—');
const sourceLabel=(status,error,warning)=>{
  const s=String(status||'').toUpperCase();
  if(s==='DONE')return `<span class="qc-source-status ok">✓ pobrano</span>${warning?`<span class="qc-source-status">${esc(warning)}</span>`:''}`;
  if(s==='WORKING')return '<span class="qc-source-status">odczytuję…</span>';
  if(s==='PENDING')return '<span class="qc-source-status">oczekuje w kolejce</span>';
  if(s==='ERROR')return `<span class="qc-source-status err">${esc(error||'błąd odczytu')}</span>`;
  return '<span class="qc-source-status">—</span>';
};
function canQuickEdit(){return typeof can125==='function'?can125('products_edit'):true}
function setPortal(el,portal,label){if(!el)return;const on=!!portal?.online;el.classList.toggle('online',on);el.classList.toggle('offline',!on);el.textContent=`${label}: ${on?'ONLINE':'OFFLINE'}`;el.title=portal?.last_seen?`Ostatni sygnał: ${fmtDate(portal.last_seen)}`:'Brak sygnału rozszerzenia'}
function quickFiltered(){const q=String(e('quickCatalogSearch')?.value||'').trim().toUpperCase().replace(/[\s.\-]/g,''),st=e('quickCatalogStatus')?.value||'';return QC.entries.filter(x=>{if(st&&x.state!==st)return false;if(!q)return true;const blob=[x.requested_oem,x.oem_no,x.sku,x.latest_oem,x.name,x.location_code].join(' ').toUpperCase().replace(/[\s.\-]/g,'');return blob.includes(q)})}
function renderQuickCatalog(){
  const rows=quickFiltered();
  e('quickCatalogBody').innerHTML=rows.length?rows.map(x=>{
    const av=String(x.mb_status_code||'').toUpperCase();const avLabel={DEALER:'Dostępne u dealera',CENTRAL:'Magazyn centralny',GERMANY:'Dostępne w Niemczech',UNAVAILABLE:'Niedostępne',UNKNOWN:'Status nieustalony'}[av]||'—';
    const edit=canQuickEdit()?`<button class="btn mini" data-qc-retry="${x.id}">Ponów</button><button class="btn mini" data-qc-remove="${x.id}">Usuń z kolejki</button>`:'';
    return `<tr data-qc-id="${x.id}"><td><button class="qc-oem" data-qc-copy="${esc(x.requested_oem)}" title="Kliknij, aby skopiować">${esc(x.requested_oem)}</button><span class="qc-sub">dodano ${esc(fmtDate(x.created_at))}</span></td><td><span class="qc-name">${esc(x.name||'—')}</span>${x.category?`<span class="qc-sub">${esc(x.category)}</span>`:''}<span class="qc-sub">Kartoteka #${x.product_id}${x.active?'':' · archiwalna'}</span><span class="qc-state ${esc(x.state)}">${esc(stateLabel(x.state))}</span></td><td>${sourceLabel(x.pi_status,x.pi_error,x.pi_warning)}${x.pi_attempts&&['PENDING','WORKING'].includes(String(x.pi_status||'').toUpperCase())?`<span class="qc-source-status">próba ${esc(x.pi_attempts)}/3</span>`:''}${x.diagram_position?`<span class="qc-source-status ok">poz. ${esc(x.diagram_position)}${x.has_diagram?' · rysunek ✓':''}</span>`:''}</td><td>${sourceLabel(x.b2b_status,x.b2b_error,'')}<span class="qc-source-status ${av==='UNAVAILABLE'?'err':av&&av!=='UNKNOWN'?'ok':''}">${esc(avLabel)}</span>${x.mb_checked_at?`<span class="qc-source-status">${esc(fmtDate(x.mb_checked_at))}</span>`:''}</td><td>${x.latest_oem&&String(x.latest_oem)!==String(x.oem_no)?`<button class="qc-latest" data-qc-copy="${esc(x.latest_oem)}" title="Kliknij, aby skopiować">${esc(x.latest_oem)}</button>`:'<span class="qc-sub">—</span>'}</td><td>${esc(x.location_code||'—')}</td><td><div class="qc-actions"><button class="btn mini primary" data-qc-open="${x.product_id}">Otwórz</button><button class="btn mini" data-qc-label="${x.id}">Etykieta</button>${edit}</div></td></tr>`
  }).join(''):'<tr><td colspan="7"><div class="empty-state">Brak pozycji w tej kolejce.</div></td></tr>';
  document.querySelectorAll('[data-qc-copy]').forEach(b=>b.onclick=async()=>{try{await navigator.clipboard.writeText(b.dataset.qcCopy);toast(`Skopiowano ${b.dataset.qcCopy}`)}catch(_){toast('Nie udało się skopiować numeru')}});
  document.querySelectorAll('[data-qc-open]').forEach(b=>b.onclick=()=>openProductDetail(+b.dataset.qcOpen));
  document.querySelectorAll('[data-qc-retry]').forEach(b=>b.onclick=()=>retryQuick(+b.dataset.qcRetry));
  document.querySelectorAll('[data-qc-remove]').forEach(b=>b.onclick=()=>removeQuick(+b.dataset.qcRemove));
  document.querySelectorAll('[data-qc-label]').forEach(b=>b.onclick=()=>printQuickLabel(+b.dataset.qcLabel));
}
async function loadQuickCatalog(silent=false){
  try{
    const d=await api('/api/quick-catalog');QC.entries=d.entries||[];
    e('quickCatalogSummary').textContent=`${QC.entries.length} pozycji`;
    const c=d.counts||{};e('qcReady').textContent=c.READY||0;e('qcWorking').textContent=(c.WORKING||0)+(c.QUEUED||0)+(c.PARTIAL||0);e('qcVerify').textContent=c.VERIFY||0;
    const pi=(d.portals||[]).find(x=>String(x.source).toUpperCase()==='PARTSINFO'),bb=(d.portals||[]).find(x=>['B2B','XENTRY'].includes(String(x.source).toUpperCase()));setPortal(e('qcPiPortal'),pi,'Parts Information');setPortal(e('qcB2bPortal'),bb,'B2B');
    const sel=e('quickCatalogLocation'),old=sel.value;sel.innerHTML='<option value="">— bez lokalizacji —</option>'+((d.locations||[]).map(l=>`<option value="${l.id}">${esc(l.code||'')} ${esc(l.name||'')}</option>`).join(''));sel.value=old;
    renderQuickCatalog();
  }catch(err){if(!silent)toast('Nie udało się pobrać kolejki katalogowania')}
}
async function addQuickCatalog(){
  if(!canQuickEdit())return toast('Brak uprawnienia do tworzenia kartoteki części');const codes=e('quickCatalogCodes')?.value.trim()||'';if(!codes)return toast('Wpisz co najmniej jeden numer części');
  const b=e('quickCatalogAdd');b.disabled=true;b.textContent='Dodaję i zlecam odczyt…';
  try{const r=await api('/api/quick-catalog/add',{method:'POST',body:JSON.stringify({codes_text:codes,location_id:e('quickCatalogLocation')?.value||null,min_qty:e('quickCatalogMin')?.value||0,stock_qty:e('quickCatalogStock')?.value,auto_location:e('quickCatalogAutoLocation')?.checked!==false,source:'MANUAL'})});toast(`Dodano ${r.created||0} nowych · ${r.existing||0} istniejących · ${r.queued||0} w kolejce`);e('quickCatalogCodes').value='';await loadQuickCatalog();try{if(typeof loadProductsSorted==='function')await loadProductsSorted(false);else if(typeof loadProducts==='function')await loadProducts()}catch(_){}}catch(err){const msg=err?.code==='no_codes'?'Nie znaleziono poprawnych numerów w podanym tekście':(err?.message||err?.code||'Nie udało się dodać numerów');toast(`Szybkie katalogowanie: ${msg}`)}finally{b.disabled=false;b.textContent='Dodaj i pobierz dane Mercedes'}
}
async function retryQuick(id){try{await api(`/api/quick-catalog/${id}/retry`,{method:'POST',body:'{}'});toast('Ponowiono Parts Information i B2B');await loadQuickCatalog()}catch(_){toast('Nie udało się ponowić odczytu')}}
async function removeQuick(id){if(!confirm('Usunąć pozycję z kolejki katalogowania? Kartoteka produktu pozostanie.'))return;try{await api(`/api/quick-catalog/${id}`,{method:'DELETE'});await loadQuickCatalog()}catch(_){toast('Nie udało się usunąć z kolejki')}}
function printQuickLabel(id){const x=QC.entries.find(z=>+z.id===+id);if(!x)return;const newest=x.latest_oem||x.oem_no||x.requested_oem;e('quickLabelOem').textContent=newest;e('quickLabelName').textContent=x.name||'Część Mercedes-Benz';const prior=newest!==x.requested_oem?`Numer wejściowy: ${x.requested_oem} · `:'';e('quickLabelMeta').textContent=`${prior}Lokalizacja: ${x.location_code||'—'}`;document.body.classList.add('printing-quick-label');setTimeout(()=>{window.print();setTimeout(()=>document.body.classList.remove('printing-quick-label'),400)},80)}
function quickPage(){document.querySelectorAll('main > section[id$="Page"]').forEach(x=>x.classList.toggle('hidden',x.id!=='quickCatalogPage'));document.querySelectorAll('nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page==='quickCatalog'));e('title').textContent='Szybkie katalogowanie części';loadQuickCatalog();applyPermissions133()}
function applyPermissions133(){const can=canQuickEdit();['quickCatalogAdd','quickCatalogRetryErrors'].forEach(id=>{if(e(id))e(id).classList.toggle('hidden',!can)})}
const prevPage=window.page;window.page=function(p){if(p==='quickCatalog'){quickPage();return}prevPage(p);if(e('quickCatalogPage'))e('quickCatalogPage').classList.add('hidden')};document.querySelectorAll('nav [data-page]').forEach(b=>b.onclick=()=>window.page(b.dataset.page));
const prevPerm=window.applyPermissions125;if(typeof prevPerm==='function')window.applyPermissions125=function(){prevPerm();applyPermissions133()};
if(e('quickCatalogNav'))e('quickCatalogNav').onclick=ev=>{ev?.preventDefault?.();quickPage()};if(e('quickCatalogAdd'))e('quickCatalogAdd').onclick=ev=>{ev?.preventDefault?.();addQuickCatalog()};e('quickCatalogRefresh')?.addEventListener('click',()=>loadQuickCatalog());e('quickCatalogRetryErrors')?.addEventListener('click',async()=>{try{const r=await api('/api/quick-catalog/retry-errors',{method:'POST',body:'{}'});toast(`Ponowiono ${r.queued||0} pozycji`);await loadQuickCatalog()}catch(_){toast('Nie udało się ponowić błędów')}});e('quickCatalogSearch')?.addEventListener('input',renderQuickCatalog);e('quickCatalogStatus')?.addEventListener('change',renderQuickCatalog);
e('quickCatalogPaste')?.addEventListener('click',async()=>{try{const tx=await navigator.clipboard.readText();e('quickCatalogCodes').value=tx;toast('Wklejono ze schowka')}catch(_){e('quickCatalogCodes').focus();toast('Wklej numery klawiszami Ctrl+V')}});
e('quickCatalogFile')?.addEventListener('change',ev=>{const f=ev.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{e('quickCatalogCodes').value=String(r.result||'');toast('Wczytano listę — sprawdź i kliknij „Dodaj”')};r.readAsText(f,'utf-8')});
QC.timer=setInterval(()=>{if(e('quickCatalogPage')&&!e('quickCatalogPage').classList.contains('hidden'))loadQuickCatalog(true)},5000);
})();
