// MB Auto Serwis 15.3.3 STABLE — stabilizacja katalogowania, Chrome, dokumentów i Sklep BETA.
(function(){
'use strict';
const el=id=>document.getElementById(id);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

// 1) Zbiorcze dane Mercedes — zawsze zamykalne.
let bulkDismissed=false;
function closeBulkMercedes(){bulkDismissed=true;el('bulkMercedesPanel')?.classList.add('hidden')}
if(el('bulkMercedesClose')){el('bulkMercedesClose').type='button';el('bulkMercedesClose').onclick=closeBulkMercedes}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!el('bulkMercedesPanel')?.classList.contains('hidden'))closeBulkMercedes()});
document.addEventListener('pointerdown',e=>{const p=el('bulkMercedesPanel');if(!p||p.classList.contains('hidden')||p.contains(e.target)||e.target.closest?.('#bulkMercedesSelected,#bulkMercedesMissing'))return;closeBulkMercedes()},{capture:true});

// 2) Ilość przy pobieraniu danych konkretnej części = STAN DOCELOWY, nigdy minimum.
const _openDetail1530=typeof openProductDetail==='function'?openProductDetail:null;
if(_openDetail1530){
  openProductDetail=async function(id){
    await _openDetail1530(id);
    const q=el('detailEnrichStockQty');if(q)q.value='';
    const btn=el('detailEnrichB2b');if(!btn||btn.dataset.stock1530==='1')return;
    const old=btn.onclick;btn.dataset.stock1530='1';
    btn.onclick=async ev=>{
      const raw=String(el('detailEnrichStockQty')?.value??'').trim();
      if(raw!==''){
        const qty=Number(raw.replace(',','.'));if(!Number.isFinite(qty)||qty<0){toast('Wpisz prawidłowy stan magazynowy');el('detailEnrichStockQty')?.focus();return}
        const pid=+(S.detailProduct?.product?.id||id||0);if(pid){
          try{const r=await api(`/api/product/${pid}/stock-target`,{method:'POST',body:JSON.stringify({quantity:qty,reference_no:'KATALOGOWANIE',note:'Stan ustawiony przy pobieraniu danych Mercedes'})});toast(`Stan magazynowy ustawiony na ${qty} szt.`);if(S.detailProduct?.product)S.detailProduct.product.stock_qty=qty;if(el('detailStock'))el('detailStock').textContent=`${qty.toFixed(2)} ${S.detailProduct?.product?.unit||'szt.'}`;}catch(_){toast('Nie udało się ustawić stanu magazynowego');return}
        }
      }
      if(typeof old==='function')return old.call(btn,ev);
    };
  };
}

// 3) Produkt -> sklep BETA. Zapis jest odseparowany od głównej kartoteki.
const _openProduct1530=typeof openProduct==='function'?openProduct:null;
if(_openProduct1530){
  openProduct=function(id=null){
    _openProduct1530(id);const p=id?S.products.find(x=>+x.id===+id):null;
    if(el('woo_publish_enabled'))el('woo_publish_enabled').checked=!!p?.woo_publish_enabled;
    if(el('wooProductState'))el('wooProductState').textContent=p?.woo_sync_status||'Niepublikowany';
  };
}
if(el('productForm'))el('productForm').onsubmit=async e=>{
  e.preventDefault();const d={};['sku','oem_no','barcode','name','category','supplier_id','location_id','min_qty','purchase_price','sale_price','pricing_mode','margin_pct','vat_rate','sell_price_net','unit','diagram_position'].forEach(k=>d[k]=el(k)?.value??'');d.aliases=el('productAliasesInput')?.value||'';d.notes=el('product_notes')?.value||'';d.expected_updated_at=el('productForm').dataset.expectedUpdatedAt||'';
  try{
    const id=el('productId').value;const r=id?await api('/api/product/'+id,{method:'PUT',body:JSON.stringify(d)}):await api('/api/product',{method:'POST',body:JSON.stringify(d)});const pid=+(id||r.id||0);
    if(pid)await api('/api/shop-beta/product',{method:'POST',body:JSON.stringify({product_id:pid,enabled:!!el('woo_publish_enabled')?.checked})}).catch(()=>{});
    el('productModal').classList.remove('show');toast('Część zapisana');await Promise.all([loadProducts(),loadSummary()]);if(!id&&r.id)setTimeout(()=>openProductDetail(r.id),250);
  }catch(err){toast(err.code==='edit_conflict'?'Kartoteka została zmieniona. Otwórz ją ponownie.':err.code==='duplicate_code'?'SKU/OEM/kod już istnieje':'Nie udało się zapisać')}
};

// 4) WooCommerce BETA — test domyślnie bez jakiejkolwiek publikacji.
const _loadIntegrationSettings1530=typeof loadIntegrationSettings==='function'?loadIntegrationSettings:null;
loadIntegrationSettings=async function(){
  if(_loadIntegrationSettings1530)await _loadIntegrationSettings1530();
  try{const d=await api('/api/integrations/settings');if(el('woo_catalog_beta_enabled'))el('woo_catalog_beta_enabled').checked=!!d.woo_catalog_beta_enabled;if(el('woo_catalog_status'))el('woo_catalog_status').value=d.woo_catalog_status||'draft';if(el('woo_catalog_price_mode'))el('woo_catalog_price_mode').value=d.woo_catalog_price_mode||'gross'}catch(_){ }
};
saveIntegrationSettings=async function(){
  const data={woo_url:el('woo_url').value,woo_key:el('woo_key').value,woo_secret:el('woo_secret').value,woo_auto_enabled:el('woo_auto_enabled').checked,woo_auto_minutes:+el('woo_auto_minutes').value||10,woo_catalog_beta_enabled:!!el('woo_catalog_beta_enabled')?.checked,woo_catalog_status:el('woo_catalog_status')?.value||'draft',woo_catalog_price_mode:el('woo_catalog_price_mode')?.value||'gross',ic_base_url:el('ic_base_url').value,ic_token_url:el('ic_token_url').value,ic_client_id:el('ic_client_id').value,ic_client_secret:el('ic_client_secret').value,ic_location:el('ic_location')?.value||'',ic_ship_to:el('ic_ship_to')?.value||''};
  await api('/api/integrations/settings',{method:'POST',body:JSON.stringify(data)});['woo_key','woo_secret','ic_client_id','ic_client_secret'].forEach(id=>{if(el(id))el(id).value=''});toast('Ustawienia zapisane');await loadIntegrationSettings();
};
async function shopBetaPreview(priceOnly=false){
  try{const d=await api(priceOnly?'/api/shop-beta/update-prices':'/api/shop-beta/preview',{method:'POST',body:JSON.stringify({dry_run:true})});const items=d.items||[];let box=el('shopBetaResult1530');if(!box){box=document.createElement('div');box.id='shopBetaResult1530';box.className='shop-beta-result';el('wooBetaPreview')?.closest('.shop-beta-box')?.appendChild(box)}box.innerHTML=`<b>TEST — ${items.length} produktów</b>`+items.slice(0,20).map(x=>`<div>${x.product_id||''} · ${esc(x.payload?.sku||'')} · ${esc(x.payload?.name||'')} · ${esc(x.payload?.regular_price||'')} zł ${x.image_ready===false?'· brak publicznego URL zdjęcia':''}</div>`).join('')+(items.length>20?`<small>… i ${items.length-20} kolejnych</small>`:'');toast('Podgląd BETA gotowy — nic nie zostało wysłane do sklepu')}catch(_){toast('Nie udało się przygotować podglądu sklepu')}
}
el('wooBetaPreview')?.addEventListener('click',()=>shopBetaPreview(false));el('wooBetaPricePreview')?.addEventListener('click',()=>shopBetaPreview(true));

// 5) Dokumenty — automatyczne odświeżanie po imporcie z B2B/rachunku.
let docRefreshBusy=false;setInterval(async()=>{if(docRefreshBusy||!el('documentsPage')||el('documentsPage').classList.contains('hidden'))return;docRefreshBusy=true;try{if(typeof loadDocuments==='function')await loadDocuments()}catch(_){}finally{docRefreshBusy=false}},7000);

// 6) Po zakończeniu katalogowania odśwież kartotekę także bez F5.
const qcBtn=el('quickCatalogAdd');if(qcBtn)qcBtn.addEventListener('click',()=>setTimeout(async()=>{try{if(typeof loadProductsSorted==='function')await loadProductsSorted(false);else if(typeof loadProducts==='function')await loadProducts();if(typeof loadSummary==='function')await loadSummary()}catch(_){}},1200));

// Drobny opis procesu — użytkownik skanuje numer, podaje stan, dopiero potem pobiera dane.
if(el('quickCatalogStock'))el('quickCatalogStock').title='Faktyczna liczba sztuk, która ma znaleźć się na stanie po katalogowaniu';
// 7) Realna synchronizacja sklepu jest zablokowana, dopóki użytkownik świadomie nie włączy BETA.
function syncBetaButtons(){const on=!!el('woo_catalog_beta_enabled')?.checked;['wooBetaSync','wooBetaSyncPrices'].forEach(id=>{if(el(id))el(id).disabled=!on})}
el('woo_catalog_beta_enabled')?.addEventListener('change',syncBetaButtons);setTimeout(syncBetaButtons,0);
async function runRealShopBeta(priceOnly=false){
  if(!el('woo_catalog_beta_enabled')?.checked){toast('Najpierw włącz Sklep BETA w ustawieniach');return}
  const msg=priceOnly?'Zaktualizować ceny i stany w WooCommerce dla zaznaczonych do sklepu produktów?':'Wysłać produkty oznaczone do sklepu do WooCommerce?';
  if(!window.confirm(msg))return;
  try{const d=await api(priceOnly?'/api/shop-beta/update-prices':'/api/shop-beta/sync',{method:'POST',body:JSON.stringify({dry_run:false})});const ok=(d.items||[]).filter(x=>x.ok).length,err=(d.items||[]).filter(x=>x.ok===false).length;toast(`WooCommerce BETA: OK ${ok}, błędy ${err}`);await loadProducts()}catch(e){toast(e?.code==='beta_disabled'?'Sklep BETA jest wyłączony':'Błąd synchronizacji WooCommerce BETA')}
}
el('wooBetaSync')?.addEventListener('click',()=>runRealShopBeta(false));el('wooBetaSyncPrices')?.addEventListener('click',()=>runRealShopBeta(true));

})();
