const $=id=>document.getElementById(id);
const S={csrf:null,setup:false,products:[],suppliers:[],locations:[],contractors:[],editing:null,detailProduct:null,icResults:[],issues:[],availabilityTimer:null};
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}
function money(v){return new Intl.NumberFormat("pl-PL",{style:"currency",currency:"PLN",maximumFractionDigits:2}).format(+v||0)}
function toast(t){$("toast").textContent=t;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2200)}
async function api(url,opt={}){opt.headers=Object.assign({"Content-Type":"application/json"},opt.headers||{});if(S.csrf&&["POST","PUT","DELETE"].includes((opt.method||"GET").toUpperCase()))opt.headers["X-CSRF-Token"]=S.csrf;const r=await fetch(url,opt);if(r.status===401){showAuth(false);throw new Error("unauthorized")}const d=await r.json();if(!r.ok)throw Object.assign(new Error(d.error||"Błąd"),{code:d.error,data:d});return d}
function showAuth(setup){S.setup=setup;$("app").classList.add("hidden");$("auth").classList.remove("hidden");$("password2").classList.toggle("hidden",!setup);$("authBtn").textContent=setup?"Utwórz konto administratora":"Zaloguj";$("authText").textContent=setup?"Pierwsze uruchomienie — ustaw hasło":"System magazynowy";$("password").value="";$("password2").value=""}
function showApp(){$("auth").classList.add("hidden");$("app").classList.remove("hidden")}
$("authForm").onsubmit=async e=>{e.preventDefault();const p=$("password").value;try{let d;if(S.setup){if(p.length<10)return toast("Hasło: minimum 10 znaków");if(p!==$("password2").value)return toast("Hasła nie są identyczne");d=await api("/api/setup",{method:"POST",body:JSON.stringify({password:p})})}else d=await api("/api/login",{method:"POST",body:JSON.stringify({password:p})});S.csrf=d.csrf;showApp();await loadAll()}catch(e){toast(e.code==="invalid_login"?"Nieprawidłowe hasło":"Błąd logowania")}}
async function boot(){const s=await api("/api/session");if(s.setup_required)return showAuth(true);if(!s.logged_in)return showAuth(false);S.csrf=s.csrf;showApp();await loadAll()}
async function loadAll(){await Promise.all([loadSuppliers(),loadLocations(),loadContractors()]);await Promise.all([loadProducts(),loadMovements(),loadDocuments(),loadSummary(),loadIntegrationSettings()])}

async function loadSuppliers(){const d=await api("/api/suppliers");S.suppliers=d.suppliers;const opts='<option value="">— brak —</option>'+S.suppliers.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("");$("supplier_id").innerHTML=opts;$("move_supplier_id").innerHTML=opts;$("suppliersList").innerHTML=S.suppliers.length?S.suppliers.map(x=>`<div class="listitem"><div><b>${esc(x.name)}</b><br><small>${esc(x.phone||"")} ${esc(x.email||"")}</small></div><small>${esc(x.nip||"")}</small></div>`).join(""):'<div class="hint">Brak dostawców.</div>'}
async function loadLocations(){const d=await api("/api/locations");S.locations=d.locations;$("location_id").innerHTML='<option value="">— brak —</option>'+S.locations.map(x=>`<option value="${x.id}">${esc(x.code)} · ${esc(x.name||"")}</option>`).join("");$("locationsList").innerHTML=S.locations.length?S.locations.map(x=>`<div class="listitem"><div><b>${esc(x.code)}</b><br><small>${esc(x.name||"")}</small></div><div><button class="btn mini" data-location-edit="${x.id}">Edytuj</button><button class="btn mini danger" data-location-del="${x.id}">Usuń</button></div></div>`).join(""):'<div class="hint">Brak lokalizacji.</div>';document.querySelectorAll("[data-location-edit]").forEach(b=>b.onclick=()=>editLocation(+b.dataset.locationEdit));document.querySelectorAll("[data-location-del]").forEach(b=>b.onclick=()=>deleteLocation(+b.dataset.locationDel))}
async function loadProducts(){
  const q=encodeURIComponent($("productSearch")?.value||""),low=$("lowOnly")?.checked?"1":"",active=$("productActive")?.value||"1";
  const d=await api(`/api/products?q=${q}&low=${low}&active=${encodeURIComponent(active)}`);S.products=d.products;$("productsLabel").textContent=d.products.length+" indeksów";
  $("productsBody").innerHTML=d.products.map(p=>`<tr class="${p.active?"":"archived-row"}" data-product-row="${p.id}"><td>${esc(p.sku||"—")}</td><td><b>${esc(p.oem_no||"—")}</b>${p.aliases?`<br><small>${esc(p.aliases)}</small>`:""}</td><td><b>${esc(p.name)}</b><br><small>${esc(p.category||"")}</small></td><td>${esc(p.location_code||"—")}</td><td class="${(+p.stock_qty)<= (+p.min_qty)?"low":"ok"}">${(+p.stock_qty).toFixed(2)} ${esc(p.unit)}</td><td>${(+p.min_qty).toFixed(2)}</td><td>${money(p.purchase_price)}</td><td>${money(p.sale_price)}</td><td>${esc(p.supplier_name||"—")}</td><td><span class="badge ${p.active?"completed":"refunded"}">${p.active?"AKTYWNY":"ARCHIWUM"}</span></td><td class="row-actions"><button class="btn mini" data-open-product="${p.id}">Otwórz</button><button class="btn mini" data-edit="${p.id}">Edytuj</button></td></tr>`).join("");
  document.querySelectorAll("[data-open-product]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProductDetail(+b.dataset.openProduct)});
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProduct(+b.dataset.edit)});
  document.querySelectorAll("[data-product-row]").forEach(r=>r.ondblclick=()=>openProductDetail(+r.dataset.productRow));
  refreshMoveProducts();refreshAltProductSelects()
}
function refreshMoveProducts(){const current=$("move_product_id").value;$("move_product_id").innerHTML='<option value="">Wybierz część...</option>'+S.products.map(p=>`<option value="${p.id}">${esc((p.sku||p.oem_no||""))} · ${esc(p.name)} · stan ${(+p.stock_qty).toFixed(2)}</option>`).join("");if(current)$("move_product_id").value=current;updateStockHint()}
function refreshAltProductSelects(){const base=$("altBaseProduct")?.value;const local=$("altLocalProduct")?.value;const opts=S.products.map(p=>`<option value="${p.id}">${esc(p.sku||p.oem_no||"")} · ${esc(p.name)}</option>`).join("");if($("altBaseProduct")){$("altBaseProduct").innerHTML='<option value="">Wybierz część bazową...</option>'+opts;if(base)$("altBaseProduct").value=base}if($("altLocalProduct")){$("altLocalProduct").innerHTML='<option value="">Wybierz lokalny zamiennik...</option>'+opts;if(local)$("altLocalProduct").value=local}}
async function loadMovements(){const q=encodeURIComponent($("moveSearch")?.value||""),typ=encodeURIComponent($("moveTypeFilter")?.value||"");const d=await api(`/api/movements?q=${q}&type=${typ}`);$("movesLabel").textContent=d.movements.length+" ruchów";$("movesBody").innerHTML=d.movements.map(m=>`<tr><td><b>${esc(m.document_no)}</b></td><td>${esc(m.move_date)}</td><td><span class="badge ${esc(m.move_type)}">${esc(m.move_type)}</span></td><td>${esc(m.sku||m.oem_no||"")} · ${esc(m.product_name)}</td><td>${(+m.quantity).toFixed(2)}</td><td>${money(m.unit_price)}</td><td>${esc(m.motowarsztat_order_no||"—")}</td><td>${esc(m.shop_order_no||"—")}</td><td>${esc(m.note||"")}</td></tr>`).join("")}
async function loadDocuments(){
  if(!$("documentsBody"))return;const q=encodeURIComponent($("documentSearch")?.value||""),typ=encodeURIComponent($("documentType")?.value||"");
  const d=await api(`/api/documents?q=${q}&type=${typ}`);$("documentsLabel").textContent=d.documents.length+" dokumentów";
  $("documentsBody").innerHTML=d.documents.map(x=>`<tr><td><div class="doc-hover"><b>${esc(x.document_no)}</b><div class="doc-tooltip"><b>${esc(x.doc_type)} ${esc(x.document_no)}</b><br>Zamówiono / data: ${esc(x.doc_date||"—")}<br>Nr zewnętrzny: ${esc(x.external_no||"—")}<br>Dostawca: ${esc(x.supplier_name||"—")}<br>Źródło: ${esc(x.source||"—")}</div></div></td><td>${esc(x.doc_date)}</td><td><span class="badge ${esc(x.doc_type)}">${esc(x.doc_type)}</span></td><td>${esc(x.external_no||"—")}</td><td>${esc(x.supplier_name||"—")}</td><td>${x.lines||0}</td><td>${money(x.value)}</td><td>${esc(x.source||"—")}</td><td><button class="btn mini" data-doc-open="${x.id}">Podgląd</button></td></tr>`).join("");
  document.querySelectorAll("[data-doc-open]").forEach(b=>b.onclick=()=>openDocument(+b.dataset.docOpen));
}
async function loadSummary(){const d=await api("/api/summary");$("kProducts").textContent=d.kpi.products_count;$("kQty").textContent=(+d.kpi.qty_total).toFixed(2);$("kPurchase").textContent=money(d.kpi.purchase_value);$("kLow").textContent=d.kpi.low_count;$("lowBody").innerHTML=d.low.length?d.low.map(p=>`<tr><td>${esc(p.sku||p.oem_no||"—")}</td><td>${esc(p.name)}</td><td class="low">${(+p.stock_qty).toFixed(2)}</td><td>${(+p.min_qty).toFixed(2)}</td><td>${esc(p.location_code||"—")}</td></tr>`).join(""):'<tr><td colspan="5">Brak alertów.</td></tr>';$("monthMoves").innerHTML=d.month.length?d.month.map(x=>`<div class="moveitem"><b>${esc(x.move_type)}</b><span>${x.cnt} dokumentów · ${money(x.value)}</span></div>`).join(""):'<div class="hint">Brak ruchów w tym miesiącu.</div>'}

function page(p){["dashboard","products","movements","documents","alternatives","integrations","b2b","suppliers","locations","contractors"].forEach(x=>$(x+"Page").classList.toggle("hidden",x!==p));document.querySelectorAll("nav [data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===p));$("title").textContent={dashboard:"Dashboard magazynu",products:"Kartoteka części",movements:"Ruchy magazynowe",documents:"Dokumenty magazynowe",alternatives:"Zamienniki i odpowiedniki",integrations:"Sklep WooCommerce BETA",b2b:"Mercedes B2B Bridge",suppliers:"Dostawcy",locations:"Lokalizacje magazynowe",contractors:"Kontrahenci / NIP"}[p];if(p==="products")loadProducts();if(p==="movements")loadMovements();if(p==="documents")loadDocuments();if(p==="alternatives"){refreshAltProductSelects();if($("altBaseProduct").value)loadAlternatives()}if(p==="integrations"){loadIntegrationSettings();loadIntegrationIssues()}if(p==="b2b"){loadB2bSettings();loadB2bCaptures()}if(p==="contractors"){loadContractors()}}
document.querySelectorAll("nav [data-page]").forEach(b=>b.onclick=()=>page(b.dataset.page));

async function deleteProduct(id){
  const p=S.products.find(x=>x.id===id);if(!p)return;
  if(!confirm(`Usunąć z kartoteki: ${p.name}?\n\nJeśli część ma historię ruchów, zostanie zarchiwizowana zamiast fizycznie usunięta.`))return;
  try{
    const r=await api("/api/product/"+id,{method:"DELETE"});
    toast(r.mode==="archived"?"Towar zarchiwizowany — historia została zachowana":"Towar usunięty z kartoteki");
    await Promise.all([loadProducts(),loadSummary()]);
  }catch(e){toast("Nie udało się usunąć towaru")}
}
async function archiveOrDeleteProduct(id){
  const p=(S.detailProduct?.product?.id===id?S.detailProduct.product:S.products.find(x=>x.id===id));if(!p)return;
  if(!confirm(`Archiwizować/usunąć z kartoteki: ${p.name}?\nHistoria magazynowa nie zostanie utracona.`))return;
  const r=await api("/api/product/"+id,{method:"DELETE"});toast(r.mode==="archived"?"Towar przeniesiony do archiwum":"Towar usunięty");
  $("productDetailModal").classList.remove("show");await Promise.all([loadProducts(),loadSummary()]);
}
async function restoreProduct(id){await api(`/api/product/${id}/restore`,{method:"POST",body:"{}"});toast("Towar przywrócony");await Promise.all([loadProducts(),loadSummary()]);openProductDetail(id)}
function detailTab(name){document.querySelectorAll("[data-detail-tab]").forEach(b=>b.classList.toggle("active",b.dataset.detailTab===name));["history","orders","alts"].forEach(x=>$("detail"+x[0].toUpperCase()+x.slice(1)).classList.toggle("hidden",x!==name))}
document.querySelectorAll("[data-detail-tab]").forEach(b=>b.onclick=()=>detailTab(b.dataset.detailTab));
function mbAvailabilityText(code){return {DEALER:["Dostępne u dealera","Dealer Mercedes"],CENTRAL:["Dostępne","Magazyn centralny Mercedes"],GERMANY:["Dostępne w Niemczech","Magazyn Mercedes Niemcy"],UNAVAILABLE:["Niedostępne","Brak dostępności Mercedes"],UNKNOWN:["Nie rozpoznano statusu","Wtyczka znalazła część, ale nie rozpoznała kropki."],ERROR:["Błąd sprawdzania","Nie udało się odczytać B2B"]}[code]||["Jeszcze nie sprawdzono","Otwórz B2B Connect w Chrome / Edge"]}
function bridgeIsOnline(bridge){
  if(!bridge?.last_seen)return false;
  const t=Date.parse(String(bridge.last_seen).replace(" ","T"));return Number.isFinite(t)&&(Date.now()-t)<30000;
}
function renderMbAvailability(av,req,bridge){
  const online=bridgeIsOnline(bridge);
  const code=(av?.status_code||((req?.status==="PENDING"||req?.status==="WORKING")?"CHECKING":"UNKNOWN")).toUpperCase();
  const icon=$("mbAvIcon");icon.className="mb-av-icon "+code.toLowerCase();
  if(code==="DEALER")icon.textContent="✓";else if(code==="CHECKING")icon.textContent="…";else icon.textContent="";
  if(code==="CHECKING"){
    if(!online){
      $("mbAvTitle").textContent="B2B niepołączone";
      $("mbAvSubtitle").textContent="Nie widzę aktywnej strony B2B. Otwórz B2B Connect i sprawdź token wtyczki.";
    }else{
      $("mbAvTitle").textContent=req?.status==="WORKING"?"Sprawdzam w B2B…":"Oczekiwanie na sprawdzenie…";
      $("mbAvSubtitle").textContent=`Wtyczka aktywna${bridge?.dealer_name?" · "+bridge.dealer_name:""} · ${bridge?.page_title||"B2B Connect"}`;
    }
    $("mbAvTime").textContent=bridge?.last_seen?"B2B "+String(bridge.last_seen).replace("T"," ").slice(11,19):"";
    return
  }
  const [title,sub]=mbAvailabilityText(code);$("mbAvTitle").textContent=title;
  let subtitle=(code==="DEALER"&&av?.dealer_name)?av.dealer_name:(av?.raw_label||sub);
  if(req?.status==="ERROR"&&req?.error)subtitle=req.error;
  if(!online&&(!av||code==="ERROR"||code==="UNKNOWN"))subtitle+=(subtitle?" · ":"")+"Brak aktywnego połączenia z B2B";
  $("mbAvSubtitle").textContent=subtitle;
  $("mbAvTime").textContent=av?.checked_at?"sprawdzono "+String(av.checked_at).replace("T"," ").slice(0,16):(online?"B2B połączone":"");
  if(av?.error&&code!=="UNAVAILABLE")$("mbAvSubtitle").textContent=av.error;
}
async function refreshMbAvailabilityState(pid){try{const d=await api(`/api/product/${pid}/availability`);renderMbAvailability(d.availability,d.request,d.bridge_status);return d}catch(e){return null}}
async function queueMbAvailability(pid,force=false){
  try{
    const state=await refreshMbAvailabilityState(pid);
    const r=await api(`/api/product/${pid}/availability/request`,{method:"POST",body:JSON.stringify({force})});
    if(r.cached){await refreshMbAvailabilityState(pid);return}
    renderMbAvailability(null,{status:r.status||"PENDING"},state?.bridge_status);
    clearInterval(S.availabilityTimer);let ticks=0;
    S.availabilityTimer=setInterval(async()=>{
      ticks++;const d=await refreshMbAvailabilityState(pid);const st=d?.request?.status;
      if(d?.availability&&(!st||st==="DONE")){clearInterval(S.availabilityTimer);S.availabilityTimer=null}
      if(st==="ERROR"||ticks>45){clearInterval(S.availabilityTimer);S.availabilityTimer=null}
    },1000);
  }catch(e){$("mbAvTitle").textContent="Nie można sprawdzić";$("mbAvSubtitle").textContent=e.code==="no_oem"?"Brak numeru OEM w kartotece":"Błąd lokalnego konektora"}
}
async function openProductDetail(id){
 try{const d=await api(`/api/product/${id}/detail`);S.detailProduct=d;const p=d.product;renderMbAvailability(d.availability,d.availability_request,d.bridge_status);$("detailName").textContent=p.name||"Karta produktu";$("detailSubtitle").textContent=`${p.oem_no||p.sku||"bez numeru"} · ${p.active?"aktywny":"zarchiwizowany"}`;
 $("detailStock").textContent=`${(+p.stock_qty).toFixed(2)} ${p.unit}`;$("detailLocation").textContent=p.location_code||"—";$("detailBuy").textContent=money(p.purchase_price);$("detailSale").textContent=money(p.sale_price);
 $("detailMeta").innerHTML=`<div class="detail-name-field"><small>NAZWA TOWARU</small><strong>${esc(p.name||"—")}</strong></div><div><b>Nazwa:</b> ${esc(p.name||"—")}</div><div><b>OEM:</b> ${esc(p.oem_no||"—")}</div><div><b>SKU:</b> ${esc(p.sku||"—")}</div><div><b>Kod skanera:</b> ${esc(p.barcode||"—")}</div><div><b>Dostawca:</b> ${esc(p.supplier_name||"—")}</div><div><b>Kategoria:</b> ${esc(p.category||"—")}</div><div><b>Pozycja na rysunku:</b> ${esc(p.diagram_position||"—")}</div><div><b>Stan min.:</b> ${(+p.min_qty).toFixed(2)}</div><div><b>Źródło Mercedes:</b> B2B / XENTRY</div><div><b>Ceny B2B:</b> ${p.commerce_checked_at?esc(String(p.commerce_checked_at).replace("T"," ").slice(0,16)):"—"}</div><div><b>Integracja Mercedes:</b> B2B / XENTRY</div>`;
 const aliases=[p.oem_no,...d.aliases.map(a=>a.alias_no)].filter(Boolean);$("detailAliases").innerHTML=aliases.length?aliases.map((a,i)=>`<span class="alias-pill ${i===0?"primary":""}">${esc(a)}</span>`).join(""):'<span class="hint">Brak numerów powiązanych.</span>';
 if(p.preview_image){
   $("detailImageWrap").className="product-image-wrap";
   const mx=Number(p.diagram_marker_x),my=Number(p.diagram_marker_y),hasPoint=Number.isFinite(mx)&&Number.isFinite(my)&&mx>=0&&mx<=1&&my>=0&&my<=1;
   const marker=p.diagram_position?`<div class="diagram-marker ${hasPoint?"located":"fallback"}" style="${hasPoint?`left:${(mx*100).toFixed(2)}%;top:${(my*100).toFixed(2)}%`:""}"><span>${esc(p.diagram_position)}</span></div>`:"";
   $("detailImageWrap").innerHTML=`<div class="diagram-stage"><img src="${esc(p.preview_image)}" alt="Rysunek katalogowy Mercedes Parts Information">${marker}<div class="diagram-caption">Pozycja na rysunku: <b>${esc(p.diagram_position||"—")}</b>${hasPoint?" · znacznik przypisany automatycznie":" · numer zapisany, położenie do ręcznej weryfikacji"}</div></div>`;
 }else{$("detailImageWrap").className="product-image-empty";$("detailImageWrap").innerHTML=`Brak rysunku z Mercedes Parts Information${p.diagram_position?`<br><b>Pozycja: ${esc(p.diagram_position)}</b>`:""}`;}
 $("detailHistory").innerHTML=d.movements.length?`<div class="tablewrap"><table class="compact"><thead><tr><th>Data</th><th>Dokument</th><th>Typ</th><th>Ilość</th><th>Cena</th><th>Nr zewn.</th><th>Uwagi</th></tr></thead><tbody>${d.movements.map(m=>`<tr><td>${esc(m.move_date)}</td><td>${esc(m.parent_document_no||m.document_no)}</td><td><span class="badge ${esc(m.move_type)}">${esc(m.move_type)}</span></td><td>${(+m.quantity).toFixed(2)}</td><td>${money(m.unit_price)}</td><td>${esc(m.external_no||m.reference_no||"—")}</td><td>${esc(m.note||"")}</td></tr>`).join("")}</tbody></table></div>`:'<div class="hint">Brak ruchów magazynowych.</div>';
 $("detailOrders").innerHTML=d.documents.length?d.documents.map(x=>`<div class="order-card doc-hover"><div><b>${esc(x.document_no)}</b> · <span class="badge ${esc(x.doc_type)}">${esc(x.doc_type)}</span><br><small>${esc(x.doc_date)} · zewn. ${esc(x.external_no||"—")} · ${esc(x.supplier_name||"—")}</small></div><div><b>${money(x.value)}</b><br><button class="btn mini" data-detail-doc="${x.id}">Podgląd</button></div><div class="doc-tooltip">Zamówiono: ${esc(x.doc_date||"—")}<br>Numer zamówienia zewnętrznego: ${esc(x.external_no||"—")}<br>Dostawca: ${esc(x.supplier_name||"—")}<br>Źródło: ${esc(x.source||"—")}</div></div>`).join(""):'<div class="hint">Brak dokumentów dla tego produktu.</div>';
 $("detailAlts").innerHTML=`<div class="detail-alt-section"><h4>Zamienniki w magazynie</h4>${d.alternatives.length?d.alternatives.map(a=>`<div class="alt-card"><div><b>${esc(a.oem_no||a.sku||"—")} · ${esc(a.name)}</b><small>Stan ${(+a.stock_qty).toFixed(2)} · ${esc(a.location_code||"bez lokalizacji")}</small></div><button class="btn mini" data-open-alt="${a.id}">Otwórz</button></div>`).join(""):'<div class="hint">Brak lokalnych zamienników.</div>'}</div><div class="detail-alt-section"><h4>Zamienniki Inter Cars</h4>${d.external_alternatives.length?d.external_alternatives.map(a=>`<div class="alt-card"><div><b>${esc(a.brand||"")} ${esc(a.external_index||a.external_sku||"")} · ${esc(a.name||"")}</b><small>Stan ${(+a.last_stock||0).toFixed(0)} · netto ${money(a.last_price_net)}</small></div></div>`).join(""):'<div class="hint">Brak zapisanych odpowiedników Inter Cars.</div>'}<button class="btn" id="manageAlternativesDetail">Zarządzaj zamiennikami</button></div>`;
 document.querySelectorAll("[data-detail-doc]").forEach(b=>b.onclick=()=>openDocument(+b.dataset.detailDoc));document.querySelectorAll("[data-open-alt]").forEach(b=>b.onclick=()=>openProductDetail(+b.dataset.openAlt));$("manageAlternativesDetail")?.addEventListener("click",()=>{$("productDetailModal").classList.remove("show");page("alternatives");$("altBaseProduct").value=id;loadAlternatives()});
 $("detailArchive").classList.toggle("hidden",!p.active);$("detailRestore").classList.toggle("hidden",!!p.active);["detailOutRw","detailOutWz","detailInPz"].forEach(k=>$(k).disabled=!p.active);$("detailArchive").onclick=()=>archiveOrDeleteProduct(id);$("detailRestore").onclick=()=>restoreProduct(id);$("detailEdit").onclick=()=>{$("productDetailModal").classList.remove("show");openProduct(id)};$("detailOutRw").onclick=()=>openQuickMovement(id,"RW");$("detailOutWz").onclick=()=>openQuickMovement(id,"WZ");$("detailInPz").onclick=()=>openQuickMovement(id,"PZ");$("mbAvRefresh").onclick=()=>queueMbAvailability(id,true);detailTab("history");$("productDetailModal").classList.add("show")
 }catch(e){toast("Nie udało się otworzyć karty produktu")}
}
function openQuickMovement(pid,type){$("productDetailModal").classList.remove("show");openMovement();setTimeout(()=>{const p=S.products.find(x=>x.id===pid)||S.detailProduct?.product;if(p&&![...$("move_product_id").options].some(o=>+o.value===pid)){$("move_product_id").insertAdjacentHTML("beforeend",`<option value="${p.id}">${esc(p.sku||p.oem_no||"")} · ${esc(p.name)} · stan ${(+p.stock_qty).toFixed(2)}</option>`)}$("move_product_id").value=pid;$("move_type").value=type;if(p)$("unit_price").value=(type==="WZ"?+p.sale_price:+p.purchase_price||0).toFixed(2);updateStockHint();$("quantity").focus();$("quantity").select()},70)}
async function openDocument(id){try{const d=await api("/api/document/"+id),x=d.document;$("documentModalTitle").textContent=`${x.doc_type} ${x.document_no}`;$("documentModalSub").textContent=`${x.doc_date}${x.external_no?" · nr zewn. "+x.external_no:""}${x.supplier_name?" · "+x.supplier_name:""}`;const total=d.lines.reduce((s,l)=>s+Math.abs((+l.quantity||0)*(+l.unit_price||0)),0);$("documentPrintArea").innerHTML=`<div class="print-head"><div><h2>MB AUTO SERWIS</h2><p>Dokument magazynowy</p></div><div><h2>${esc(x.doc_type)} ${esc(x.document_no)}</h2><p>${esc(x.doc_date)}</p></div></div><div class="print-meta"><div><b>Numer zewnętrzny</b><span>${esc(x.external_no||"—")}</span></div><div><b>Dostawca</b><span>${esc(x.supplier_name||"—")}</span></div><div><b>Źródło</b><span>${esc(x.source||"—")}</span></div><div><b>Uwagi</b><span>${esc(x.notes||"—")}</span></div></div><table class="print-table"><thead><tr><th>Lp.</th><th>OEM/SKU</th><th>Nazwa</th><th>Ilość</th><th>Cena</th><th>Wartość</th></tr></thead><tbody>${d.lines.map((l,i)=>`<tr><td>${i+1}</td><td>${esc(l.oem_no||l.sku||"—")}</td><td>${esc(l.product_name)}</td><td>${Math.abs(+l.quantity).toFixed(2)} ${esc(l.unit)}</td><td>${money(l.unit_price)}</td><td>${money(Math.abs((+l.quantity)*(+l.unit_price)))}</td></tr>`).join("")}</tbody><tfoot><tr><td colspan="5">Razem</td><td>${money(total)}</td></tr></tfoot></table><div class="print-signatures"><span>Wystawił</span><span>Przyjął / wydał</span></div>`;$("documentModal").classList.add("show")}catch(e){toast("Nie udało się otworzyć dokumentu")}}
$("printDocument").onclick=()=>{document.body.classList.add("printing-doc");window.print();setTimeout(()=>document.body.classList.remove("printing-doc"),500)};
function openProduct(id=null){$("productForm").reset();$("productId").value="";$("productModalTitle").textContent="Nowa część";$("unit").value="szt.";$("min_qty").value=0;$("purchase_price").value=0;$("sale_price").value=0;$("openAlternativesFromProduct").classList.add("hidden");$("productAliases").textContent="—";if(id){const p=S.products.find(x=>x.id===id);if(!p)return;$("productId").value=id;$("productModalTitle").textContent="Edycja części";$("productAliases").textContent=p.aliases||"—";["sku","oem_no","barcode","name","category","supplier_id","location_id","min_qty","purchase_price","sale_price","unit","diagram_position"].forEach(k=>$(k).value=p[k]??"");$("product_notes").value=p.notes||"";$("openAlternativesFromProduct").classList.remove("hidden")}$("productModal").classList.add("show");setTimeout(()=>$("sku").focus(),50)}
function openMovement(){$("moveForm").reset();$("move_date").value=new Date().toISOString().slice(0,10);$("quantity").value=1;$("unit_price").value=0;$("move_type").value="PZ";refreshMoveProducts();$("moveModal").classList.add("show");setTimeout(()=>$("move_product_id").focus(),50)}
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>$(b.dataset.close).classList.remove("show"));
$("productForm").onsubmit=async e=>{e.preventDefault();const d={};["sku","oem_no","barcode","name","category","supplier_id","location_id","min_qty","purchase_price","sale_price","unit","diagram_position"].forEach(k=>d[k]=$(k).value);d.notes=$("product_notes").value;try{const id=$("productId").value;if(id)await api("/api/product/"+id,{method:"PUT",body:JSON.stringify(d)});else await api("/api/product",{method:"POST",body:JSON.stringify(d)});$("productModal").classList.remove("show");toast("Część zapisana");await Promise.all([loadProducts(),loadSummary()])}catch(e){toast(e.code==="duplicate_code"?"SKU/OEM/kod kreskowy już istnieje":"Nie udało się zapisać")}}
$("moveForm").onsubmit=async e=>{e.preventDefault();const d={};["move_type","move_date","move_product_id","quantity","unit_price","reference_no","move_supplier_id","motowarsztat_order_no","shop_order_no"].forEach(k=>d[k]=$(k).value);d.product_id=d.move_product_id;d.supplier_id=d.move_supplier_id;d.note=$("move_note").value;try{const r=await api("/api/movement",{method:"POST",body:JSON.stringify(d)});$("moveModal").classList.remove("show");toast("Zapisano "+r.document_no);await Promise.all([loadProducts(),loadMovements(),loadSummary()])}catch(e){toast(e.code==="insufficient_stock"?`Za mały stan. Dostępne: ${e.data.stock}`:"Nie udało się zapisać ruchu")}}
$("supplierForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/supplier",{method:"POST",body:JSON.stringify({name:$("supplierName").value,phone:$("supplierPhone").value,email:$("supplierEmail").value,nip:$("supplierNip").value})});e.target.reset();await loadSuppliers();toast("Dostawca dodany")}catch(e){toast("Nie udało się dodać dostawcy")}}
$("locationForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/location",{method:"POST",body:JSON.stringify({code:$("locationCode").value,name:$("locationName").value})});e.target.reset();await loadLocations();toast("Lokalizacja dodana")}catch(e){toast("Nie udało się dodać lokalizacji")}}
function updateStockHint(){const p=S.products.find(x=>x.id===$("move_product_id").value);$("stockHint").textContent=p?`Aktualny stan: ${(+p.stock_qty).toFixed(2)} ${p.unit} · minimum: ${(+p.min_qty).toFixed(2)}`:""}
$("move_product_id").onchange=()=>{const p=S.products.find(x=>x.id===$("move_product_id").value);if(p&&["PZ","ZW","KOREKTA+"].includes($("move_type").value))$("unit_price").value=(+p.purchase_price||0).toFixed(2);updateStockHint()};$("move_type").onchange=updateStockHint;

// Zamienniki
async function loadAlternatives(){const pid=+$("altBaseProduct").value;if(!pid){$("localAlternatives").innerHTML='<div class="hint">Wybierz część bazową.</div>';$("externalAlternatives").innerHTML='';return}const d=await api(`/api/product/${pid}/alternatives`);$("localAlternatives").innerHTML=d.local.length?d.local.map(p=>`<div class="alt-card"><div><b>${esc(p.sku||p.oem_no||"—")} · ${esc(p.name)}</b><small>Stan: ${(+p.stock_qty).toFixed(2)} · ${esc(p.location_code||"bez lokalizacji")} · zakup ${money(p.purchase_price)}</small></div></div>`).join(""):'<div class="hint">Brak lokalnych zamienników.</div>';$("externalAlternatives").innerHTML=d.external.length?d.external.map(x=>`<div class="alt-card"><div><b>${esc(x.brand||"")} ${esc(x.external_index||x.external_sku||"")} · ${esc(x.name||"")}</b><small>IC SKU: ${esc(x.external_sku||"—")} · stan ${(+x.last_stock||0).toFixed(0)} · netto ${money(x.last_price_net)}</small></div><button class="btn mini" data-del-ext="${x.id}">Usuń</button></div>`).join(""):'<div class="hint">Brak zapisanych zamienników Inter Cars.</div>';document.querySelectorAll("[data-del-ext]").forEach(b=>b.onclick=async()=>{await api("/api/alternative/external/"+b.dataset.delExt,{method:"DELETE"});await loadAlternatives()})}
$("altBaseProduct").onchange=loadAlternatives;$("refreshAlternatives").onclick=loadAlternatives;$("linkLocalAlt").onclick=async()=>{const pid=+$("altBaseProduct").value,alt=+$("altLocalProduct").value;if(!pid||!alt)return toast("Wybierz obie części");try{await api(`/api/product/${pid}/alternatives/link`,{method:"POST",body:JSON.stringify({alternative_product_id:alt})});toast("Połączono jako zamienniki");await loadAlternatives()}catch(e){toast(e.code==="same_product"?"Nie można wskazać tej samej części":"Nie udało się połączyć")}};
$("openAlternativesFromProduct").onclick=()=>{const id=$("productId").value;$("productModal").classList.remove("show");page("alternatives");$("altBaseProduct").value=id;loadAlternatives()};

// Inter Cars
$("icSearchBtn").onclick=async()=>{const q=$("icSearchQuery").value.trim();if(!q)return toast("Wpisz indeks lub SKU");$("icResults").innerHTML='<div class="hint">Pobieram katalog, stan i cenę Inter Cars...</div>';try{const d=await api(`/api/intercars/search?mode=${encodeURIComponent($("icSearchMode").value)}&q=${encodeURIComponent(q)}`);S.icResults=d.items;renderIcResults()}catch(e){$("icResults").innerHTML='';toast(e.code==="ic_http"?`Inter Cars: HTTP ${e.data.status}`:"Nie udało się pobrać danych Inter Cars")}};
function renderIcResults(){$("icSearchInfo").textContent=`Znaleziono: ${S.icResults.length}`;$("icResults").innerHTML=S.icResults.length?S.icResults.map((x,i)=>`<div class="ic-card"><div class="ic-main"><b>${esc(x.brand||"")} ${esc(x.index||x.sku||"")}</b><span>${esc(x.name||x.description||"")}</span><small>SKU: ${esc(x.sku||"—")} · stan: ${(+x.stock||0).toFixed(0)} · cena klienta netto: ${money(x.price_net)} · brutto: ${money(x.price_gross)}</small></div><div class="ic-actions"><button class="btn mini" data-ic-alt="${i}">Zapisz jako zamiennik</button><button class="btn mini primary" data-ic-import="${i}">Dodaj do magazynu + zamiennik</button></div></div>`).join(""):'<div class="hint">Brak wyników.</div>';document.querySelectorAll("[data-ic-alt]").forEach(b=>b.onclick=()=>saveIcAlternative(+b.dataset.icAlt));document.querySelectorAll("[data-ic-import]").forEach(b=>b.onclick=()=>importIcAsLocal(+b.dataset.icImport))}
async function saveIcAlternative(i){const pid=+$("altBaseProduct").value;if(!pid)return toast("Najpierw wybierz część bazową");const x=S.icResults[i];await api(`/api/product/${pid}/alternatives/external`,{method:"POST",body:JSON.stringify(x)});toast("Zapisano zamiennik Inter Cars");await loadAlternatives()}
async function importIcAsLocal(i){const base=+$("altBaseProduct").value;if(!base)return toast("Najpierw wybierz część bazową");const x=S.icResults[i];try{const d=await api("/api/intercars/import-product",{method:"POST",body:JSON.stringify(x)});await loadProducts();await api(`/api/product/${base}/alternatives/link`,{method:"POST",body:JSON.stringify({alternative_product_id:d.id})});toast(d.existing?"Istniejąca część została przypisana jako zamiennik":"Dodano część z Inter Cars do magazynu i zamienników");await loadAlternatives()}catch(e){toast("Nie udało się dodać części")}}

// Integracje
async function loadIntegrationSettings(){try{const d=await api("/api/integrations/settings");$("woo_url").value=d.woo_url||"https://sklep.mbautoserwis.com";$("woo_key").placeholder=d.has_woo_key?"zapisany — pozostaw puste":"ck_...";$("woo_secret").placeholder=d.has_woo_key?"zapisany — pozostaw puste":"cs_...";$("woo_auto_enabled").checked=!!d.woo_auto_enabled;$("woo_auto_minutes").value=d.woo_auto_minutes||10;$("ic_base_url").value=d.ic_base_url;$("ic_token_url").value=d.ic_token_url;$("ic_client_id").placeholder=d.has_ic_key?"zapisany — pozostaw puste":"ClientID";$("ic_client_secret").placeholder=d.has_ic_key?"zapisany — pozostaw puste":"ClientSecret";$("syncWooLocal").disabled=!d.has_local_sales_db;$("integrationLogs").innerHTML=d.logs.length?d.logs.map(x=>`<div class="listitem"><div><b>${esc(x.source)}</b> · ${esc(x.result)}<br><small>${esc((x.synced_at||"").replace("T"," "))} · rekordy ${x.records_seen} · ruchy ${x.movements_created} · problemy ${x.issues_count}</small></div><small>${esc(x.message||"")}</small></div>`).join(""):'<div class="hint">Brak synchronizacji.</div>'}catch(e){}}
async function saveIntegrationSettings(){const data={woo_url:$("woo_url").value,woo_key:$("woo_key").value,woo_secret:$("woo_secret").value,woo_auto_enabled:$("woo_auto_enabled").checked,woo_auto_minutes:+$("woo_auto_minutes").value||10,ic_base_url:$("ic_base_url").value,ic_token_url:$("ic_token_url").value,ic_client_id:$("ic_client_id").value,ic_client_secret:$("ic_client_secret").value};await api("/api/integrations/settings",{method:"POST",body:JSON.stringify(data)});$("woo_key").value=$("woo_secret").value=$("ic_client_id").value=$("ic_client_secret").value="";toast("Ustawienia zapisane");await loadIntegrationSettings()}
$("integrationForm").onsubmit=async e=>{e.preventDefault();try{await saveIntegrationSettings()}catch(e){toast("Nie udało się zapisać ustawień")}};$("saveIntegrations").onclick=async()=>{try{await saveIntegrationSettings()}catch(e){toast("Nie udało się zapisać ustawień")}};
$("testInterCars").onclick=async()=>{try{await saveIntegrationSettings();const d=await api("/api/intercars/test",{method:"POST",body:"{}"});toast(d.ok?"Inter Cars API: połączenie OK":"Błąd Inter Cars")}catch(e){toast(e.code==="ic_http"?`Inter Cars HTTP ${e.data.status}`:"Nie udało się uwierzytelnić Inter Cars")}};
async function syncWoo(source){try{toast("Synchronizacja nowych zamówień WooCommerce...");const d=await api("/api/integrations/sync-woo",{method:"POST",body:JSON.stringify({source})});if(d.baseline_initialized)toast(`WooCommerce: start od teraz · zamknięto ${d.historical_issues_closed||0} starych problemów`);else toast(`Nowe/zmienione zamówienia: ${d.seen} · ruchy ${d.movements} · problemy ${d.issues}`);await Promise.all([loadProducts(),loadMovements(),loadSummary(),loadIntegrationIssues(),loadIntegrationSettings()])}catch(e){toast(e.code==="woo_http"?`WooCommerce HTTP ${e.data.status}`:"Nie udało się zsynchronizować WooCommerce")}}
$("syncWooDirect").onclick=()=>syncWoo("direct");$("syncWooLocal").onclick=()=>syncWoo("local");
async function loadIntegrationIssues(){const d=await api("/api/integrations/issues");S.issues=d.issues;$("issuesLabel").textContent=d.issues.length+" otwartych";$("integrationIssues").innerHTML=d.issues.length?d.issues.map(x=>`<div class="issue-card"><div><b>${esc(x.source)} · ${esc(x.external_doc||"")}</b><span>${esc(x.item_name||"")} · SKU ${esc(x.sku||"—")} / OEM ${esc(x.oem_no||"—")} · ilość ${(+x.quantity).toFixed(2)}</span><small>${esc(x.message||x.issue_type)}</small></div><div class="issue-map"><select data-issue-select="${x.id}"><option value="">Przypisz część...</option>${S.products.map(p=>`<option value="${p.id}">${esc(p.sku||p.oem_no||"")} · ${esc(p.name)}</option>`).join("")}</select><button class="btn mini" data-issue-map="${x.id}">Przypisz</button></div></div>`).join(""):'<div class="hint">Brak problemów integracji.</div>';document.querySelectorAll("[data-issue-map]").forEach(b=>b.onclick=async()=>{const id=b.dataset.issueMap,sel=document.querySelector(`[data-issue-select="${id}"]`),pid=+sel.value;if(!pid)return toast("Wybierz część");await api(`/api/integrations/issues/${id}/map`,{method:"POST",body:JSON.stringify({product_id:pid})});toast("Przypisano. Uruchom synchronizację ponownie, aby utworzyć ruch.");await loadIntegrationIssues()})}

// MotoWarsztat CSV
function parseCSV(text){const first=(text.split(/\r?\n/,1)[0]||"");const delim=(first.split(";").length>first.split(",").length)?";":",";const rows=[];let row=[],cell="",q=false;for(let i=0;i<text.length;i++){const ch=text[i],nx=text[i+1];if(ch==='"'){if(q&&nx==='"'){cell+='"';i++}else q=!q}else if(ch===delim&&!q){row.push(cell);cell=""}else if((ch==='\n'||ch==='\r')&&!q){if(ch==='\r'&&nx==='\n')i++;row.push(cell);cell="";if(row.some(x=>x.trim()!==""))rows.push(row);row=[]}else cell+=ch}if(cell||row.length){row.push(cell);if(row.some(x=>x.trim()!==""))rows.push(row)}return rows}
function norm(s){return String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim().toLowerCase().replace(/\s+/g," ")}
function col(headers,names){for(const n of names){const i=headers.indexOf(n);if(i>=0)return i}return -1}
$("importMotoCsv").onclick=async()=>{const f=$("motoCsv").files[0];if(!f)return toast("Wybierz plik CSV");const rows=parseCSV(await f.text());if(rows.length<2)return toast("CSV jest pusty");const h=rows[0].map(norm);const ix={order:col(h,["zlecenie","nr zlecenia","numer zlecenia","motowarsztat","order","order no"]),sku:col(h,["sku","indeks","indeks towaru","symbol"]),oem:col(h,["oem","nr oem","numer oem","numer czesci"]),qty:col(h,["ilosc","qty","quantity"]),date:col(h,["data","date"]),name:col(h,["nazwa","towar","czesc","produkt"]),action:col(h,["akcja","typ","ruch"]),line:col(h,["id pozycji","line id","pozycja id"])};if(ix.order<0||ix.qty<0||(ix.sku<0&&ix.oem<0))return toast("CSV musi mieć: zlecenie, ilość i SKU lub OEM");const num=v=>parseFloat(String(v||"0").replace(/\s/g,"").replace(",","."))||0;const payload=rows.slice(1).map((r,i)=>({order_no:r[ix.order]||"",sku:ix.sku>=0?r[ix.sku]||"":"",oem_no:ix.oem>=0?r[ix.oem]||"":"",quantity:num(r[ix.qty]),date:ix.date>=0?r[ix.date]||"":"",name:ix.name>=0?r[ix.name]||"":"",action:ix.action>=0?r[ix.action]||"RW":"RW",line_id:ix.line>=0?r[ix.line]||String(i+1):String(i+1)}));try{const d=await api("/api/integrations/import-moto",{method:"POST",body:JSON.stringify({rows:payload})});toast(`Import CSV: ${d.movements} ruchów, ${d.issues} problemów`);$("motoCsv").value="";await Promise.all([loadProducts(),loadMovements(),loadSummary(),loadIntegrationIssues(),loadIntegrationSettings()])}catch(e){toast("Nie udało się zaimportować CSV")}};

// Standard controls
$("newProductSide").onclick=$("newProductTop").onclick=()=>openProduct();$("newMovementSide").onclick=$("newMovementTop").onclick=openMovement;$("productSearch").oninput=()=>{clearTimeout(window.ps);window.ps=setTimeout(loadProducts,160)};$("productSearch").onkeydown=async e=>{if(e.key!=="Enter")return;e.preventDefault();const code=$("productSearch").value.trim();if(!code)return;try{const d=await api("/api/scan?code="+encodeURIComponent(code));if(d.found){openProductDetail(d.product.id)}else if(d.suggested_oem&&confirm(`Nie znaleziono towaru. Utworzyć kartotekę dla ${d.suggested_oem}?`)){openProduct();$("oem_no").value=d.suggested_oem;$("sku").value=d.suggested_oem;$("barcode").value=d.suggested_oem;$("name").value="Mercedes-Benz OEM "+d.suggested_oem}}catch(e){toast("Nie udało się odczytać kodu")}};$("productActive").onchange=loadProducts;$("lowOnly").onchange=loadProducts;$("moveSearch").oninput=()=>{clearTimeout(window.ms);window.ms=setTimeout(loadMovements,200)};$("moveTypeFilter").onchange=loadMovements;$("documentSearch").oninput=()=>{clearTimeout(window.ds);window.ds=setTimeout(loadDocuments,180)};$("documentType").onchange=loadDocuments;
async function backup(){
  try{
    const r=await api("/api/backup/create",{method:"POST",body:"{}"});
    toast("Kopia zapisana: "+r.filename);
    try{const a=document.createElement("a");a.href="/api/backup";a.download="";document.body.appendChild(a);a.click();a.remove()}catch(_){}
    setTimeout(()=>alert("Kopia została zapisana lokalnie oraz uruchomiono pobieranie pliku:\\n"+r.path),150);
  }catch(e){toast("Nie udało się wykonać kopii zapasowej")}
}
$("backupSide").onclick=backup;$("exportBtn").onclick=()=>{window.location.href="/api/export-products.csv"};$("logout").onclick=async()=>{await api("/api/logout",{method:"POST",body:"{}"});S.csrf=null;showAuth(false)};
boot().catch(()=>showAuth(false));


// Mercedes B2B Bridge — części i zamówienia
async function loadB2bSettings(){
  try{const d=await api("/api/b2b/settings");$("b2bToken").value=d.bridge_token||""}catch(e){}
}
$("copyB2bToken").onclick=async()=>{try{await navigator.clipboard.writeText($("b2bToken").value);toast("Token skopiowany")}catch(e){$("b2bToken").select();document.execCommand("copy");toast("Token skopiowany")}};
$("regenB2bToken").onclick=async()=>{
  if(!confirm("Wygenerować nowy token? Stary token we wtyczce przestanie działać."))return;
  const d=await api("/api/b2b/token/regenerate",{method:"POST",body:"{}"});$("b2bToken").value=d.bridge_token;toast("Nowy token wygenerowany");
};
$("refreshB2b").onclick=loadB2bCaptures;

async function loadB2bCaptures(){
  try{
    const d=await api("/api/b2b/imports");$("b2bCount").textContent=d.imports.length+" wpisów";
    $("b2bImports").innerHTML=d.imports.length?d.imports.map(x=>{
      const s=x.summary||{},isOrder=x.import_type==="ORDER";
      const lines=isOrder?(s.items||[]).slice(0,20).map(i=>`<div class="b2b-import-line"><b>${esc(i.oem_no||i.sku||"—")}</b><span>${esc(i.name||"")}</span><span>${(+i.qty||0).toFixed(2)} szt.</span><span>${money(i.purchase_price)}</span><span>sugerowana ${money(i.suggested_price)}</span></div>`).join(""):"";
      const internal=s.internal_document_no||"";return `<div class="b2b-card doc-hover">
        <div class="b2b-card-head"><div><b>${isOrder?"Zamówienie":"Kartoteka części"} ${esc(x.order_no||"")}</b><small>${esc((x.imported_at||"").replace("T"," "))}${x.purchase_date?" · zakup "+esc(x.purchase_date):""}${x.supplier_name?" · "+esc(x.supplier_name):""}${internal?" · "+esc(internal):""}</small></div><div><span class="badge ${isOrder?"PZ":""}">${isOrder?"PZ / "+x.movements_count+" poz.":"stan bez zmian"}</span>${isOrder&&s.document_id?`<button class="btn mini" data-b2b-doc="${s.document_id}">Podgląd PZ</button>`:""}</div></div>
        <div class="b2b-source">${esc(x.page_url||"")}</div>${lines}${isOrder?`<div class="doc-tooltip">Data zamówienia: ${esc(x.purchase_date||"—")}<br>Numer zewnętrzny: ${esc(x.order_no||"—")}<br>Dokument wewnętrzny: ${esc(internal||"—")}<br>Dostawca: ${esc(x.supplier_name||"—")}</div>`:""}
      </div>`;
    }).join(""):'<div class="hint">Brak importów z Mercedes B2B.</div>';document.querySelectorAll("[data-b2b-doc]").forEach(b=>b.onclick=()=>openDocument(+b.dataset.b2bDoc));
  }catch(e){toast("Nie udało się pobrać historii B2B")}
}

async function loadContractors(){
  try{const d=await api("/api/contractors");S.contractors=d.contractors;$("contractorsCount").textContent=d.contractors.length+" firm";$("contractorsList").innerHTML=d.contractors.length?d.contractors.map(c=>`<div class="listitem contractor"><div><b>${esc(c.name)}</b><br><small>NIP ${esc(c.nip||"—")} · REGON ${esc(c.regon||"—")} · VAT ${esc(c.vat_status||"—")}<br>${esc(c.address||"")}</small></div><div><span class="badge">${esc(c.role)}</span><br><button class="btn mini danger" data-contractor-del="${c.id}">Usuń</button></div></div>`).join(""):'<div class="hint">Brak firm w kartotece.</div>';document.querySelectorAll("[data-contractor-del]").forEach(b=>b.onclick=async()=>{if(!confirm("Usunąć firmę z kartoteki?"))return;await api("/api/contractor/"+b.dataset.contractorDel,{method:"DELETE"});loadContractors()})}catch(e){}
}
$("nipForm").onsubmit=async e=>{e.preventDefault();const nip=$("nipLookup").value.replace(/\D/g,"");if(nip.length!==10)return toast("NIP musi mieć 10 cyfr");toast("Pobieram dane firmy…");try{const d=await api("/api/contractor/lookup-nip",{method:"POST",body:JSON.stringify({nip})}),c=d.company;$("companyName").value=c.name||"";$("companyNip").value=c.nip||nip;$("companyRegon").value=c.regon||"";$("companyKrs").value=c.krs||"";$("companyAddress").value=c.address||"";$("companyVat").value=c.vat_status||"";$("companyRequestId").value=c.request_id||"";$("contractorForm").classList.remove("hidden");$("companyPhone").focus();toast("Dane firmy pobrane")}catch(e){toast(e.data?.message||"Nie znaleziono firmy")}};
$("contractorForm").onsubmit=async e=>{e.preventDefault();const d={name:$("companyName").value,nip:$("companyNip").value,regon:$("companyRegon").value,krs:$("companyKrs").value,address:$("companyAddress").value,vat_status:$("companyVat").value,phone:$("companyPhone").value,email:$("companyEmail").value,role:$("companyRole").value,mf_request_id:$("companyRequestId").value};await api("/api/contractor",{method:"POST",body:JSON.stringify(d)});e.target.reset();e.target.classList.add("hidden");$("nipLookup").value="";toast("Firma dodana do kartoteki");await Promise.all([loadContractors(),loadSuppliers()])};

function resetLocationForm(){$("locationId").value="";$("locationCode").value="";$("locationName").value="";$("locationFormTitle").textContent="Dodaj lokalizację";$("locationSubmit").textContent="Dodaj";$("cancelLocationEdit").classList.add("hidden")}
function editLocation(id){const x=S.locations.find(v=>v.id===id);if(!x)return;$("locationId").value=id;$("locationCode").value=x.code||"";$("locationName").value=x.name||"";$("locationFormTitle").textContent="Edytuj lokalizację";$("locationSubmit").textContent="Zapisz";$("cancelLocationEdit").classList.remove("hidden");$("locationCode").focus()}
$("cancelLocationEdit").onclick=resetLocationForm;
async function deleteLocation(id){const x=S.locations.find(v=>v.id===id);if(!x)return;if(!confirm(`Usunąć lokalizację ${x.code}?\nTowary przypisane do niej pozostaną w kartotece, ale bez lokalizacji.`))return;const r=await api("/api/location/"+id,{method:"DELETE"});toast(r.unassigned_products?`Usunięto. ${r.unassigned_products} towarów bez lokalizacji.`:"Lokalizacja usunięta");resetLocationForm();await Promise.all([loadLocations(),loadProducts()])}
$("locationForm").onsubmit=async e=>{e.preventDefault();const id=$("locationId").value,d={code:$("locationCode").value,name:$("locationName").value};try{if(id)await api("/api/location/"+id,{method:"PUT",body:JSON.stringify(d)});else await api("/api/location",{method:"POST",body:JSON.stringify(d)});toast(id?"Lokalizacja zmieniona":"Lokalizacja dodana");resetLocationForm();await loadLocations()}catch(e){toast(e.code==="duplicate"?"Kod lokalizacji już istnieje":"Nie udało się zapisać lokalizacji")}};




// ===== v10 TEST — lista B2B, koszyk Mercedes, pełna edycja, interaktywny diagram =====
function mbStatusMeta(code){return {
  DEALER:{label:"Dealer",cls:"dealer",mark:"✓"},CENTRAL:{label:"Centralny",cls:"central",mark:""},GERMANY:{label:"Niemcy",cls:"germany",mark:""},UNAVAILABLE:{label:"Niedostępne",cls:"unavailable",mark:""},UNKNOWN:{label:"Nieznane",cls:"unknown",mark:"?"},ERROR:{label:"Błąd",cls:"unknown",mark:"!"}
}[code]||{label:"Sprawdzam",cls:"pending",mark:""}}
function mbListStatus(p){const pending=["PENDING","WORKING"].includes(p.mb_request_status);const m=mbStatusMeta(pending?null:p.mb_status_code);const tm=p.mb_checked_at?String(p.mb_checked_at).replace("T"," ").slice(0,16):"";return `<div class="mb-list-status" title="${esc(tm?"Sprawdzono: "+tm:"Oczekuje na sprawdzenie w B2B")}"><i class="mb-dot ${m.cls}">${m.mark}</i><div><b>${esc(m.label)}</b>${tm?`<small>${esc(tm.slice(5))}</small>`:""}</div></div>`}

async function loadProducts(){
  const q=encodeURIComponent($("productSearch")?.value||""),low=$("lowOnly")?.checked?"1":"",active=$("productActive")?.value||"1";
  const d=await api(`/api/products?q=${q}&low=${low}&active=${encodeURIComponent(active)}`);S.products=d.products;$("productsLabel").textContent=d.products.length+" indeksów";
  $("productsBody").innerHTML=d.products.map(p=>`<tr class="${p.active?"":"archived-row"}" data-product-row="${p.id}">
    <td><input type="checkbox" class="product-select" value="${p.id}" aria-label="Zaznacz ${esc(p.name)}"></td><td>${esc(p.sku||"—")}</td><td><b>${esc(p.oem_no||"—")}</b>${p.aliases?`<br><small>${esc(p.aliases)}</small>`:""}</td>
    <td><b>${esc(p.name)}</b><br><small>${esc(p.category||"")}</small></td><td>${esc(p.location_code||"—")}</td><td class="${(+p.stock_qty)<= (+p.min_qty)?"low":"ok"}">${(+p.stock_qty).toFixed(2)} ${esc(p.unit)}</td><td>${(+p.min_qty).toFixed(2)}</td><td>${mbListStatus(p)}</td>
    <td>${money(p.purchase_price)}</td><td>${money(p.sale_price)}</td><td>${esc(p.supplier_name||"—")}</td><td class="row-actions"><button class="btn mini" data-open-product="${p.id}">Otwórz</button><button class="btn mini" data-cart-product="${p.id}">+ Koszyk</button><button class="btn mini" data-edit="${p.id}">Edytuj</button></td></tr>`).join("");
  document.querySelectorAll("[data-open-product]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProductDetail(+b.dataset.openProduct)});
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProduct(+b.dataset.edit)});
  document.querySelectorAll("[data-cart-product]").forEach(b=>b.onclick=e=>{e.stopPropagation();addToCart(+b.dataset.cartProduct,1)});
  document.querySelectorAll("[data-product-row]").forEach(r=>r.ondblclick=e=>{if(!e.target.closest("button,input"))openProductDetail(+r.dataset.productRow)});
  $("selectAllProducts").checked=false;refreshMoveProducts();refreshAltProductSelects();
  // FASTFIX: dostępność nie jest już kolejkowana masowo dla całej kartoteki.
}
$("selectAllProducts").onchange=e=>document.querySelectorAll(".product-select").forEach(x=>x.checked=e.target.checked);
$("addSelectedCart").onclick=async()=>{const ids=[...document.querySelectorAll(".product-select:checked")].map(x=>+x.value);if(!ids.length)return toast("Zaznacz towary");for(const id of ids)await addToCart(id,1,false);toast(`Dodano ${ids.length} pozycji do koszyka`);await loadCart()};

async function addToCart(pid,qty=1,notify=true){try{await api("/api/cart/item",{method:"POST",body:JSON.stringify({product_id:pid,quantity:qty})});if(notify)toast("Dodano do koszyka Mercedes");await updateCartCount()}catch(e){toast("Nie udało się dodać do koszyka")}}
async function updateCartCount(){try{const d=await api("/api/cart");$("cartNavCount").textContent=d.items.length;return d}catch(e){return null}}
function cartSendStatus(x){const s=x.b2b_status||"";if(s==="ADDED")return `<span class="cart-send-ok">✓ Dodano do B2B</span>`;if(s==="ADDED_REVIEW_QTY")return `<span class="cart-send-warn">✓ Dodano · sprawdź ilość</span>`;if(s==="REPLACED")return `<span class="cart-send-warn">↪ ${esc(x.b2b_final_oem||"numer zastąpiony")}</span>`;if(s==="NOT_FOUND")return `<span class="cart-send-err">Nie znaleziono</span>`;if(s==="ERROR")return `<span class="cart-send-err">${esc(x.b2b_message||"Błąd")}</span>`;if(["PENDING","WORKING"].includes(s))return `<span class="cart-send-warn">${s==="WORKING"?"Wysyłanie…":"Oczekuje…"}</span>`;return `<span class="hint">Jeszcze nie wysłano</span>`}
async function loadCart(){const d=await api("/api/cart");$("cartNavCount").textContent=d.items.length;$("cartBody").innerHTML=d.items.length?d.items.map(x=>`<tr><td><b>${esc(x.oem_no||x.sku||"—")}</b></td><td>${esc(x.name)}</td><td>${(+x.stock_qty).toFixed(2)} ${esc(x.unit)}</td><td>${mbListStatus({mb_status_code:x.mb_status_code,mb_checked_at:x.mb_checked_at})}</td><td><input class="cart-qty" type="number" min="0.01" step="1" value="${+x.quantity}" data-cart-qty="${x.id}" data-cart-product="${x.product_id}"></td><td>${money(x.purchase_price)}</td><td>${cartSendStatus(x)}</td><td><button class="btn mini danger" data-cart-del="${x.id}">Usuń</button></td></tr>`).join(""):'<tr><td colspan="8">Koszyk jest pusty.</td></tr>';
  document.querySelectorAll("[data-cart-qty]").forEach(inp=>inp.onchange=async()=>{await api("/api/cart/item",{method:"POST",body:JSON.stringify({product_id:+inp.dataset.cartProduct,quantity:Math.max(.01,+inp.value||1)})});loadCart()});
  document.querySelectorAll("[data-cart-del]").forEach(b=>b.onclick=async()=>{await api("/api/cart/item/"+b.dataset.cartDel,{method:"DELETE"});loadCart()});
  const busy=d.items.some(x=>["PENDING","WORKING"].includes(x.b2b_status));$("cartStatus").textContent=busy?"Wtyczka B2B realizuje pozycje koszyka. Nie zamykaj zalogowanej karty B2B Connect.":"Koszyk gotowy. Wysyłka do B2B nie zatwierdza finalnego zamówienia.";if(busy){clearTimeout(window.v10CartTimer);window.v10CartTimer=setTimeout(()=>{if(!$("cartPage").classList.contains("hidden"))loadCart()},3000)}
}
$("sendCartB2b").onclick=async()=>{try{const r=await api("/api/cart/send-b2b",{method:"POST",body:"{}"});toast(r.queued?`Przekazano ${r.queued} pozycji do wtyczki B2B`:"Brak nowych pozycji do wysłania");loadCart()}catch(e){toast("Nie udało się uruchomić wysyłki do B2B")}};

function page(p){["dashboard","products","movements","documents","cart","alternatives","integrations","b2b","suppliers","locations","contractors"].forEach(x=>$(x+"Page").classList.toggle("hidden",x!==p));document.querySelectorAll("nav [data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===p));$("title").textContent={dashboard:"Dashboard magazynu",products:"Kartoteka części",movements:"Ruchy magazynowe",documents:"Dokumenty magazynowe",cart:"Koszyk Mercedes",alternatives:"Zamienniki i odpowiedniki",integrations:"Sklep WooCommerce BETA",b2b:"Mercedes B2B Bridge",suppliers:"Dostawcy",locations:"Lokalizacje magazynowe",contractors:"Kontrahenci / NIP"}[p];if(p==="products")loadProducts();if(p==="movements")loadMovements();if(p==="documents")loadDocuments();if(p==="cart")loadCart();if(p==="alternatives"){refreshAltProductSelects();if($("altBaseProduct").value)loadAlternatives()}if(p==="integrations"){loadIntegrationSettings();loadIntegrationIssues()}if(p==="b2b"){loadB2bSettings();loadB2bCaptures()}if(p==="contractors")loadContractors();if(p==="suppliers")loadSuppliers();}

async function openProductDetail(id){try{const d=await api(`/api/product/${id}/detail`);S.detailProduct=d;const p=d.product;renderMbAvailability(d.availability,d.availability_request,d.bridge_status);$("detailName").textContent=p.name||"Karta produktu";$("detailSubtitle").textContent=p.oem_no||p.sku||"bez numeru";$("detailDiagramPosition").textContent=p.diagram_position||"—";$("detailFigurePos").textContent="poz. "+(p.diagram_position||"—");$("detailStock").textContent=`${(+p.stock_qty).toFixed(2)} ${p.unit}`;$("detailLocation").textContent=p.location_code||"—";$("detailBuy").textContent=money(p.purchase_price);$("detailSale").textContent=money(p.sale_price);
  $("detailMeta").innerHTML=`<div><b>OEM:</b> ${esc(p.oem_no||"—")}</div><div><b>SKU:</b> ${esc(p.sku||"—")}</div><div><b>Kod skanera:</b> ${esc(p.barcode||"—")}</div><div><b>Dostawca:</b> ${esc(p.supplier_name||"—")}</div><div><b>Kategoria:</b> ${esc(p.category||"—")}</div><div><b>Pozycja na rysunku:</b> ${esc(p.diagram_position||"—")}</div><div><b>Stan min.:</b> ${(+p.min_qty).toFixed(2)}</div><div><b>Źródło Mercedes:</b> B2B / XENTRY</div><div><b>Ceny B2B:</b> ${p.commerce_checked_at?esc(String(p.commerce_checked_at).replace("T"," ").slice(0,16)):"—"}</div><div><b>Integracja Mercedes:</b> B2B / XENTRY</div>`;
  const aliases=[p.oem_no,...d.aliases.map(a=>a.alias_no)].filter(Boolean);$("detailAliases").innerHTML=aliases.length?aliases.map((a,i)=>`<span class="alias-pill ${i===0?"primary":""}">${esc(a)}</span>`).join(""):'<span class="hint">Brak numerów powiązanych.</span>';
  if(p.preview_image){$("detailImageWrap").className="product-image-wrap";const hot=(d.diagram_hotspots||[]);let hs=hot.map(h=>{const m=mbStatusMeta(h.mb_status_code),pid=h.product_id||h.id||"";return `<button type="button" class="diagram-hotspot ${pid===p.id?"current":""} ${pid?"":"catalog-only"}" ${pid?`data-hotspot-product="${pid}"`:""} style="left:${(+h.diagram_marker_x*100).toFixed(2)}%;top:${(+h.diagram_marker_y*100).toFixed(2)}%"><span>${esc(h.diagram_position||"•")}</span><span class="hotspot-tip"><b>Poz. ${esc(h.diagram_position||"—")} · ${esc(h.oem_no||h.sku||"—")}</b>${esc(h.name||"Część Mercedes")}<br>${pid?`Stan MB Auto Serwis: ${(+h.stock_qty).toFixed(2)} ${esc(h.unit)}<br>Mercedes: ${esc(m.label)}<br><small>Kliknij, aby otworzyć kartotekę</small>`:`<small>Pozycja katalogowa — brak kartoteki w magazynie</small>`}</span></button>`}).join("");if(p.diagram_position&&!hot.some(h=>h.id===p.id))hs+=``;$("detailImageWrap").innerHTML=`<div class="diagram-stage"><img src="${esc(p.preview_image)}" alt="Rysunek katalogowy Mercedes Parts Information">${hs}<div class="diagram-caption">Pozycja tej części: <b>${esc(p.diagram_position||"—")}</b></div></div>`;document.querySelectorAll("[data-hotspot-product]").forEach(b=>{b.onclick=e=>{e.preventDefault();document.querySelectorAll(".diagram-hotspot").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");if(+b.dataset.hotspotProduct!==p.id)setTimeout(()=>openProductDetail(+b.dataset.hotspotProduct),160)}})}else{$("detailImageWrap").className="product-image-empty";$("detailImageWrap").innerHTML=`Brak rysunku z Mercedes Parts Information${p.diagram_position?`<br><b>Pozycja: ${esc(p.diagram_position)}</b>`:""}`}
  $("detailHistory").innerHTML=d.movements.length?`<div class="tablewrap"><table class="compact"><thead><tr><th>Data</th><th>Dokument</th><th>Typ</th><th>Ilość</th><th>Cena</th><th>Nr zewn.</th><th>Uwagi</th></tr></thead><tbody>${d.movements.map(m=>`<tr><td>${esc(m.move_date)}</td><td>${esc(m.parent_document_no||m.document_no)}</td><td><span class="badge ${esc(m.move_type)}">${esc(m.move_type)}</span></td><td>${(+m.quantity).toFixed(2)}</td><td>${money(m.unit_price)}</td><td>${esc(m.external_no||m.reference_no||"—")}</td><td>${esc(m.note||"")}</td></tr>`).join("")}</tbody></table></div>`:'<div class="hint">Brak ruchów magazynowych.</div>';
  $("detailOrders").innerHTML=d.documents.length?d.documents.map(x=>`<div class="order-card doc-hover"><div><b>${esc(x.document_no)}</b> · <span class="badge ${esc(x.doc_type)}">${esc(x.doc_type)}</span><br><small>${esc(x.doc_date)} · zewn. ${esc(x.external_no||"—")} · ${esc(x.supplier_name||"—")}</small></div><div><b>${money(x.value)}</b><br><button class="btn mini" data-detail-doc="${x.id}">Podgląd / edycja</button></div><div class="doc-tooltip">Zamówiono: ${esc(x.doc_date||"—")}<br>Numer zamówienia zewnętrznego: ${esc(x.external_no||"—")}<br>Dostawca: ${esc(x.supplier_name||"—")}<br>Źródło: ${esc(x.source||"—")}</div></div>`).join(""):'<div class="hint">Brak dokumentów dla tego produktu.</div>';
  $("detailAlts").innerHTML=`<div class="detail-alt-section"><h4>Zamienniki w magazynie</h4>${d.alternatives.length?d.alternatives.map(a=>`<div class="alt-card"><div><b>${esc(a.oem_no||a.sku||"—")} · ${esc(a.name)}</b><small>Stan ${(+a.stock_qty).toFixed(2)} · ${esc(a.location_code||"bez lokalizacji")}</small></div><button class="btn mini" data-open-alt="${a.id}">Otwórz</button></div>`).join(""):'<div class="hint">Brak lokalnych zamienników.</div>'}</div><div class="detail-alt-section"><h4>Zamienniki Inter Cars</h4>${d.external_alternatives.length?d.external_alternatives.map(a=>`<div class="alt-card"><div><b>${esc(a.brand||"")} ${esc(a.external_index||a.external_sku||"")} · ${esc(a.name||"")}</b><small>Stan ${(+a.last_stock||0).toFixed(0)} · netto ${money(a.last_price_net)}</small></div></div>`).join(""):'<div class="hint">Brak zapisanych odpowiedników Inter Cars.</div>'}<button class="btn" id="manageAlternativesDetail">Zarządzaj zamiennikami</button></div>`;
  document.querySelectorAll("[data-detail-doc]").forEach(b=>b.onclick=()=>openDocument(+b.dataset.detailDoc));document.querySelectorAll("[data-open-alt]").forEach(b=>b.onclick=()=>openProductDetail(+b.dataset.openAlt));$("manageAlternativesDetail")?.addEventListener("click",()=>{$("productDetailModal").classList.remove("show");page("alternatives");$("altBaseProduct").value=id;loadAlternatives()});
  $("detailArchive").classList.toggle("hidden",!p.active);$("detailRestore").classList.toggle("hidden",!!p.active);["detailOutRw","detailOutWz","detailInPz"].forEach(k=>$(k).disabled=!p.active);$("detailArchive").onclick=()=>archiveOrDeleteProduct(id);$("detailRestore").onclick=()=>restoreProduct(id);$("detailEdit").onclick=()=>{$("productDetailModal").classList.remove("show");openProduct(id)};$("detailAddCart").onclick=()=>addToCart(id,1);$("detailEnrichB2b").onclick=async()=>{try{await api(`/api/product/${id}/mercedes-enrich/request`,{method:"POST",body:JSON.stringify({force:true})});toast("Mercedes: uruchomiono Parts Information + B2B");setTimeout(()=>openProductDetail(id),4000)}catch(e){toast("Nie udało się uruchomić integracji Mercedes")}};$("detailOutRw").onclick=()=>openQuickMovement(id,"RW");$("detailOutWz").onclick=()=>openQuickMovement(id,"WZ");$("detailInPz").onclick=()=>openQuickMovement(id,"PZ");$("mbAvRefresh").onclick=()=>queueMbAvailability(id,true);detailTab("history");$("productDetailModal").classList.add("show")
}catch(e){toast("Nie udało się otworzyć karty produktu")}}

S.currentDocument=null;
async function openDocument(id){try{const d=await api("/api/document/"+id),x=d.document;S.currentDocument=d;$("documentModalTitle").textContent=`${x.doc_type} ${x.document_no}`;$("documentModalSub").textContent=`${x.doc_date}${x.external_no?" · nr zewn. "+x.external_no:""}${x.supplier_name?" · "+x.supplier_name:""}`;$("docEditDate").value=x.doc_date||"";$("docEditExternal").value=x.external_no||"";$("docEditNotes").value=x.notes||"";$("docEditSupplier").innerHTML='<option value="">— brak —</option>'+S.suppliers.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("");$("docEditSupplier").value=x.supplier_id||"";$("docEditLines").innerHTML=d.lines.map(l=>`<div class="doc-edit-line" data-doc-line="${l.id}"><div><b>${esc(l.oem_no||l.sku||"—")}</b><br><small>${esc(l.product_name)}</small></div><input type="number" min="0.01" step="0.01" value="${Math.abs(+l.quantity)}" data-doc-qty><input type="number" min="0" step="0.01" value="${+l.unit_price||0}" data-doc-price></div>`).join("");const total=d.lines.reduce((s,l)=>s+Math.abs((+l.quantity||0)*(+l.unit_price||0)),0);$("documentPrintArea").innerHTML=`<div class="print-head"><div><h2>MB AUTO SERWIS</h2><p>Dokument magazynowy</p></div><div><h2>${esc(x.doc_type)} ${esc(x.document_no)}</h2><p>${esc(x.doc_date)}</p></div></div><div class="print-meta"><div><b>Numer zewnętrzny</b><span>${esc(x.external_no||"—")}</span></div><div><b>Dostawca</b><span>${esc(x.supplier_name||"—")}</span></div><div><b>Źródło</b><span>${esc(x.source||"—")}</span></div><div><b>Uwagi</b><span>${esc(x.notes||"—")}</span></div></div><table class="print-table"><thead><tr><th>Lp.</th><th>OEM/SKU</th><th>Nazwa</th><th>Ilość</th><th>Cena</th><th>Wartość</th></tr></thead><tbody>${d.lines.map((l,i)=>`<tr><td>${i+1}</td><td>${esc(l.oem_no||l.sku||"—")}</td><td>${esc(l.product_name)}</td><td>${Math.abs(+l.quantity).toFixed(2)} ${esc(l.unit)}</td><td>${money(l.unit_price)}</td><td>${money(Math.abs((+l.quantity)*(+l.unit_price)))}</td></tr>`).join("")}</tbody><tfoot><tr><td colspan="5">Razem</td><td>${money(total)}</td></tr></tfoot></table><div class="print-signatures"><span>Wystawił</span><span>Przyjął / wydał</span></div>`;$("documentModal").classList.add("show")}catch(e){toast("Nie udało się otworzyć dokumentu")}}
$("saveDocumentEdit").onclick=async()=>{if(!S.currentDocument)return;const lines=[...document.querySelectorAll("[data-doc-line]")].map(r=>({id:+r.dataset.docLine,quantity:+r.querySelector("[data-doc-qty]").value,unit_price:+r.querySelector("[data-doc-price]").value}));try{await api("/api/document/"+S.currentDocument.document.id,{method:"PUT",body:JSON.stringify({doc_date:$("docEditDate").value,external_no:$("docEditExternal").value,supplier_id:$("docEditSupplier").value,notes:$("docEditNotes").value,lines})});toast("Dokument zapisany");await Promise.all([loadDocuments(),loadProducts(),loadSummary()]);openDocument(S.currentDocument.document.id)}catch(e){toast(e.code==="insufficient_stock"?"Zmiana spowodowałaby ujemny stan magazynu":"Nie udało się zapisać dokumentu")}};

async function loadSuppliers(){const d=await api("/api/suppliers");S.suppliers=d.suppliers;const opts='<option value="">— brak —</option>'+S.suppliers.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("");$("supplier_id").innerHTML=opts;$("move_supplier_id").innerHTML=opts;if($("docEditSupplier"))$("docEditSupplier").innerHTML=opts;$("suppliersList").innerHTML=S.suppliers.length?S.suppliers.map(x=>`<div class="listitem"><div><b>${esc(x.name)}</b><br><small>${esc(x.phone||"")} ${esc(x.email||"")} · NIP ${esc(x.nip||"—")}</small></div><div class="edit-inline-actions"><button class="btn mini" data-supplier-edit="${x.id}">Edytuj</button><button class="btn mini danger" data-supplier-del="${x.id}">Usuń</button></div></div>`).join(""):'<div class="hint">Brak dostawców.</div>';document.querySelectorAll("[data-supplier-edit]").forEach(b=>b.onclick=()=>editSupplier(+b.dataset.supplierEdit));document.querySelectorAll("[data-supplier-del]").forEach(b=>b.onclick=()=>deleteSupplier(+b.dataset.supplierDel))}
function resetSupplierForm(){$("supplierId").value="";$("supplierForm").reset();$("supplierFormTitle").textContent="Dodaj dostawcę";$("supplierSubmit").textContent="Dodaj";$("cancelSupplierEdit").classList.add("hidden")}
function editSupplier(id){const x=S.suppliers.find(v=>v.id===id);if(!x)return;$("supplierId").value=id;$("supplierName").value=x.name||"";$("supplierPhone").value=x.phone||"";$("supplierEmail").value=x.email||"";$("supplierNip").value=x.nip||"";$("supplierNotes").value=x.notes||"";$("supplierFormTitle").textContent="Edytuj dostawcę";$("supplierSubmit").textContent="Zapisz";$("cancelSupplierEdit").classList.remove("hidden")}
$("cancelSupplierEdit").onclick=resetSupplierForm;$("supplierForm").onsubmit=async e=>{e.preventDefault();const id=$("supplierId").value,d={name:$("supplierName").value,phone:$("supplierPhone").value,email:$("supplierEmail").value,nip:$("supplierNip").value,notes:$("supplierNotes").value};try{if(id)await api("/api/supplier/"+id,{method:"PUT",body:JSON.stringify(d)});else await api("/api/supplier",{method:"POST",body:JSON.stringify(d)});toast(id?"Dostawca zmieniony":"Dostawca dodany");resetSupplierForm();await loadSuppliers()}catch(e){toast("Nie udało się zapisać dostawcy")}};async function deleteSupplier(id){if(!confirm("Usunąć dostawcę? Towary i dokumenty pozostaną, ale bez przypisanego dostawcy."))return;await api("/api/supplier/"+id,{method:"DELETE"});loadSuppliers()}

async function loadContractors(){try{const d=await api("/api/contractors");S.contractors=d.contractors;$("contractorsCount").textContent=d.contractors.length+" firm";$("contractorsList").innerHTML=d.contractors.length?d.contractors.map(c=>`<div class="listitem contractor"><div><b>${esc(c.name)}</b><br><small>NIP ${esc(c.nip||"—")} · REGON ${esc(c.regon||"—")} · VAT ${esc(c.vat_status||"—")}<br>${esc(c.address||"")}</small></div><div class="edit-inline-actions"><button class="btn mini" data-contractor-edit="${c.id}">Edytuj</button><button class="btn mini danger" data-contractor-del="${c.id}">Usuń</button></div></div>`).join(""):'<div class="hint">Brak firm w kartotece.</div>';document.querySelectorAll("[data-contractor-edit]").forEach(b=>b.onclick=()=>editContractor(+b.dataset.contractorEdit));document.querySelectorAll("[data-contractor-del]").forEach(b=>b.onclick=async()=>{if(!confirm("Usunąć firmę z kartoteki?"))return;await api("/api/contractor/"+b.dataset.contractorDel,{method:"DELETE"});loadContractors()})}catch(e){}}
function editContractor(id){const c=S.contractors.find(x=>x.id===id);if(!c)return;$("contractorId").value=id;$("companyName").value=c.name||"";$("companyNip").value=c.nip||"";$("companyRegon").value=c.regon||"";$("companyKrs").value=c.krs||"";$("companyAddress").value=c.address||"";$("companyVat").value=c.vat_status||"";$("companyPhone").value=c.phone||"";$("companyEmail").value=c.email||"";$("companyRole").value=c.role||"Klient";$("contractorForm").classList.remove("hidden");$("contractorSubmit").textContent="Zapisz zmiany";$("cancelContractorEdit").classList.remove("hidden")}
function resetContractorEdit(){$("contractorId").value="";$("contractorForm").reset();$("contractorForm").classList.add("hidden");$("contractorSubmit").textContent="Dodaj do kartoteki";$("cancelContractorEdit").classList.add("hidden")}
$("cancelContractorEdit").onclick=resetContractorEdit;$("contractorForm").onsubmit=async e=>{e.preventDefault();const id=$("contractorId").value,d={name:$("companyName").value,nip:$("companyNip").value,regon:$("companyRegon").value,krs:$("companyKrs").value,address:$("companyAddress").value,vat_status:$("companyVat").value,phone:$("companyPhone").value,email:$("companyEmail").value,role:$("companyRole").value,mf_request_id:$("companyRequestId").value};try{if(id)await api("/api/contractor/"+id,{method:"PUT",body:JSON.stringify(d)});else await api("/api/contractor",{method:"POST",body:JSON.stringify(d)});toast(id?"Dane firmy zmienione":"Firma dodana do kartoteki");resetContractorEdit();await Promise.all([loadContractors(),loadSuppliers()])}catch(e){toast("Nie udało się zapisać firmy")}};

$("productForm").onsubmit=async e=>{e.preventDefault();const d={};["sku","oem_no","barcode","name","category","supplier_id","location_id","min_qty","purchase_price","sale_price","unit","diagram_position"].forEach(k=>d[k]=$(k).value);d.notes=$("product_notes").value;try{const id=$("productId").value;const r=id?await api("/api/product/"+id,{method:"PUT",body:JSON.stringify(d)}):await api("/api/product",{method:"POST",body:JSON.stringify(d)});$("productModal").classList.remove("show");toast(d.oem_no?"Część zapisana · dane Mercedes aktualizujesz przez import z B2B":"Część zapisana");await Promise.all([loadProducts(),loadSummary()]);if(!id&&r.id)setTimeout(()=>openProductDetail(r.id),700)}catch(e){toast(e.code==="duplicate_code"?"SKU/OEM/kod kreskowy już istnieje":"Nie udało się zapisać")}};

async function loadAll(){await Promise.all([loadSuppliers(),loadLocations(),loadContractors()]);await Promise.all([loadProducts(),loadMovements(),loadDocuments(),loadSummary(),loadIntegrationSettings()]);await updateCartCount()}
function openProduct(id=null){$("productForm").reset();$("productId").value="";$("productModalTitle").textContent="Nowa część";$("unit").value="szt.";$("min_qty").value=0;$("purchase_price").value=0;$("sale_price").value=0;$("productAliasesInput").value="";$("openAlternativesFromProduct").classList.add("hidden");if(id){const p=S.products.find(x=>x.id===id);if(!p)return;$("productId").value=id;$("productModalTitle").textContent="Edycja części";$("productAliasesInput").value=p.aliases||"";["sku","oem_no","barcode","name","category","supplier_id","location_id","min_qty","purchase_price","sale_price","unit","diagram_position"].forEach(k=>$(k).value=p[k]??"");$("product_notes").value=p.notes||"";$("openAlternativesFromProduct").classList.remove("hidden")}$("productModal").classList.add("show");setTimeout(()=>$("oem_no").focus(),50)}
$("productForm").onsubmit=async e=>{e.preventDefault();const d={};["sku","oem_no","barcode","name","category","supplier_id","location_id","min_qty","purchase_price","sale_price","unit","diagram_position"].forEach(k=>d[k]=$(k).value);d.aliases=$("productAliasesInput").value;d.notes=$("product_notes").value;try{const id=$("productId").value;const r=id?await api("/api/product/"+id,{method:"PUT",body:JSON.stringify(d)}):await api("/api/product",{method:"POST",body:JSON.stringify(d)});$("productModal").classList.remove("show");toast(d.oem_no?"Część zapisana · dane Mercedes aktualizujesz przez import z B2B":"Część zapisana");await Promise.all([loadProducts(),loadSummary()]);if(!id&&r.id)setTimeout(()=>openProductDetail(r.id),700)}catch(e){toast(e.code==="duplicate_code"?"SKU/OEM/kod już istnieje":"Nie udało się zapisać")}};

// ===== FINAL STABLE — MERCEDES B2B / MAGAZYN =====
async function copyCode(value){
  const text=String(value||"").trim(); if(!text)return;
  try{await navigator.clipboard.writeText(text)}catch(_){const ta=document.createElement("textarea");ta.value=text;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();document.execCommand("copy");ta.remove()}
  toast(`Skopiowano: ${text}`);
}
function normCode(v){return String(v||"").toUpperCase().replace(/[\s.\-]+/g,"")}
function mbListStatus(p){
  const m=mbStatusMeta((p.mb_status_code||"UNKNOWN").toUpperCase());
  const tm=p.mb_checked_at?String(p.mb_checked_at).replace("T"," ").slice(0,16):"";
  const label=p.mb_status_code?m.label:"Brak danych";
  return `<div class="mb-list-status" title="${esc(tm?`Status zapisany podczas importu B2B: ${tm}`:"Zaimportuj część z B2B, aby zapisać status")}"><i class="mb-dot ${p.mb_status_code?m.cls:"unknown"}">${p.mb_status_code?m.mark:"?"}</i><div><b>${esc(label)}</b>${tm?`<small>${esc(tm.slice(5))}</small>`:"<small>z importu B2B</small>"}</div></div>`
}
function renderMbAvailability(av,req,bridge){
  const code=(av?.status_code||"UNKNOWN").toUpperCase(),m=mbStatusMeta(code),icon=$("mbAvIcon");
  icon.className="mb-av-icon "+m.cls;icon.textContent=code==="DEALER"?"✓":(code==="UNKNOWN"?"?":"");
  if(!av){$("mbAvTitle").textContent="Brak danych z importu B2B";$("mbAvSubtitle").textContent="Otwórz część w B2B/XENTRY i użyj Import części. Automatyczne odpytywanie jest wyłączone.";$("mbAvTime").textContent="";return}
  const [title,sub]=mbAvailabilityText(code);$("mbAvTitle").textContent=title;$("mbAvSubtitle").textContent=(code==="DEALER"&&av.dealer_name)?av.dealer_name:(av.raw_label||sub);$("mbAvTime").textContent=av.checked_at?"import B2B "+String(av.checked_at).replace("T"," ").slice(0,16):"";
}
async function loadProducts(){
  const raw=$("productSearch")?.value||"",q=encodeURIComponent(raw),low=$("lowOnly")?.checked?"1":"",active=$("productActive")?.value||"1";
  const d=await api(`/api/products?q=${q}&low=${low}&active=${encodeURIComponent(active)}`);S.products=d.products;$("productsLabel").textContent=d.products.length+" indeksów";
  const nq=normCode(raw);
  $("productsBody").innerHTML=d.products.map(p=>{
    const vals=[p.sku,p.oem_no,p.barcode,...String(p.aliases||"").split(",")].map(normCode);const exact=nq&&vals.includes(nq);
    return `<tr class="${p.active?"":"archived-row"} ${raw?"search-hit":""} ${exact?"search-exact":""}" data-product-row="${p.id}">
      <td><input type="checkbox" class="product-select" value="${p.id}" aria-label="Zaznacz ${esc(p.name)}"></td>
      <td>${p.sku?`<button class="code-copy" data-copy-code="${esc(p.sku)}" title="Kliknij, aby skopiować SKU">${esc(p.sku)}</button>`:"—"}</td>
      <td>${p.oem_no?`<button class="code-copy primary-code" data-copy-code="${esc(p.oem_no)}" title="Kliknij, aby skopiować OEM">${esc(p.oem_no)}</button>`:"—"}${p.aliases?`<br><small>${esc(p.aliases)}</small>`:""}</td>
      <td><b>${esc(p.name)}</b><br><small>${esc(p.category||"")}</small></td><td>${esc(p.location_code||"—")}</td><td class="${(+p.stock_qty)<= (+p.min_qty)?"low":"ok"}">${(+p.stock_qty).toFixed(2)} ${esc(p.unit)}</td><td>${(+p.min_qty).toFixed(2)}</td><td>${mbListStatus(p)}</td>
      <td>${money(p.purchase_price)}</td><td>${money(p.sale_price)}</td><td>${esc(p.supplier_name||"—")}</td><td class="row-actions"><button class="btn mini" data-open-product="${p.id}">Otwórz</button><button class="btn mini" data-edit="${p.id}">Edytuj</button></td></tr>`
  }).join("");
  document.querySelectorAll("[data-copy-code]").forEach(b=>b.onclick=e=>{e.stopPropagation();copyCode(b.dataset.copyCode)});
  document.querySelectorAll("[data-open-product]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProductDetail(+b.dataset.openProduct)});
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProduct(+b.dataset.edit)});
  document.querySelectorAll("[data-product-row]").forEach(r=>r.ondblclick=e=>{if(!e.target.closest("button,input"))openProductDetail(+r.dataset.productRow)});
  if($("selectAllProducts"))$("selectAllProducts").checked=false;refreshMoveProducts();refreshAltProductSelects();
  if(raw){requestAnimationFrame(()=>{const x=document.querySelector("#productsBody .search-exact")||document.querySelector("#productsBody .search-hit");x?.scrollIntoView({behavior:"smooth",block:"center"})})}
}
function renderIcDetail(ic,pid){
  const card=$("detailIcCard"),title=$("detailIcTitle"),meta=$("detailIcMeta"),btn=$("detailIcRefresh");if(!card)return;
  if(!ic){title.textContent="Niepowiązane";meta.textContent="Wyszukaj część w Inter Cars i wybierz „Powiąż z kartoteką”.";btn.disabled=true;return}
  const eans=Array.isArray(ic.eans)?ic.eans:[];const stocks=Array.isArray(ic.stock)?ic.stock:[];
  title.textContent=`${ic.brand||"Inter Cars"} · ${ic.ic_index||ic.ic_sku||""}`;
  meta.innerHTML=`SKU IC: <b>${esc(ic.ic_sku||"—")}</b> · EAN/GTIN: ${eans.length?eans.map(x=>`<button class="code-copy mini-code" data-copy-code="${esc(x)}">${esc(x)}</button>`).join(" "):"—"}<br>Stan ${esc(ic.location_code||"ścieżka logistyczna")}: <b>${(+ic.stock_qty||0).toFixed(0)}</b> · cena klienta netto: <b>${money(ic.customer_price_net)}</b> · katalogowa netto: <b>${money(ic.list_price_net)}</b>${ic.checked_at?` · ${esc(String(ic.checked_at).replace("T"," ").slice(0,16))}`:""}`;
  card.querySelectorAll("[data-copy-code]").forEach(b=>b.onclick=()=>copyCode(b.dataset.copyCode));btn.disabled=false;btn.onclick=async()=>{btn.disabled=true;try{await api(`/api/product/${pid}/intercars/sync`,{method:"POST",body:"{}"});toast("Inter Cars: dane odświeżone");openProductDetail(pid)}catch(e){toast(e.code==="ic_not_linked"?"Produkt nie jest powiązany z Inter Cars":"Nie udało się odświeżyć Inter Cars")}finally{btn.disabled=false}}
}
async function openProductDetail(id){try{
  const d=await api(`/api/product/${id}/detail`);S.detailProduct=d;const p=d.product;renderMbAvailability(d.availability,null,d.bridge_status);
  $("detailName").textContent=p.name||"Karta produktu";$("detailSubtitle").innerHTML=(p.oem_no||p.sku)?`<button class="detail-code-copy" data-copy-code="${esc(p.oem_no||p.sku)}" title="Kliknij, aby skopiować">${esc(p.oem_no||p.sku)}</button>`:"bez numeru";
  $("detailSubtitle").querySelector("[data-copy-code]")?.addEventListener("click",e=>copyCode(e.currentTarget.dataset.copyCode));
  $("detailDiagramPosition").textContent=p.diagram_position||"—";$("detailFigurePos").textContent="poz. "+(p.diagram_position||"—");$("detailStock").textContent=`${(+p.stock_qty).toFixed(2)} ${p.unit}`;$("detailLocation").textContent=p.location_code||"—";$("detailBuy").textContent=money(p.purchase_price);$("detailSale").textContent=money(p.sale_price);
  $("detailMeta").innerHTML=`<div><b>OEM:</b> ${p.oem_no?`<button class="code-copy mini-code" data-copy-code="${esc(p.oem_no)}">${esc(p.oem_no)}</button>`:"—"}</div><div><b>SKU:</b> ${p.sku?`<button class="code-copy mini-code" data-copy-code="${esc(p.sku)}">${esc(p.sku)}</button>`:"—"}</div><div><b>Kod skanera:</b> ${p.barcode?`<button class="code-copy mini-code" data-copy-code="${esc(p.barcode)}">${esc(p.barcode)}</button>`:"—"}</div><div><b>Dostawca:</b> ${esc(p.supplier_name||"—")}</div><div><b>Kategoria:</b> ${esc(p.category||"—")}</div><div><b>Pozycja na rysunku:</b> ${esc(p.diagram_position||"—")}</div><div><b>Stan min.:</b> ${(+p.min_qty).toFixed(2)}</div><div><b>Źródło Mercedes:</b> B2B / XENTRY</div>`;
  $("detailMeta").querySelectorAll("[data-copy-code]").forEach(b=>b.onclick=()=>copyCode(b.dataset.copyCode));
  const aliases=[p.oem_no,...d.aliases.map(a=>a.alias_no)].filter(Boolean);$("detailAliases").innerHTML=aliases.length?aliases.map((a,i)=>`<button class="alias-pill ${i===0?"primary":""}" data-copy-code="${esc(a)}" title="Kliknij, aby skopiować">${esc(a)}</button>`).join(""):'<span class="hint">Brak numerów powiązanych.</span>';$("detailAliases").querySelectorAll("[data-copy-code]").forEach(b=>b.onclick=()=>copyCode(b.dataset.copyCode));
  if(p.preview_image){$("detailImageWrap").className="product-image-wrap";const hot=(d.diagram_hotspots||[]).filter(h=>Number.isFinite(+h.diagram_marker_x)&&Number.isFinite(+h.diagram_marker_y)&&+h.diagram_marker_x>=0&&+h.diagram_marker_x<=1&&+h.diagram_marker_y>=0&&+h.diagram_marker_y<=1);let hs=hot.map(h=>{const m=mbStatusMeta(h.mb_status_code),pid=h.product_id||h.id||"";return `<button type="button" class="diagram-hotspot ${pid===p.id?"current":""} ${pid?"":"catalog-only"}" ${pid?`data-hotspot-product="${pid}"`:""} style="left:${(+h.diagram_marker_x*100).toFixed(2)}%;top:${(+h.diagram_marker_y*100).toFixed(2)}%"><span>${esc(h.diagram_position||"•")}</span><span class="hotspot-tip"><b>Poz. ${esc(h.diagram_position||"—")} · ${esc(h.oem_no||h.sku||"—")}</b>${esc(h.name||"Część Mercedes")}<br>${pid?`Stan MB Auto Serwis: ${(+h.stock_qty).toFixed(2)} ${esc(h.unit)}<br>Status z importu B2B: ${esc(m.label)}<br><small>Kliknij, aby otworzyć kartotekę</small>`:`<small>Pozycja katalogowa — brak kartoteki w magazynie</small>`}</span></button>`}).join("");$("detailImageWrap").innerHTML=`<div class="diagram-stage"><img src="${esc(p.preview_image)}" alt="Rysunek katalogowy Mercedes B2B / XENTRY">${hs}<div class="diagram-caption">Pozycja tej części: <b>${esc(p.diagram_position||"—")}</b>${p.diagram_position&&!hot.length?` · brak pewnych współrzędnych — bez fałszywego markera`:""}</div></div>`;document.querySelectorAll("[data-hotspot-product]").forEach(b=>b.onclick=e=>{e.preventDefault();if(+b.dataset.hotspotProduct!==p.id)openProductDetail(+b.dataset.hotspotProduct)})
  }else{$("detailImageWrap").className="product-image-empty";$("detailImageWrap").innerHTML=`Brak rysunku z Mercedes B2B / XENTRY${p.diagram_position?`<br><b>Pozycja: ${esc(p.diagram_position)}</b>`:""}`}
  renderIcDetail(d.intercars,id);
  $("detailHistory").innerHTML=d.movements.length?`<div class="tablewrap"><table class="compact"><thead><tr><th>Data</th><th>Dokument</th><th>Typ</th><th>Ilość</th><th>Cena</th><th>Nr zewn.</th><th>Uwagi</th></tr></thead><tbody>${d.movements.map(m=>`<tr><td>${esc(m.move_date)}</td><td>${esc(m.parent_document_no||m.document_no)}</td><td><span class="badge ${esc(m.move_type)}">${esc(m.move_type)}</span></td><td>${(+m.quantity).toFixed(2)}</td><td>${money(m.unit_price)}</td><td>${esc(m.external_no||m.reference_no||"—")}</td><td>${esc(m.note||"")}</td></tr>`).join("")}</tbody></table></div>`:'<div class="hint">Brak ruchów magazynowych.</div>';
  $("detailOrders").innerHTML=d.documents.length?d.documents.map(x=>`<div class="order-card doc-hover"><div><b>${esc(x.document_no)}</b> · <span class="badge ${esc(x.doc_type)}">${esc(x.doc_type)}</span><br><small>${esc(x.doc_date)} · zewn. ${esc(x.external_no||"—")} · ${esc(x.supplier_name||"—")}</small></div><div><b>${money(x.value)}</b><br><button class="btn mini" data-detail-doc="${x.id}">Podgląd / edycja</button></div></div>`).join(""):'<div class="hint">Brak dokumentów dla tego produktu.</div>';
  $("detailAlts").innerHTML=`<div class="detail-alt-section"><h4>Zamienniki w magazynie</h4>${d.alternatives.length?d.alternatives.map(a=>`<div class="alt-card"><div><b>${esc(a.oem_no||a.sku||"—")} · ${esc(a.name)}</b><small>Stan ${(+a.stock_qty).toFixed(2)} · ${esc(a.location_code||"bez lokalizacji")}</small></div><button class="btn mini" data-open-alt="${a.id}">Otwórz</button></div>`).join(""):'<div class="hint">Brak lokalnych zamienników.</div>'}</div><div class="detail-alt-section"><h4>Zamienniki Inter Cars</h4>${d.external_alternatives.length?d.external_alternatives.map(a=>`<div class="alt-card"><div><b>${esc(a.brand||"")} ${esc(a.external_index||a.external_sku||"")} · ${esc(a.name||"")}</b><small>Stan ${(+a.last_stock||0).toFixed(0)} · netto ${money(a.last_price_net)}</small></div></div>`).join(""):'<div class="hint">Brak zapisanych odpowiedników Inter Cars.</div>'}<button class="btn" id="manageAlternativesDetail">Zarządzaj / powiąż z Inter Cars</button></div>`;
  document.querySelectorAll("[data-detail-doc]").forEach(b=>b.onclick=()=>openDocument(+b.dataset.detailDoc));document.querySelectorAll("[data-open-alt]").forEach(b=>b.onclick=()=>openProductDetail(+b.dataset.openAlt));$("manageAlternativesDetail")?.addEventListener("click",()=>{$("productDetailModal").classList.remove("show");page("alternatives");$("altBaseProduct").value=id;loadAlternatives()});
  $("detailArchive").classList.toggle("hidden",!p.active);$("detailRestore").classList.toggle("hidden",!!p.active);["detailOutRw","detailOutWz","detailInPz"].forEach(k=>$(k).disabled=!p.active);$("detailArchive").onclick=()=>archiveOrDeleteProduct(id);$("detailRestore").onclick=()=>restoreProduct(id);$("detailEdit").onclick=()=>{$("productDetailModal").classList.remove("show");openProduct(id)};$("detailEnrichB2b").onclick=()=>copyCode(p.oem_no||p.sku);$("detailOutRw").onclick=()=>openQuickMovement(id,"RW");$("detailOutWz").onclick=()=>openQuickMovement(id,"WZ");$("detailInPz").onclick=()=>openQuickMovement(id,"PZ");detailTab("history");$("productDetailModal").classList.add("show")
}catch(e){toast("Nie udało się otworzyć karty produktu")}}

function renderIcResults(){
  $("icSearchInfo").textContent=`Znaleziono: ${S.icResults.length}`;
  $("icResults").innerHTML=S.icResults.length?S.icResults.map((x,i)=>{const eans=(x.eans||[]).map(e=>`<button class="code-copy mini-code" data-copy-code="${esc(e)}">${esc(e)}</button>`).join(" ");const stocks=(x.stock_locations||[]).map(st=>`${esc(st.location||"?")}: <b>${(+st.availability||0).toFixed(0)}</b>`).join(" · ");return `<div class="ic-card"><div class="ic-main"><b>${esc(x.brand||"")} ${esc(x.index||x.sku||"")}</b><span>${esc(x.name||x.description||"")}</span><small>SKU: ${esc(x.sku||"—")} · EAN/GTIN: ${eans||"—"}<br>${stocks||`Stan: ${(+x.stock||0).toFixed(0)}`} · cena klienta netto: <b>${money(x.price_net)}</b> · katalogowa netto: ${money(x.list_price_net)}</small></div><div class="ic-actions"><button class="btn mini" data-ic-link="${i}">Powiąż z kartoteką</button><button class="btn mini" data-ic-alt="${i}">Zapisz jako zamiennik</button><button class="btn mini primary" data-ic-only="${i}">Dodaj do magazynu</button></div></div>`}).join(""):'<div class="hint">Brak wyników.</div>';
  $("icResults").querySelectorAll("[data-copy-code]").forEach(b=>b.onclick=()=>copyCode(b.dataset.copyCode));document.querySelectorAll("[data-ic-link]").forEach(b=>b.onclick=()=>linkIcToBase(+b.dataset.icLink));document.querySelectorAll("[data-ic-alt]").forEach(b=>b.onclick=()=>saveIcAlternative(+b.dataset.icAlt));document.querySelectorAll("[data-ic-only]").forEach(b=>b.onclick=()=>importIcOnly(+b.dataset.icOnly));
}
async function linkIcToBase(i){const pid=+$("altBaseProduct").value;if(!pid)return toast("Wybierz część bazową");const x=S.icResults[i];try{await api("/api/intercars/link-product",{method:"POST",body:JSON.stringify({product_id:pid,sku:x.sku,index:x.index})});toast("Inter Cars powiązany z kartoteką");if(S.detailProduct?.product?.id===pid)openProductDetail(pid)}catch(e){toast("Nie udało się powiązać Inter Cars")}}
async function importIcOnly(i){const x=S.icResults[i];try{const d=await api("/api/intercars/import-product",{method:"POST",body:JSON.stringify(x)});toast(d.existing?"Kartoteka już istnieje — dane IC zapisane":"Dodano kartotekę z Inter Cars");await loadProducts()}catch(e){toast("Nie udało się dodać kartoteki")}}
async function loadIntegrationSettings(){try{const d=await api("/api/integrations/settings");$("woo_url").value=d.woo_url||"https://sklep.mbautoserwis.com";$("woo_key").placeholder=d.has_woo_key?"zapisany — pozostaw puste":"ck_...";$("woo_secret").placeholder=d.has_woo_key?"zapisany — pozostaw puste":"cs_...";$("woo_auto_enabled").checked=!!d.woo_auto_enabled;$("woo_auto_minutes").value=d.woo_auto_minutes||10;$("ic_base_url").value=d.ic_base_url;$("ic_token_url").value=d.ic_token_url;$("ic_location").value=d.ic_location||"";$("ic_ship_to").value=d.ic_ship_to||"";$("ic_client_id").placeholder=d.has_ic_key?"zapisany — pozostaw puste":"ClientID";$("ic_client_secret").placeholder=d.has_ic_key?"zapisany — pozostaw puste":"ClientSecret";$("syncWooLocal").disabled=!d.has_local_sales_db;$("integrationLogs").innerHTML=d.logs.length?d.logs.map(x=>`<div class="listitem"><div><b>${esc(x.source)}</b> · ${esc(x.result)}<br><small>${esc((x.synced_at||"").replace("T"," "))} · rekordy ${x.records_seen} · ruchy ${x.movements_created} · problemy ${x.issues_count}</small></div><small>${esc(x.message||"")}</small></div>`).join(""):'<div class="hint">Brak synchronizacji.</div>'}catch(e){}}
async function saveIntegrationSettings(){const data={woo_url:$("woo_url").value,woo_key:$("woo_key").value,woo_secret:$("woo_secret").value,woo_auto_enabled:$("woo_auto_enabled").checked,woo_auto_minutes:+$("woo_auto_minutes").value||10,ic_base_url:$("ic_base_url").value,ic_token_url:$("ic_token_url").value,ic_client_id:$("ic_client_id").value,ic_client_secret:$("ic_client_secret").value,ic_location:$("ic_location").value,ic_ship_to:$("ic_ship_to").value};await api("/api/integrations/settings",{method:"POST",body:JSON.stringify(data)});$("woo_key").value=$("woo_secret").value=$("ic_client_id").value=$("ic_client_secret").value="";toast("Ustawienia zapisane");await loadIntegrationSettings()}
$("syncInterCarsAll")?.addEventListener("click",async()=>{try{await saveIntegrationSettings();toast("Inter Cars: synchronizacja…");const d=await api("/api/intercars/sync-all",{method:"POST",body:"{}"});toast(`Inter Cars: odświeżono ${d.synced}, błędy ${d.failed}`);await loadProducts()}catch(e){toast("Nie udało się zsynchronizować Inter Cars")}});
$("icCustomerInfo")?.addEventListener("click",async()=>{try{await saveIntegrationSettings();const d=await api("/api/intercars/customer",{method:"POST",body:"{}"});alert("Inter Cars — dane konta:\n\n"+JSON.stringify(d.data,null,2))}catch(e){toast("Nie udało się pobrać danych konta IC")}});
function page(p){if(p==="cart")p="products";["dashboard","products","movements","documents","alternatives","integrations","b2b","suppliers","locations","contractors"].forEach(x=>$(x+"Page").classList.toggle("hidden",x!==p));if($("cartPage"))$("cartPage").classList.add("hidden");document.querySelectorAll("nav [data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===p));$("title").textContent={dashboard:"Dashboard magazynu",products:"Kartoteka części",movements:"Ruchy magazynowe",documents:"Dokumenty magazynowe",alternatives:"Zamienniki i odpowiedniki",integrations:"Sklep WooCommerce BETA",b2b:"Mercedes B2B Bridge",suppliers:"Dostawcy",locations:"Lokalizacje magazynowe",contractors:"Kontrahenci / NIP"}[p];if(p==="products")loadProducts();if(p==="movements")loadMovements();if(p==="documents")loadDocuments();if(p==="alternatives"){refreshAltProductSelects();if($("altBaseProduct").value)loadAlternatives()}if(p==="integrations"){loadIntegrationSettings();loadIntegrationIssues()}if(p==="b2b"){loadB2bSettings();loadB2bCaptures()}if(p==="contractors")loadContractors();if(p==="suppliers")loadSuppliers()}
async function loadAll(){await Promise.all([loadSuppliers(),loadLocations(),loadContractors()]);await Promise.all([loadProducts(),loadMovements(),loadDocuments(),loadSummary(),loadIntegrationSettings()])}
$("productForm").onsubmit=async e=>{e.preventDefault();const d={};["sku","oem_no","barcode","name","category","supplier_id","location_id","min_qty","purchase_price","sale_price","unit","diagram_position"].forEach(k=>d[k]=$(k).value);d.aliases=$("productAliasesInput").value;d.notes=$("product_notes").value;try{const id=$("productId").value;const r=id?await api("/api/product/"+id,{method:"PUT",body:JSON.stringify(d)}):await api("/api/product",{method:"POST",body:JSON.stringify(d)});$("productModal").classList.remove("show");toast(d.oem_no?"Część zapisana. Kliknij OEM, skopiuj numer i zaimportuj widoczną część z B2B/XENTRY.":"Część zapisana");await Promise.all([loadProducts(),loadSummary()]);if(!id&&r.id)setTimeout(()=>openProductDetail(r.id),300)}catch(e){toast(e.code==="duplicate_code"?"SKU/OEM/kod już istnieje":"Nie udało się zapisać")}};

// ===== FINAL STABLE IC/OE PATCH =====
function icBaseProduct(){const pid=+$('altBaseProduct')?.value;return S.products.find(p=>+p.id===pid)||null}
function icResultImage(x){return x?.image_url?`<img class="ic-thumb" src="${esc(x.image_url)}" alt="Zdjęcie produktu Inter Cars" onerror="this.style.display='none'">`:''}
async function searchInterCarsPatched(){
  let mode=$('icSearchMode').value;let q=$('icSearchQuery').value.trim();const base=icBaseProduct();const pid=base?.id||0;
  if(mode==='oe'&&!q&&base)q=base.oem_no||base.sku||'';
  if(!q&&mode!=='oe')return toast('Wpisz numer, fragment, SKU, EAN/GTIN lub indeks');
  $('icResults').innerHTML='<div class="hint">Szukam w Inter Cars i lokalnym indeksie…</div>';
  try{
    const d=await api(`/api/intercars/search?mode=${encodeURIComponent(mode)}&q=${encodeURIComponent(q)}&product_id=${pid}`);
    S.icResults=d.items||[];
    $('icSearchInfo').textContent=`Znaleziono: ${S.icResults.length}${d.remote_count!=null?` · API ${d.remote_count} · cache ${d.cache_count||0}`:''}${d.note?` · ${d.note}`:''}${d.remote_error?` · API: ${d.remote_error}`:''}`;
    renderIcResults();
  }catch(e){$('icResults').innerHTML='';toast(e.code==='ic_http'?`Inter Cars: HTTP ${e.data.status}`:'Nie udało się wyszukać w Inter Cars')}
}
$('icSearchBtn').onclick=searchInterCarsPatched;
$('icSearchQuery').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchInterCarsPatched()}});
$('icUseOemBtn')?.addEventListener('click',()=>{const p=icBaseProduct();if(!p)return toast('Najpierw wybierz część bazową');$('icSearchMode').value='oe';$('icSearchQuery').value=p.oem_no||p.sku||'';searchInterCarsPatched()});

function renderIcResults(){
  if(!$('icResults'))return;
  if(!$('icSearchInfo').textContent)$('icSearchInfo').textContent=`Znaleziono: ${S.icResults.length}`;
  $('icResults').innerHTML=S.icResults.length?S.icResults.map((x,i)=>{
    const eans=(x.eans||[]).map(e=>`<button class="code-copy mini-code" data-copy-code="${esc(e)}">${esc(e)}</button>`).join(' ');
    const stocks=(x.stock_locations||[]).map(st=>`${esc(st.location||'?')}: <b>${(+st.availability||0).toFixed(0)}</b>`).join(' · ');
    const source=x.source==='cache'?'cache lokalny':x.source==='oe_link'?'powiązanie OE':'IC API';
    const linked=x.source==='oe_link';
    return `<div class="ic-card"><div class="ic-main">${icResultImage(x)}<b>${esc(x.brand||'')} ${x.index?`<button class="code-copy" data-copy-code="${esc(x.index)}">${esc(x.index)}</button>`:esc(x.sku||'')}<span class="ic-source">${esc(source)}</span></b><span>${esc(x.name||x.description||'')}</span><small>SKU: ${x.sku?`<button class="code-copy mini-code" data-copy-code="${esc(x.sku)}">${esc(x.sku)}</button>`:'—'} · nr artykułu: ${x.article_number?`<button class="code-copy mini-code" data-copy-code="${esc(x.article_number)}">${esc(x.article_number)}</button>`:'—'} · TecDoc: ${esc(x.tecdoc||'—')}<br>EAN/GTIN: ${eans||'—'}<br>${stocks||((x.stock!=null)?`Stan: <b>${(+x.stock||0).toFixed(0)}</b>`:'Stan: —')} ${x.price_net!=null?`· cena klienta netto: <b>${money(x.price_net)}</b> · katalogowa netto: ${money(x.list_price_net)}`:''}</small></div><div class="ic-actions">${linked&&x.oe_link_id?`<button class="btn mini danger" data-ic-unlink="${x.oe_link_id}">Usuń powiązanie OE</button>`:`<button class="btn mini" data-ic-link="${i}">Powiąż z OE / kartoteką</button><button class="btn mini" data-ic-alt="${i}">Zapisz jako zamiennik</button><button class="btn mini primary" data-ic-only="${i}">Dodaj do magazynu</button>`}</div></div>`
  }).join(''):'<div class="hint">Brak wyników. Dla zupełnie nowego numeru OE standardowe IC API nie udostępnia cross-reference; po ręcznym powiązaniu system zapamięta relację na przyszłość.</div>';
  $('icResults').querySelectorAll('[data-copy-code]').forEach(b=>b.onclick=()=>copyCode(b.dataset.copyCode));
  $('icResults').querySelectorAll('[data-ic-link]').forEach(b=>b.onclick=()=>linkIcToBase(+b.dataset.icLink));
  $('icResults').querySelectorAll('[data-ic-alt]').forEach(b=>b.onclick=()=>saveIcAlternative(+b.dataset.icAlt));
  $('icResults').querySelectorAll('[data-ic-only]').forEach(b=>b.onclick=()=>importIcOnly(+b.dataset.icOnly));
  $('icResults').querySelectorAll('[data-ic-unlink]').forEach(b=>b.onclick=async()=>{try{await api('/api/intercars/oe-link/'+b.dataset.icUnlink,{method:'DELETE'});toast('Usunięto powiązanie OE');searchInterCarsPatched();if(S.detailProduct?.product?.id)openProductDetail(S.detailProduct.product.id)}catch(e){toast('Nie udało się usunąć powiązania')}});
}
async function linkIcToBase(i){
  const pid=+$('altBaseProduct').value;if(!pid)return toast('Najpierw wybierz część bazową OE');const x=S.icResults[i];
  try{await api('/api/intercars/link-product',{method:'POST',body:JSON.stringify({product_id:pid,sku:x.sku,index:x.index})});toast('Powiązano OEM z produktem Inter Cars');await loadAlternatives();if(S.detailProduct?.product?.id===pid)openProductDetail(pid)}catch(e){toast(e.code==='ic_not_found'?'Inter Cars nie znalazł tego kodu':'Nie udało się powiązać produktu')}
}

function renderIcDetail(ic,pid){
  const card=$('detailIcCard'),title=$('detailIcTitle'),meta=$('detailIcMeta'),btn=$('detailIcRefresh');if(!card)return;
  const matches=Array.isArray(S.detailProduct?.intercars_matches)?S.detailProduct.intercars_matches:[];
  if(!ic&&!matches.length){title.textContent='Niepowiązane';meta.textContent='Wybierz produkt Inter Cars w zakładce Zamienniki i kliknij „Powiąż z OE / kartoteką”.';btn.disabled=true;return}
  const base=ic||matches[0]||{};const eans=Array.isArray(base.eans)?base.eans:[];
  title.textContent=`${base.brand||'Inter Cars'} · ${base.ic_index||base.index||base.ic_sku||base.sku||''}`;
  const matchHtml=matches.length?`<div class="ic-oe-links">${matches.map(m=>`<div class="ic-oe-link">${m.image_url?`<img src="${esc(m.image_url)}" alt="">`:''}<div><b>${esc(m.brand||'IC')} ${m.ic_index?`<button class="code-copy mini-code" data-copy-code="${esc(m.ic_index)}">${esc(m.ic_index)}</button>`:esc(m.ic_sku||'')}</b><div class="codes">SKU ${esc(m.ic_sku||'—')} · ${esc(m.name||'')} · EAN ${(m.eans||[]).join(', ')||'—'}</div></div></div>`).join('')}</div>`:'';
  meta.innerHTML=`SKU IC: <b>${esc(base.ic_sku||base.sku||'—')}</b> · EAN/GTIN: ${eans.length?eans.map(x=>`<button class="code-copy mini-code" data-copy-code="${esc(x)}">${esc(x)}</button>`).join(' '):'—'}${ic?`<br>Stan ${esc(ic.location_code||'ścieżka logistyczna')}: <b>${(+ic.stock_qty||0).toFixed(0)}</b> · cena klienta netto: <b>${money(ic.customer_price_net)}</b> · katalogowa netto: <b>${money(ic.list_price_net)}</b>`:''}${matches.length?`<br>Powiązane produkty IC: <b>${matches.length}</b>`:''}${matchHtml}`;
  card.querySelectorAll('[data-copy-code]').forEach(b=>b.onclick=()=>copyCode(b.dataset.copyCode));btn.disabled=!ic;btn.onclick=async()=>{if(!ic)return;btn.disabled=true;try{await api(`/api/product/${pid}/intercars/sync`,{method:'POST',body:'{}'});toast('Inter Cars: dane odświeżone');openProductDetail(pid)}catch(e){toast('Nie udało się odświeżyć Inter Cars')}finally{btn.disabled=false}}
}


// ===== HOTSPOT + SORT PATCH =====
function productSortDirLabel(){
  const b=$("productSortDir"); if(!b)return;
  const d=b.dataset.dir||"asc",k=$("productSort")?.value||"name";
  const numeric=["stock","purchase","catalog","created"].includes(k);
  b.textContent=numeric?(d==="asc"?"0 → 9":"9 → 0"):(d==="asc"?"A → Z":"Z → A");
  b.title=d==="asc"?"Rosnąco — kliknij, aby odwrócić":"Malejąco — kliknij, aby odwrócić";
}
async function loadProductsSorted(){
  const raw=$("productSearch")?.value||"",q=encodeURIComponent(raw),low=$("lowOnly")?.checked?"1":"",active=$("productActive")?.value||"1";
  const sort=$("productSort")?.value||"name",dir=$("productSortDir")?.dataset.dir||"asc";
  const d=await api(`/api/products?q=${q}&low=${low}&active=${encodeURIComponent(active)}&sort=${encodeURIComponent(sort)}&dir=${encodeURIComponent(dir)}`);
  S.products=d.products;$("productsLabel").textContent=d.products.length+" indeksów";const nq=normCode(raw);
  $("productsBody").innerHTML=d.products.map(p=>{const vals=[p.sku,p.oem_no,p.barcode,...String(p.aliases||"").split(",")].map(normCode),exact=nq&&vals.includes(nq);return `<tr class="${p.active?"":"archived-row"} ${raw?"search-hit":""} ${exact?"search-exact":""}" data-product-row="${p.id}"><td><input type="checkbox" class="product-select" value="${p.id}" aria-label="Zaznacz ${esc(p.name)}"></td><td>${p.sku?`<button class="code-copy" data-copy-code="${esc(p.sku)}" title="Kliknij, aby skopiować SKU">${esc(p.sku)}</button>`:"—"}</td><td>${p.oem_no?`<button class="code-copy primary-code" data-copy-code="${esc(p.oem_no)}" title="Kliknij, aby skopiować OEM">${esc(p.oem_no)}</button>`:"—"}${p.aliases?`<br><small>${esc(p.aliases)}</small>`:""}</td><td><b>${esc(p.name)}</b><br><small>${esc(p.category||"")}</small></td><td>${esc(p.location_code||"—")}</td><td class="${(+p.stock_qty)<= (+p.min_qty)?"low":"ok"}">${(+p.stock_qty).toFixed(2)} ${esc(p.unit)}</td><td>${(+p.min_qty).toFixed(2)}</td><td>${mbListStatus(p)}</td><td>${money(p.purchase_price)}</td><td>${money(p.sale_price)}</td><td>${esc(p.supplier_name||"—")}</td><td class="row-actions"><button class="btn mini" data-open-product="${p.id}">Otwórz</button><button class="btn mini" data-edit="${p.id}">Edytuj</button></td></tr>`}).join("");
  document.querySelectorAll("[data-copy-code]").forEach(b=>b.onclick=e=>{e.stopPropagation();copyCode(b.dataset.copyCode)});
  document.querySelectorAll("[data-open-product]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProductDetail(+b.dataset.openProduct)});
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=e=>{e.stopPropagation();openProduct(+b.dataset.edit)});
  document.querySelectorAll("[data-product-row]").forEach(r=>r.ondblclick=e=>{if(!e.target.closest("button,input"))openProductDetail(+r.dataset.productRow)});
  if($("selectAllProducts"))$("selectAllProducts").checked=false;refreshMoveProducts();refreshAltProductSelects();productSortDirLabel();
  if(raw)requestAnimationFrame(()=>{const x=document.querySelector("#productsBody .search-exact")||document.querySelector("#productsBody .search-hit");x?.scrollIntoView({behavior:"smooth",block:"center"})});
}
loadProducts=loadProductsSorted;
if($("productSort"))$("productSort").onchange=()=>{productSortDirLabel();loadProductsSorted()};
if($("productSortDir"))$("productSortDir").onclick=()=>{const b=$("productSortDir");b.dataset.dir=(b.dataset.dir||"asc")==="asc"?"desc":"asc";productSortDirLabel();loadProductsSorted()};
if($("productActive"))$("productActive").onchange=loadProductsSorted;
if($("lowOnly"))$("lowOnly").onchange=loadProductsSorted;
if($("productSearch"))$("productSearch").oninput=()=>{clearTimeout(window.ps);window.ps=setTimeout(loadProductsSorted,160)};
productSortDirLabel();

function placeDiagramHotspots(stage){
  if(!stage)return;const img=stage.querySelector("img");if(!img||!img.complete||!img.naturalWidth||!img.naturalHeight)return;
  const sr=stage.getBoundingClientRect(),ir=img.getBoundingClientRect();
  stage.querySelectorAll(".diagram-hotspot[data-hx][data-hy]").forEach(h=>{
    const x=Number(h.dataset.hx),y=Number(h.dataset.hy);if(!Number.isFinite(x)||!Number.isFinite(y)||x<0||x>1||y<0||y>1){h.classList.remove("placed");return}
    h.style.left=`${ir.left-sr.left+x*ir.width}px`;h.style.top=`${ir.top-sr.top+y*ir.height}px`;h.classList.add("placed");
  });
}
function bindDiagramHotspots(root){
  const stage=root?.querySelector?.(".diagram-stage");if(!stage)return;const img=stage.querySelector("img");if(!img)return;
  const run=()=>requestAnimationFrame(()=>placeDiagramHotspots(stage));img.addEventListener("load",run,{once:false});if(img.complete)run();
  if(window.ResizeObserver){stage.__mbResizeObserver?.disconnect?.();stage.__mbResizeObserver=new ResizeObserver(run);stage.__mbResizeObserver.observe(stage);stage.__mbResizeObserver.observe(img)}else window.addEventListener("resize",run,{passive:true});
}

const _openProductDetailHotspotBase=openProductDetail;
openProductDetail=async function(id){
  await _openProductDetailHotspotBase(id);
  const wrap=$("detailImageWrap"),stage=wrap?.querySelector?.(".diagram-stage");if(!stage)return;
  // Stare wersje wpisywały left/top w procentach panelu. Przepisujemy je na dane znormalizowane względem samego obrazu.
  stage.querySelectorAll(".diagram-hotspot").forEach(h=>{
    const m=(h.getAttribute("style")||"").match(/left:\s*([\d.]+)%;\s*top:\s*([\d.]+)%/i);
    if(m){h.dataset.hx=(+m[1]/100).toFixed(6);h.dataset.hy=(+m[2]/100).toFixed(6);h.style.left="0px";h.style.top="0px"}
    const n=h.querySelector(":scope > span:not(.hotspot-tip)");if(n)n.classList.add("hotspot-badge");
  });
  bindDiagramHotspots(wrap);
};



// ===== FINAL UX PATCH — zoom diagramu, zaznaczenia, usuwanie, sortowanie =====
function updateProductSelectionUi(){
  const boxes=[...document.querySelectorAll('.product-select')],checked=boxes.filter(x=>x.checked);
  const count=$('selectedProductsCount');if(count)count.textContent=`${checked.length} zazn.`;
  const del=$('deleteSelectedProducts');if(del)del.disabled=!checked.length;
  const all=$('selectAllProducts');if(all){all.checked=boxes.length>0&&checked.length===boxes.length;all.indeterminate=checked.length>0&&checked.length<boxes.length}
}
function bindProductSelectionUi(){
  document.querySelectorAll('.product-select').forEach(x=>x.addEventListener('change',updateProductSelectionUi));updateProductSelectionUi();
}
const _loadProductsSortedUxBase=loadProductsSorted;
loadProductsSorted=async function(){await _loadProductsSortedUxBase();bindProductSelectionUi();updateSortHeaderUi()};
loadProducts=loadProductsSorted;
if($('selectAllProducts'))$('selectAllProducts').onchange=e=>{document.querySelectorAll('.product-select').forEach(x=>x.checked=e.target.checked);updateProductSelectionUi()};
if($('selectAllVisibleProducts'))$('selectAllVisibleProducts').onclick=()=>{document.querySelectorAll('.product-select').forEach(x=>x.checked=true);updateProductSelectionUi()};
if($('clearProductSelection'))$('clearProductSelection').onclick=()=>{document.querySelectorAll('.product-select').forEach(x=>x.checked=false);updateProductSelectionUi()};
if($('deleteSelectedProducts'))$('deleteSelectedProducts').onclick=async()=>{
  const ids=[...document.querySelectorAll('.product-select:checked')].map(x=>+x.value).filter(Boolean);if(!ids.length)return;
  if(!confirm(`Trwale usunąć ${ids.length} zaznaczonych pozycji?\n\nSystem najpierw utworzy automatyczną kopię bazy. Powiązane ruchy tych pozycji zostaną również usunięte.`))return;
  try{const r=await api('/api/products/bulk-delete',{method:'POST',body:JSON.stringify({ids,confirm:'USUN'})});toast(`Usunięto ${r.deleted} pozycji · kopia: ${r.backup_filename}`);await Promise.all([loadProducts(),loadMovements(),loadDocuments(),loadSummary()])}catch(e){toast('Nie udało się usunąć zaznaczonych pozycji')}
};
if($('clearDatabaseBtn'))$('clearDatabaseBtn').onclick=async()=>{
  const phrase=prompt('To wyczyści dane magazynowe, dokumenty, kontrahentów, dostawców i lokalizacje.\nPrzed operacją powstanie kopia bezpieczeństwa.\n\nWpisz dokładnie: WYCZYSC BAZE');
  if(phrase!=='WYCZYSC BAZE')return toast('Anulowano czyszczenie bazy');
  if(!confirm('Ostatnie potwierdzenie: wyczyścić dane systemu?'))return;
  try{const r=await api('/api/database/reset',{method:'POST',body:JSON.stringify({confirm:'WYCZYSC BAZE'})});toast(`Baza wyczyszczona · kopia: ${r.backup_filename}`);await loadAll();page('dashboard')}catch(e){toast('Nie udało się wyczyścić bazy')}
};
function updateSortHeaderUi(){
  const key=$('productSort')?.value||'name',dir=$('productSortDir')?.dataset.dir||'asc';
  document.querySelectorAll('.th-sort').forEach(b=>{b.classList.toggle('active',b.dataset.sortKey===key);b.dataset.dir=b.dataset.sortKey===key?dir:'';b.setAttribute('aria-sort',b.dataset.sortKey===key?(dir==='asc'?'ascending':'descending'):'none')});
}
document.querySelectorAll('.th-sort').forEach(b=>b.onclick=()=>{
  const key=b.dataset.sortKey,sel=$('productSort'),dir=$('productSortDir');if(!sel||!dir)return;
  if(sel.value===key)dir.dataset.dir=(dir.dataset.dir||'asc')==='asc'?'desc':'asc';else{sel.value=key;dir.dataset.dir='asc'}
  productSortDirLabel();updateSortHeaderUi();loadProductsSorted();
});

let diagramZoom=1;
function diagramZoomLabel(){const el=document.querySelector('#detailImageWrap .diagram-zoom-value');if(el)el.textContent=Math.round(diagramZoom*100)+'%'}
function applyDiagramZoom(stage,zoom,fit=false){
  const img=stage?.querySelector('img'),viewport=stage?.closest('.diagram-viewport');if(!img||!viewport)return;
  const run=()=>{
    if(!img.naturalWidth||!img.naturalHeight)return;
    if(!img.dataset.fitWidth){const vw=Math.max(300,viewport.clientWidth-120),vh=Math.max(260,Math.min(650,window.innerHeight*.58)-120);const fitScale=Math.min(1,vw/img.naturalWidth,vh/img.naturalHeight);img.dataset.fitWidth=String(Math.max(180,img.naturalWidth*fitScale));}
    const base=+img.dataset.fitWidth||Math.min(img.naturalWidth,900);diagramZoom=Math.max(.4,Math.min(3,zoom));
    img.style.maxWidth='none';img.style.maxHeight='none';img.style.width=(base*diagramZoom)+'px';img.style.height='auto';
    stage.style.width='max-content';stage.style.minWidth='100%';placeDiagramHotspots(stage);diagramZoomLabel();
    if(fit){viewport.scrollLeft=Math.max(0,(viewport.scrollWidth-viewport.clientWidth)/2);viewport.scrollTop=Math.max(0,(viewport.scrollHeight-viewport.clientHeight)/2)}
  }; if(img.complete)run();else img.addEventListener('load',run,{once:true});
}
function bindDiagramZoom(root){
  const viewport=root?.querySelector?.('.diagram-viewport'),stage=root?.querySelector?.('.diagram-stage');if(!viewport||!stage)return;
  diagramZoom=1;applyDiagramZoom(stage,1,true);
  root.querySelector('[data-diagram-zoom="in"]')?.addEventListener('click',()=>applyDiagramZoom(stage,diagramZoom+.2));
  root.querySelector('[data-diagram-zoom="out"]')?.addEventListener('click',()=>applyDiagramZoom(stage,diagramZoom-.2));
  root.querySelector('[data-diagram-zoom="fit"]')?.addEventListener('click',()=>{const img=stage.querySelector('img');if(img)delete img.dataset.fitWidth;applyDiagramZoom(stage,1,true)});
  root.querySelector('[data-diagram-zoom="100"]')?.addEventListener('click',()=>{const img=stage.querySelector('img');if(!img)return;img.dataset.fitWidth=String(img.naturalWidth);applyDiagramZoom(stage,1,true)});
  viewport.addEventListener('wheel',e=>{if(!e.ctrlKey)return;e.preventDefault();applyDiagramZoom(stage,diagramZoom+(e.deltaY<0?.1:-.1))},{passive:false});
  let drag=false,sx=0,sy=0,sl=0,st=0;
  viewport.addEventListener('pointerdown',e=>{if(e.target.closest('.diagram-hotspot,button'))return;drag=true;sx=e.clientX;sy=e.clientY;sl=viewport.scrollLeft;st=viewport.scrollTop;viewport.setPointerCapture?.(e.pointerId);viewport.classList.add('dragging')});
  viewport.addEventListener('pointermove',e=>{if(!drag)return;viewport.scrollLeft=sl-(e.clientX-sx);viewport.scrollTop=st-(e.clientY-sy)});
  const end=e=>{drag=false;viewport.classList.remove('dragging')};viewport.addEventListener('pointerup',end);viewport.addEventListener('pointercancel',end);
}
const _openProductDetailZoomBase=openProductDetail;
openProductDetail=async function(id){
  await _openProductDetailZoomBase(id);
  const wrap=$('detailImageWrap'),stage=wrap?.querySelector?.('.diagram-stage');if(!stage)return;
  // Dodaj obszar przewijania oraz sterowanie zoomem bez zmiany danych hotspotów.
  if(!wrap.querySelector('.diagram-viewport')){
    const toolbar=document.createElement('div');toolbar.className='diagram-toolbar';toolbar.innerHTML='<div class="diagram-toolbar-left"><button type="button" class="btn mini" data-diagram-zoom="out">−</button><span class="diagram-zoom-value">100%</span><button type="button" class="btn mini" data-diagram-zoom="in">＋</button><button type="button" class="btn mini" data-diagram-zoom="fit">Dopasuj</button><button type="button" class="btn mini" data-diagram-zoom="100">100%</button></div><small>Przeciągnij rysunek, aby go przesunąć · Ctrl + rolka = zoom</small>';
    const viewport=document.createElement('div');viewport.className='diagram-viewport';stage.parentNode.insertBefore(toolbar,stage);stage.parentNode.insertBefore(viewport,stage);viewport.appendChild(stage);
  }
  bindDiagramHotspots(wrap);bindDiagramZoom(wrap);
  wrap.querySelectorAll('[data-hotspot-product]').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();openProductDetail(+b.dataset.hotspotProduct)});
};


// ===== STABLE UX v2: paginacja, reset bez prompt(), zoom diagramu =====
S.productPage=S.productPage||1;
S.productPerPage=S.productPerPage||100;
S.selectedProductIds=S.selectedProductIds||new Set();

function renderProductPagination(){
  const total=S.products.length,per=Math.max(1,+S.productPerPage||100),pages=Math.max(1,Math.ceil(total/per));
  S.productPage=Math.max(1,Math.min(pages,+S.productPage||1));
  const a=(S.productPage-1)*per,b=Math.min(total,a+per);
  if($('productPageInfo'))$('productPageInfo').textContent=`Strona ${S.productPage} z ${pages} · ${total} pozycji · ${total?`${a+1}–${b}`:'0'}`;
  if($('productPrevPage'))$('productPrevPage').disabled=S.productPage<=1;
  if($('productNextPage'))$('productNextPage').disabled=S.productPage>=pages;
  return S.products.slice(a,b);
}
function stableProductRow(p,raw){
  const nq=normCode(raw),vals=[p.sku,p.oem_no,p.barcode,...String(p.aliases||'').split(',')].map(normCode),exact=nq&&vals.includes(nq);
  const checked=S.selectedProductIds.has(+p.id)?'checked':'';
  return `<tr class="${p.active?'':'archived-row'} ${raw?'search-hit':''} ${exact?'search-exact':''}" data-product-row="${p.id}"><td class="cell-select"><input type="checkbox" class="product-select" value="${p.id}" ${checked} aria-label="Zaznacz ${esc(p.name)}"></td><td class="cell-sku">${p.sku?`<button class="code-copy" data-copy-code="${esc(p.sku)}" title="Kliknij, aby skopiować SKU">${esc(p.sku)}</button>`:'—'}</td><td class="cell-oem">${p.oem_no?`<button class="code-copy primary-code" data-copy-code="${esc(p.oem_no)}" title="Kliknij, aby skopiować OEM">${esc(p.oem_no)}</button>`:'—'}${p.aliases?`<div class="related-code-text">${esc(p.aliases)}</div>`:''}</td><td class="cell-name"><b class="product-name-main">${esc(p.name)}</b>${p.category?`<small class="product-source">${esc(p.category)}</small>`:''}</td><td class="cell-location">${esc(p.location_code||'—')}</td><td class="cell-stock ${(+p.stock_qty)<=(+p.min_qty)?'low':'ok'}"><b>${(+p.stock_qty).toFixed(2)}</b><small>${esc(p.unit)}</small></td><td class="cell-min">${(+p.min_qty).toFixed(2)}</td><td class="cell-b2b">${mbListStatus(p)}</td><td class="cell-price"><b>${money(p.purchase_price)}</b><small>netto</small></td><td class="cell-price cell-sale"><b>${money(p.sale_price)}</b><small>netto</small></td><td class="cell-supplier">${esc(p.supplier_name||'—')}</td><td class="row-actions"><button class="btn mini" data-open-product="${p.id}">Otwórz</button><button class="btn mini edit-row" data-edit="${p.id}">Edytuj</button></td></tr>`;
}
function bindStableProductRows(raw){
  document.querySelectorAll('.product-select').forEach(x=>x.onchange=()=>{const id=+x.value;if(x.checked)S.selectedProductIds.add(id);else S.selectedProductIds.delete(id);stableSelectionUi()});
  document.querySelectorAll('[data-copy-code]').forEach(b=>b.onclick=e=>{e.stopPropagation();copyCode(b.dataset.copyCode)});
  document.querySelectorAll('[data-open-product]').forEach(b=>b.onclick=e=>{e.stopPropagation();openProductDetail(+b.dataset.openProduct)});
  document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=e=>{e.stopPropagation();openProduct(+b.dataset.edit)});
  document.querySelectorAll('[data-product-row]').forEach(r=>r.ondblclick=e=>{if(!e.target.closest('button,input'))openProductDetail(+r.dataset.productRow)});
  stableSelectionUi();
  if(raw)requestAnimationFrame(()=>{const x=document.querySelector('#productsBody .search-exact')||document.querySelector('#productsBody .search-hit');x?.scrollIntoView({behavior:'smooth',block:'center'})});
}
function stableSelectionUi(){
  const boxes=[...document.querySelectorAll('.product-select')],visibleIds=boxes.map(x=>+x.value),visibleSelected=visibleIds.filter(id=>S.selectedProductIds.has(id));
  if($('selectedProductsCount'))$('selectedProductsCount').textContent=`${S.selectedProductIds.size} zaznaczonych`;
  if($('deleteSelectedProducts'))$('deleteSelectedProducts').disabled=!S.selectedProductIds.size;
  if($('selectAllProducts')){$('selectAllProducts').checked=boxes.length>0&&visibleSelected.length===boxes.length;$('selectAllProducts').indeterminate=visibleSelected.length>0&&visibleSelected.length<boxes.length}
}
const _stableLoadBase=loadProductsSorted;
loadProductsSorted=async function(resetPage=false){
  const raw=$('productSearch')?.value||'',q=encodeURIComponent(raw),low=$('lowOnly')?.checked?'1':'',active=$('productActive')?.value||'1';
  const sort=$('productSort')?.value||'name',dir=$('productSortDir')?.dataset.dir||'asc';
  if(resetPage){S.productPage=1;S.selectedProductIds.clear();}
  const d=await api(`/api/products?q=${q}&low=${low}&active=${encodeURIComponent(active)}&sort=${encodeURIComponent(sort)}&dir=${encodeURIComponent(dir)}`);
  S.products=d.products||[];
  const pageRows=renderProductPagination();
  if($('productsLabel'))$('productsLabel').textContent=`${S.products.length} indeksów`;
  const totalQty=S.products.reduce((sum,p)=>sum+(Number(p.stock_qty)||0),0);
  const totalValue=S.products.reduce((sum,p)=>sum+(Number(p.stock_qty)||0)*(Number(p.purchase_price)||0),0);
  if($('productTotalQty'))$('productTotalQty').textContent=totalQty.toLocaleString('pl-PL',{maximumFractionDigits:2});
  if($('productTotalValue'))$('productTotalValue').textContent=totalValue.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2})+' zł';
  $('productsBody').innerHTML=pageRows.map(p=>stableProductRow(p,raw)).join('');
  bindStableProductRows(raw);refreshMoveProducts();refreshAltProductSelects();productSortDirLabel();updateSortHeaderUi();
};
loadProducts=loadProductsSorted;
if($('productPerPage')){$('productPerPage').value=String(S.productPerPage);$('productPerPage').onchange=()=>{S.productPerPage=+$('productPerPage').value||100;S.productPage=1;loadProductsSorted()}}
if($('productPrevPage'))$('productPrevPage').onclick=()=>{if(S.productPage>1){S.productPage--;const raw=$('productSearch')?.value||'';const rows=renderProductPagination();$('productsBody').innerHTML=rows.map(p=>stableProductRow(p,raw)).join('');bindStableProductRows(raw)}};
if($('productNextPage'))$('productNextPage').onclick=()=>{const pages=Math.max(1,Math.ceil(S.products.length/(+S.productPerPage||100)));if(S.productPage<pages){S.productPage++;const raw=$('productSearch')?.value||'';const rows=renderProductPagination();$('productsBody').innerHTML=rows.map(p=>stableProductRow(p,raw)).join('');bindStableProductRows(raw)}};
if($('productSearch'))$('productSearch').oninput=()=>{clearTimeout(window.ps);window.ps=setTimeout(()=>loadProductsSorted(true),160)};
if($('productActive'))$('productActive').onchange=()=>loadProductsSorted(true);
if($('lowOnly'))$('lowOnly').onchange=()=>loadProductsSorted(true);
if($('productSort'))$('productSort').onchange=()=>{productSortDirLabel();loadProductsSorted(true)};
if($('productSortDir'))$('productSortDir').onclick=()=>{const b=$('productSortDir');b.dataset.dir=(b.dataset.dir||'asc')==='asc'?'desc':'asc';productSortDirLabel();loadProductsSorted(true)};
if($('selectAllProducts'))$('selectAllProducts').onchange=e=>{document.querySelectorAll('.product-select').forEach(x=>{x.checked=e.target.checked;const id=+x.value;if(e.target.checked)S.selectedProductIds.add(id);else S.selectedProductIds.delete(id)});stableSelectionUi()};
if($('selectAllVisibleProducts'))$('selectAllVisibleProducts').onclick=()=>{document.querySelectorAll('.product-select').forEach(x=>{x.checked=true;S.selectedProductIds.add(+x.value)});stableSelectionUi()};
if($('selectAllResultsProducts'))$('selectAllResultsProducts').onclick=()=>{S.products.forEach(p=>S.selectedProductIds.add(+p.id));document.querySelectorAll('.product-select').forEach(x=>x.checked=true);stableSelectionUi();toast(`Zaznaczono ${S.selectedProductIds.size} pozycji`)};
if($('clearProductSelection'))$('clearProductSelection').onclick=()=>{S.selectedProductIds.clear();document.querySelectorAll('.product-select').forEach(x=>x.checked=false);stableSelectionUi()};
if($('deleteSelectedProducts'))$('deleteSelectedProducts').onclick=async()=>{const ids=[...S.selectedProductIds];if(!ids.length)return;if(!confirm(`Trwale usunąć ${ids.length} zaznaczonych pozycji?\n\nPrzed usunięciem system utworzy kopię bazy danych.`))return;try{const r=await api('/api/products/bulk-delete',{method:'POST',body:JSON.stringify({ids,confirm:'USUN'})});S.selectedProductIds.clear();toast(`Usunięto ${r.deleted} pozycji · kopia: ${r.backup_filename}`);await Promise.all([loadProductsSorted(true),loadMovements(),loadDocuments(),loadSummary()])}catch(e){toast('Nie udało się usunąć zaznaczonych pozycji')}};

// Reset bazy w modalu — działa również w oknie pywebview, gdzie prompt() bywa niedostępny.
if($('clearDatabaseBtn'))$('clearDatabaseBtn').onclick=()=>{$('databaseResetPhrase').value='';$('databaseResetModal').classList.add('show');setTimeout(()=>$('databaseResetPhrase').focus(),40)};
if($('databaseResetConfirm'))$('databaseResetConfirm').onclick=async()=>{const phrase=$('databaseResetPhrase').value.trim();if(phrase!=='WYCZYSC BAZE')return toast('Wpisz dokładnie: WYCZYSC BAZE');$('databaseResetConfirm').disabled=true;try{const r=await api('/api/database/reset',{method:'POST',body:JSON.stringify({confirm:phrase})});$('databaseResetModal').classList.remove('show');S.selectedProductIds.clear();toast(`Baza wyczyszczona · kopia: ${r.backup_filename}`);await loadAll();page('dashboard')}catch(e){toast(`Nie udało się wyczyścić bazy: ${e.code||e.message||'błąd'}`)}finally{$('databaseResetConfirm').disabled=false}};

// Stabilny zoom: każdy nowo otwarty diagram dostaje własny stan skali i duży margines na hotspoty.
function installStableDiagramZoom(){
  const wrap=$('detailImageWrap'),stage=wrap?.querySelector('.diagram-stage'),img=stage?.querySelector('img');if(!wrap||!stage||!img)return;
  let viewport=wrap.querySelector('.diagram-viewport'),toolbar=wrap.querySelector('.diagram-toolbar');
  if(!viewport){viewport=document.createElement('div');viewport.className='diagram-viewport';stage.parentNode.insertBefore(viewport,stage);viewport.appendChild(stage)}
  if(!toolbar){toolbar=document.createElement('div');toolbar.className='diagram-toolbar';toolbar.innerHTML='<div class="diagram-toolbar-left"><button type="button" class="btn mini" data-z="out">−</button><span class="diagram-zoom-value">100%</span><button type="button" class="btn mini" data-z="in">＋</button><button type="button" class="btn mini" data-z="fit">Dopasuj</button><button type="button" class="btn mini" data-z="one">100%</button></div><small>Przeciągnij rysunek myszą · Ctrl + rolka = powiększ / pomniejsz</small>';viewport.parentNode.insertBefore(toolbar,viewport)}
  stage.style.padding='110px';stage.style.boxSizing='content-box';stage.style.position='relative';stage.style.width='max-content';stage.style.minWidth='100%';
  let zoom=1,baseWidth=0;
  const apply=(z,center=false,native=false)=>{const go=()=>{if(!img.naturalWidth)return;const vw=Math.max(260,viewport.clientWidth-220),vh=Math.max(260,viewport.clientHeight-220);if(native)baseWidth=img.naturalWidth;else if(!baseWidth)baseWidth=Math.max(180,img.naturalWidth*Math.min(1,vw/img.naturalWidth,vh/img.naturalHeight));zoom=Math.max(.25,Math.min(5,z));img.style.width=`${Math.round(baseWidth*zoom)}px`;img.style.height='auto';img.style.maxWidth='none';img.style.maxHeight='none';const val=toolbar.querySelector('.diagram-zoom-value');if(val)val.textContent=Math.round(zoom*100)+'%';requestAnimationFrame(()=>{placeDiagramHotspots(stage);if(center){viewport.scrollLeft=Math.max(0,(viewport.scrollWidth-viewport.clientWidth)/2);viewport.scrollTop=Math.max(0,(viewport.scrollHeight-viewport.clientHeight)/2)}})};img.complete?go():img.addEventListener('load',go,{once:true})};
  toolbar.querySelector('[data-z="in"]').onclick=()=>apply(zoom+.2);toolbar.querySelector('[data-z="out"]').onclick=()=>apply(zoom-.2);toolbar.querySelector('[data-z="fit"]').onclick=()=>{baseWidth=0;apply(1,true)};toolbar.querySelector('[data-z="one"]').onclick=()=>{baseWidth=img.naturalWidth;apply(1,true,true)};
  viewport.onwheel=e=>{if(!e.ctrlKey)return;e.preventDefault();apply(zoom+(e.deltaY<0?.12:-.12))};
  let drag=false,sx=0,sy=0,sl=0,st=0;viewport.onpointerdown=e=>{if(e.target.closest('.diagram-hotspot,button'))return;drag=true;sx=e.clientX;sy=e.clientY;sl=viewport.scrollLeft;st=viewport.scrollTop;viewport.classList.add('dragging');viewport.setPointerCapture?.(e.pointerId)};viewport.onpointermove=e=>{if(drag){viewport.scrollLeft=sl-(e.clientX-sx);viewport.scrollTop=st-(e.clientY-sy)}};viewport.onpointerup=viewport.onpointercancel=()=>{drag=false;viewport.classList.remove('dragging')};
  apply(1,true);
}
const _stableDetailBase=openProductDetail;
openProductDetail=async function(id){await _stableDetailBase(id);installStableDiagramZoom();const d=S.detailProduct;if(d?.mercedes_relations?.length){const box=$('detailAliases');if(box){box.insertAdjacentHTML('beforeend',`<div class="mb-relations"><small>Zamienniki Mercedes:</small> ${d.mercedes_relations.map(r=>`<button class="alias-pill substitute" data-search-related="${esc(r.related_oem)}">${esc(r.related_oem)}</button>`).join(' ')}</div>`);box.querySelectorAll('[data-search-related]').forEach(b=>b.onclick=()=>{const q=b.dataset.searchRelated;$('productDetailModal').classList.remove('show');page('products');$('productSearch').value=q;loadProductsSorted(true)})}}};


// 15.1.4 — zbiorcze uzupełnianie danych Mercedes po imporcie rachunku/faktury.
function bulkMercedesSetProgress(done,total,label){
  const pct=total?Math.max(0,Math.min(100,Math.round(done*100/total))):0;
  if($('bulkMercedesBar'))$('bulkMercedesBar').style.width=pct+'%';
  if($('bulkMercedesText'))$('bulkMercedesText').textContent=label||`${done} z ${total}`;
}
function bulkMercedesOpen(){if($('bulkMercedesPanel'))$('bulkMercedesPanel').classList.remove('hidden')}
function bulkMercedesRow(x,status='queued'){
  const icon=status==='done'?'✓':status==='error'?'!':'…';
  return `<div class="bulk-mercedes-row ${status}" data-bulk-product="${x.id}"><span>${icon}</span><b>${esc(x.oem||x.sku||('ID '+x.id))}</b><small>${status==='done'?'Dane uzupełnione':status==='error'?'Brak numeru OEM / błąd':'Zlecono Parts Information + B2B'}</small></div>`;
}
async function runBulkMercedes(ids=[],onlyMissing=false){
  bulkMercedesOpen();
  if($('bulkMercedesItems'))$('bulkMercedesItems').innerHTML='';
  bulkMercedesSetProgress(0,1,'Zlecanie pobierania danych Mercedes…');
  try{
    const r=await api('/api/products/mercedes-enrich-many',{method:'POST',body:JSON.stringify({ids,only_missing:onlyMissing,force:false})});
    const items=r.items||[],skipped=r.skipped_items||[];
    if($('bulkMercedesItems'))$('bulkMercedesItems').innerHTML=items.map(x=>bulkMercedesRow(x)).join('')+skipped.map(x=>bulkMercedesRow({id:x.id,oem:'ID '+x.id},'error')).join('');
    bulkMercedesSetProgress(items.length,items.length||1,`Zlecono ${items.length} pozycji${skipped.length?` · pominięto ${skipped.length}`:''}. Oczekiwanie na dane…`);
    if(!items.length){toast('Brak pozycji wymagających uzupełnienia');return}
    const wanted=new Set(items.map(x=>+x.id));
    for(let round=0;round<12;round++){
      await new Promise(res=>setTimeout(res,2500));
      const d=await api('/api/products?active=1&sort=name&dir=asc');
      const map=new Map((d.products||[]).map(p=>[+p.id,p]));
      let done=0;
      wanted.forEach(id=>{
        const p=map.get(id),row=document.querySelector(`[data-bulk-product="${id}"]`);
        if(!p||!row)return;
        const image=!!p.preview_image;
        const goodName=!!String(p.name||'').trim()&&!['do weryfikacji','część mercedes','czesc mercedes'].includes(String(p.name||'').trim().toLowerCase());
        if(image&&goodName){done++;row.classList.remove('queued','error');row.classList.add('done');row.querySelector('span').textContent='✓';row.querySelector('small').textContent='Nazwa i zdjęcie/rysunek uzupełnione'}
        else row.querySelector('small').textContent=`Oczekiwanie: ${image?'zdjęcie ✓':'zdjęcie…'} · ${goodName?'nazwa ✓':'nazwa…'}`;
      });
      bulkMercedesSetProgress(done,wanted.size,done===wanted.size?`Gotowe: ${done} z ${wanted.size}`:`Uzupełniono ${done} z ${wanted.size} · pozostałe są nadal pobierane`);
      try{await loadProductsSorted(false)}catch(_){}
      if(done===wanted.size)break;
    }
    await loadProductsSorted(false);
  }catch(e){bulkMercedesSetProgress(0,1,'Nie udało się uruchomić zbiorczego pobierania');toast('Błąd zbiorczego pobierania danych Mercedes')}
}
if($('bulkMercedesSelected'))$('bulkMercedesSelected').onclick=()=>runBulkMercedes([...S.selectedProductIds],false);
if($('bulkMercedesMissing'))$('bulkMercedesMissing').onclick=()=>runBulkMercedes([],true);
if($('bulkMercedesClose'))$('bulkMercedesClose').onclick=()=>$('bulkMercedesPanel').classList.add('hidden');
const _stableSelectionUiBulk=stableSelectionUi;
stableSelectionUi=function(){_stableSelectionUiBulk();if($('bulkMercedesSelected'))$('bulkMercedesSelected').disabled=!S.selectedProductIds.size};
stableSelectionUi();

// 15.2.3 — numery części niezależne od formatowania + ręczne zamienniki.
normCode=function(v){return String(v||'').toUpperCase().replace(/[^A-Z0-9]+/g,'')};
async function loadManualAlternatives1523(){
  const pid=+$('altBaseProduct')?.value,box=$('manualAlternatives');if(!box)return;
  if(!pid){box.innerHTML='<div class="hint">Wybierz część bazową.</div>';return}
  try{
    const d=await api(`/api/product/${pid}/detail`),rels=(d.mercedes_relations||[]).filter(r=>String(r.relation_type||'').toUpperCase()==='MANUAL');
    box.innerHTML=rels.length?rels.map(r=>`<div class="alt-card"><div><b>${esc(r.related_oem)}</b><small>Zamiennik wpisany ręcznie</small></div><button class="btn mini danger" data-manual-alt-del="${esc(r.related_oem)}">Usuń</button></div>`).join(''):'<div class="hint">Brak ręcznie wpisanych zamienników.</div>';
    box.querySelectorAll('[data-manual-alt-del]').forEach(b=>b.onclick=async()=>{await api(`/api/product/${pid}/manual-substitute`,{method:'POST',body:JSON.stringify({action:'remove',code:b.dataset.manualAltDel})});toast('Usunięto zamiennik');await loadManualAlternatives1523()});
  }catch(e){box.innerHTML='<div class="hint">Nie udało się pobrać ręcznych zamienników.</div>'}
}
const _loadAlternatives1523=loadAlternatives;
loadAlternatives=async function(){await _loadAlternatives1523();await loadManualAlternatives1523()};
if($('altBaseProduct'))$('altBaseProduct').onchange=loadAlternatives;
if($('refreshAlternatives'))$('refreshAlternatives').onclick=loadAlternatives;
if($('addManualAlt'))$('addManualAlt').onclick=async()=>{const pid=+$('altBaseProduct')?.value,code=$('manualAltCode')?.value||'';if(!pid)return toast('Wybierz część bazową');if(!normCode(code))return toast('Wpisz numer zamiennika');try{await api(`/api/product/${pid}/manual-substitute`,{method:'POST',body:JSON.stringify({action:'add',code})});$('manualAltCode').value='';toast('Dodano ręczny zamiennik');await loadManualAlternatives1523()}catch(e){toast(e.code==='same_code'?'To jest numer części bazowej':'Nie udało się dodać zamiennika')}};
