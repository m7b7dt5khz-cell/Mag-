// MB Auto Serwis 15.2.5 — szybka inwentaryzacja: numer -> ilość -> wyszukaj.
(function(){
'use strict';
const codeInput=document.getElementById('productSearch');
const qtyInput=document.getElementById('stockTargetQty');
const searchBtn=document.getElementById('productSearchBtn');
if(!codeInput||!qtyInput||!searchBtn)return;

let busy=false;
const today=()=>new Date().toISOString().slice(0,10);
const num=v=>Number(String(v??'').replace(',','.'));
const fmt=v=>{const n=Number(v||0);return Number.isInteger(n)?String(n):n.toFixed(2).replace('.',',')};

async function setScannedStock(){
  if(busy)return;
  const code=String(codeInput.value||'').trim();
  const target=num(qtyInput.value);
  if(!code){toast('Zeskanuj lub wpisz numer towaru');codeInput.focus();return}
  // Pusta ilość = zwykłe wyszukiwanie bez zmiany stanu.
  if(qtyInput.value===''){
    try{if(typeof loadProductsSorted==='function')await loadProductsSorted(true);else if(typeof loadProducts==='function')await loadProducts()}catch(_){ }
    return;
  }
  if(!Number.isFinite(target)||target<0){toast('Wpisz prawidłową ilość sztuk');qtyInput.focus();qtyInput.select();return}
  busy=true;searchBtn.disabled=true;searchBtn.textContent='Szukam…';
  try{
    const d=await api('/api/scan?code='+encodeURIComponent(code));
    if(!d.found){
      toast('Nie znaleziono towaru: '+code);
      codeInput.focus();codeInput.select();return;
    }
    const p=d.product||{};
    const current=Number(p.stock_qty||0);
    const delta=target-current;
    if(Math.abs(delta)>0.000001){
      const type=delta>0?'KOREKTA+':'KOREKTA-';
      await api('/api/movement',{method:'POST',body:JSON.stringify({
        move_type:type,
        move_date:today(),
        product_id:+p.id,
        quantity:Math.abs(delta),
        unit_price:0,
        reference_no:'INWENTARYZACJA-SKAN',
        note:`Szybka inwentaryzacja skanerem: stan ${fmt(current)} → ${fmt(target)}`
      })});
      toast(`${p.name||p.oem_no||p.sku||code}: stan ${fmt(current)} → ${fmt(target)} szt.`);
    }else{
      toast(`${p.name||p.oem_no||p.sku||code}: stan już wynosi ${fmt(target)} szt.`);
    }
    try{if(typeof loadProductsSorted==='function')await loadProductsSorted(false);else if(typeof loadProducts==='function')await loadProducts()}catch(_){ }
    try{if(typeof loadSummary==='function')await loadSummary()}catch(_){ }
    codeInput.value='';qtyInput.value='';
    codeInput.focus();
  }catch(e){
    toast(e?.code==='insufficient_stock'?'Nie można ustawić ujemnego stanu':'Nie udało się ustawić stanu towaru');
  }finally{
    busy=false;searchBtn.disabled=false;searchBtn.textContent='Wyszukaj';
  }
}

// W 15.2.5 wyszukiwanie skanerem nie uruchamia się po samym numerze.
// Enter wysłany przez skaner przenosi kursor do ilości.
codeInput.oninput=null;
codeInput.onkeydown=e=>{
  if(e.key!=='Enter')return;
  e.preventDefault();
  if(!String(codeInput.value||'').trim()){toast('Zeskanuj lub wpisz numer towaru');return}
  qtyInput.focus();qtyInput.select();
};
qtyInput.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();setScannedStock()}};
searchBtn.onclick=setScannedStock;

// Kliknięcie przycisku przy pustej ilości nigdy nie zmieni stanu przypadkiem.
// Dla zwykłego przeglądania kartoteki nadal działają sortowanie i filtry tabeli.
window.mbSetScannedStock=setScannedStock;
})();
