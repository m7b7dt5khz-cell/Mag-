/* MB Auto Serwis 15.3.8 — WooCommerce publication diagnostics + auth fallback */
(()=>{
'use strict';
const el=id=>document.getElementById(id);
const n=v=>Number(String(v??'').replace(',','.'))||0;
let shopRows=[];
const checkedIds=()=>[...document.querySelectorAll('.shop-beta-select:checked')].map(x=>+x.value).filter(Boolean);
function state(txt,err=false){const x=el('shopBetaActionState');if(x){x.textContent=txt||'';x.classList.toggle('error',!!err)}}
async function loadShopTest(){
  const body=el('shopBetaQueueBody');if(!body)return;
  try{
    const d=await api('/api/products?active=1&sort=name&dir=asc');
    shopRows=(d.products||[]).filter(p=>+p.woo_publish_enabled===1);
    if(el('shopBetaQueueLabel'))el('shopBetaQueueLabel').textContent=`${shopRows.length} produktów`;
    body.innerHTML=shopRows.length?shopRows.map(p=>{
      const vat=n(p.vat_rate)||23,gross=n(p.sell_price_net)*(1+vat/100),status=p.woo_sync_status||'NIEPUBLIKOWANY';
      const disabled=p.woo_product_id?' title="Produkt ma już Woo ID"':'';
      return `<tr data-shop-pid="${p.id}"><td><input class="shop-beta-select" type="checkbox" value="${p.id}"${disabled}></td><td><span class="code">${esc(p.oem_no||p.sku||'—')}</span></td><td>${esc(p.name||'')}</td><td>${money(n(p.purchase_price))}</td><td><div class="shop-inline-pricing"><select data-shop-mode="${p.id}"><option value="MARKUP" ${p.pricing_mode==='MARKUP'?'selected':''}>Narzut</option><option value="MARGIN" ${p.pricing_mode==='MARGIN'?'selected':''}>Marża</option></select><input data-shop-pct="${p.id}" type="number" step="0.1" value="${n(p.margin_pct).toFixed(1)}"><button class="btn mini" data-shop-save="${p.id}">Zapisz</button></div></td><td>${money(gross)}</td><td>${esc(status)}</td><td>${p.woo_product_id||'—'}</td></tr>`
    }).join(''):'<tr><td colspan="8" class="muted">Brak produktów oznaczonych do sklepu. Otwórz kartę części i zaznacz „Produkt przeznaczony do sklepu WooCommerce (BETA)”.</td></tr>';
    body.querySelectorAll('[data-shop-save]').forEach(b=>b.onclick=async()=>{const id=+b.dataset.shopSave,mode=body.querySelector(`[data-shop-mode="${id}"]`)?.value||'MARKUP',pct=body.querySelector(`[data-shop-pct="${id}"]`)?.value||'0';b.disabled=true;try{await api('/api/shop-beta/product',{method:'POST',body:JSON.stringify({product_id:id,enabled:true,pricing_mode:mode,margin_pct:pct})});toast('Cena sklepu przeliczona');await loadShopTest()}catch(_){toast('Nie udało się zapisać marży/narzutu')}finally{b.disabled=false}});
  }catch(e){body.innerHTML='<tr><td colspan="8">Nie udało się wczytać kolejki sklepu.</td></tr>';state('Błąd wczytywania kolejki',true)}
}
async function saveWooSettingsForTest(){
  if(typeof saveIntegrationSettings==='function')await saveIntegrationSettings();
}
el('shopBetaTestConnection')?.addEventListener('click',async()=>{
  const b=el('shopBetaTestConnection');if(b)b.disabled=true;state('Sprawdzam połączenie z WooCommerce…');
  try{await saveWooSettingsForTest();const d=await api('/api/shop-beta/test-connection',{method:'POST',body:'{}'});state(`Połączenie OK: ${d.store||''} · API ${d.api||'wc/v3'}`);toast('WooCommerce: połączenie OK')}
  catch(e){state(e?.data?.message||'Nie udało się połączyć z WooCommerce',true);toast('WooCommerce: test połączenia nieudany')}
  finally{if(b)b.disabled=false}
});
el('shopBetaWriteProbe')?.addEventListener('click',async()=>{
  const b=el('shopBetaWriteProbe');if(b)b.disabled=true;state('Sprawdzam realne prawo zapisu WooCommerce…');
  try{await saveWooSettingsForTest();const d=await api('/api/shop-beta/test-write-access',{method:'POST',body:'{}'});state(d.message||'Zapis WooCommerce działa.');toast('WooCommerce: zapis API działa');if(!d.cleanup)window.alert(d.message)}
  catch(e){const msg=e?.data?.message||e?.message||'Test zapisu nieudany';state(msg,true);toast('WooCommerce: zapis API NIE działa');window.alert(`Test zapisu WooCommerce NIE przeszedł:\n\n${msg}`)}
  finally{if(b)b.disabled=false}
});
el('shopBetaSelectAll')?.addEventListener('change',e=>{document.querySelectorAll('.shop-beta-select').forEach(x=>{if(!x.disabled)x.checked=e.target.checked})});
el('shopBetaPublishDraft')?.addEventListener('click',async()=>{
  const ids=checkedIds();if(!ids.length){toast('Zaznacz produkt do testowej publikacji');return}
  if(!el('woo_catalog_beta_enabled')?.checked){toast('Włącz „realną synchronizację produktów BETA” i zapisz ustawienia');return}
  if(!window.confirm(`Utworzyć ${ids.length} zaznaczonych produktów jako SZKIC w realnym WooCommerce?\n\nTest nie nadpisze istniejącego Woo ID ani istniejącego SKU.`))return;
  const b=el('shopBetaPublishDraft');b.disabled=true;state('Publikuję szkic testowy…');
  try{await saveWooSettingsForTest();const d=await api('/api/shop-beta/test-publish',{method:'POST',body:JSON.stringify({ids})});const items=d.items||[],created=items.filter(x=>x.ok&&x.outcome==='created'),linked=items.filter(x=>x.ok&&x.outcome==='linked'),bad=items.filter(x=>!x.ok),warn=items.find(x=>x.warning)?.warning||'',err=bad[0]?.error||'';const okIds=created.map(x=>x.woo_product_id).filter(Boolean);state(`TEST: szkice ${created.length} · powiązane ${linked.length} · problemy ${bad.length}${okIds.length?' · Woo ID: '+okIds.join(', '):''}${warn?' · '+warn:''}${err?' · '+err:''}`,bad.length>0&&created.length===0&&linked.length===0);if(bad.length){toast(`Woo: problem — ${err.slice(0,160)}`);window.alert(`WooCommerce NIE utworzył produktu.\n\n${err||'Brak szczegółów błędu'}\n\nSprawdź przycisk „Test zapisu API” w module Sklep.`)}else{toast(`WooCommerce: szkice ${created.length}, powiązane ${linked.length}`)}await Promise.all([loadShopTest(),loadProducts()])}
  catch(e){const msg=e?.data?.message||e?.message||'Błąd testowej publikacji';state(msg,true);toast('Nie udało się opublikować szkicu testowego');window.alert(`Błąd publikacji WooCommerce:\n\n${msg}`)}
  finally{b.disabled=false}
});
el('shopBetaUpdateSelected')?.addEventListener('click',async()=>{
  const ids=checkedIds();if(!ids.length){toast('Zaznacz produkty do aktualizacji');return}
  if(!el('woo_catalog_beta_enabled')?.checked){toast('Włącz realną synchronizację produktów BETA');return}
  if(!window.confirm(`Zaktualizować cenę i stan ${ids.length} zaznaczonych produktów, które już istnieją w WooCommerce?`))return;
  const b=el('shopBetaUpdateSelected');b.disabled=true;state('Aktualizuję ceny i stany…');
  try{await saveWooSettingsForTest();const d=await api('/api/shop-beta/update-prices',{method:'POST',body:JSON.stringify({dry_run:false,ids})});const ok=(d.items||[]).filter(x=>x.ok).length,bad=(d.items||[]).filter(x=>x.ok===false).length;state(`Aktualizacja: OK ${ok}, błędy ${bad}`,bad>0&&ok===0);toast(`WooCommerce: zaktualizowano ${ok}, błędy ${bad}`);await loadShopTest()}
  catch(e){state('Nie udało się zaktualizować zaznaczonych produktów',true);toast('Błąd aktualizacji WooCommerce')}
  finally{b.disabled=false}
});
el('shopBetaRefresh')?.addEventListener('click',loadShopTest);
el('shopNav')?.addEventListener('click',()=>setTimeout(loadShopTest,50));
const old=window.loadShopBeta1534;window.loadShopBeta1534=loadShopTest;
setTimeout(()=>{if(el('integrationsPage')&&!el('integrationsPage').classList.contains('hidden'))loadShopTest()},150);
})();
