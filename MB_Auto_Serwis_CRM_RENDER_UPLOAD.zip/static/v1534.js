/* MB Auto Serwis 15.3.4 — PI POF fallback, NBP EUR, stable shop beta */
(()=>{
'use strict';
const el=id=>document.getElementById(id);
const num=v=>Number(String(v??'').replace(',','.'))||0;
let nbpBusy=false;
function setNbpState(txt,err=false){const x=el('toolNbpState');if(x){x.textContent=txt;x.style.color=err?'#d66':''}}
async function fetchNbpRate(force=false){
  const date=el('toolPurchaseDate')?.value||'';if(!date||nbpBusy)return null;
  if(!force&&el('toolEurRateDate')?.value===date&&num(el('toolEurRate')?.value)>0)return null;
  nbpBusy=true;setNbpState('Pobieram kurs EUR z NBP…');
  try{
    const d=await api('/api/nbp/eur-rate?date='+encodeURIComponent(date));
    if(el('toolEurRate'))el('toolEurRate').value=(+d.rate||0).toFixed(4);
    if(el('toolEurRateDate'))el('toolEurRateDate').value=d.effective_date||date;
    if(el('toolEurRateTable'))el('toolEurRateTable').value=d.table||'';
    const eur=num(el('toolPriceEur')?.value),pln=eur*(+d.rate||0);
    if(el('toolCalculatedPln'))el('toolCalculatedPln').value=pln?pln.toFixed(2):'';
    if(eur>0&&el('toolPricePln'))el('toolPricePln').value=pln.toFixed(2);
    setNbpState(`NBP: ${(+d.rate).toFixed(4)} PLN · tabela ${d.table||'A'} · ${d.effective_date||date}`);
    return d;
  }catch(e){setNbpState('Nie udało się pobrać kursu NBP — możesz wpisać kurs ręcznie.',true);return null}
  finally{nbpBusy=false}
}
el('toolPurchaseDate')?.addEventListener('change',()=>fetchNbpRate(true));
el('toolPriceEur')?.addEventListener('change',()=>{if(el('toolPurchaseDate')?.value)fetchNbpRate(false)});
el('toolEurRate')?.addEventListener('input',()=>{if(el('toolEurRateDate'))el('toolEurRateDate').value='';if(el('toolEurRateTable'))el('toolEurRateTable').value='';setNbpState('Kurs zmieniony ręcznie')});

// openTool z audited.js wypełnia również ukryte pola daty/tabeli NBP.
setTimeout(()=>{const d=el('toolPurchaseDate')?.value,rd=el('toolEurRateDate')?.value,r=num(el('toolEurRate')?.value);if(d&&rd&&r)setNbpState(`NBP: ${r.toFixed(4)} PLN · tabela ${el('toolEurRateTable')?.value||'A'} · ${rd}`)},0);
if(el('toolForm'))el('toolForm').onsubmit=async e=>{
  e.preventDefault();const btn=e.submitter||e.target.querySelector('button[type=submit]');if(btn)btn.disabled=true;
  try{
    if(el('toolPurchaseDate')?.value&&num(el('toolPriceEur')?.value)>0&&!num(el('toolEurRate')?.value))await fetchNbpRate(true);
    const d={name:el('toolName').value,category:el('toolCategory').value,manufacturer:el('toolManufacturer').value,model:el('toolModel').value,catalog_no:el('toolCatalog').value,serial_no:el('toolSerial').value,location_id:el('toolLocation').value,quantity:el('toolQty').value,purchase_price_pln:el('toolPricePln').value,purchase_price_eur:el('toolPriceEur').value,eur_rate:el('toolEurRate').value,eur_rate_date:el('toolEurRateDate')?.value||'',eur_rate_table:el('toolEurRateTable')?.value||'',invoice_no:el('toolInvoice').value,supplier_id:el('toolSupplier').value,purchase_date:el('toolPurchaseDate').value,image_data:el('toolImageData').value,notes:el('toolNotes').value};
    const id=el('toolId').value;await api(id?'/api/tool/'+id:'/api/tool',{method:id?'PUT':'POST',body:JSON.stringify(d)});el('toolModal').classList.remove('show');toast(id?'Narzędzie zapisane':'Narzędzie dodane');await loadTools();
  }catch(err){toast('Nie udało się zapisać narzędzia')}finally{if(btn)btn.disabled=false}
};
})();
