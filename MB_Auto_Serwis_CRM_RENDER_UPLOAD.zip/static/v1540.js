/* MB Auto Serwis 15.4.0 — unified tool editor hotfix */
(()=>{
'use strict';
const $=id=>document.getElementById(id);
const n=v=>Number(String(v??'').replace(',','.'))||0;
const safe=v=>String(v??'');
let saving=false;
function notify(msg){ try{ if(typeof toast==='function') toast(msg); else console.log(msg); }catch(_){ console.log(msg); } }
async function api1540(path,opt={}){ return await api(path,opt); }
async function fillToolSelects(t){
  try{
    const [ld,sd]=await Promise.all([api1540('/api/locations'),api1540('/api/suppliers')]);
    const loc=$('toolLocation'),sup=$('toolSupplier');
    if(loc){loc.innerHTML='<option value="">— brak —</option>'+((ld.locations||[]).map(x=>`<option value="${x.id}">${safe(x.code)} · ${safe(x.name||'')}</option>`).join(''));loc.value=t?.location_id??'';}
    if(sup){sup.innerHTML='<option value="">— brak —</option>'+((sd.suppliers||[]).map(x=>`<option value="${x.id}">${safe(x.name||'')}</option>`).join(''));sup.value=t?.supplier_id??'';}
  }catch(e){ console.warn('tool selects',e); }
}
function calcPln(){
  const eur=n($('toolPriceEur')?.value),rate=n($('toolEurRate')?.value);
  const pln=eur>0&&rate>0?eur*rate:n($('toolPricePln')?.value);
  if($('toolCalculatedPln'))$('toolCalculatedPln').value=pln?pln.toFixed(2):'';
}
async function openEditTool(id){
  try{
    const d=await api1540('/api/tools?q=&sort=name&dir=asc');
    const t=(d.tools||[]).find(x=>+x.id===+id);
    if(!t){notify('Nie znaleziono narzędzia');return;}
    const form=$('toolForm'); if(!form)return;
    form.reset();
    if($('toolId'))$('toolId').value=t.id;
    if($('toolModalTitle'))$('toolModalTitle').textContent='Edycja narzędzia';
    await fillToolSelects(t);
    const map={toolName:'name',toolCategory:'category',toolManufacturer:'manufacturer',toolModel:'model',toolCatalog:'catalog_no',toolSerial:'serial_no',toolQty:'quantity',toolPricePln:'purchase_price_pln',toolPriceEur:'purchase_price_eur',toolEurRate:'eur_rate',toolEurRateDate:'eur_rate_date',toolEurRateTable:'eur_rate_table',toolInvoice:'invoice_no',toolPurchaseDate:'purchase_date',toolNotes:'notes'};
    for(const [eid,key] of Object.entries(map)){const el=$(eid);if(el)el.value=t[key]??'';}
    if($('toolImageData'))$('toolImageData').value=t.image_data||'';
    if($('toolImagePreview'))$('toolImagePreview').innerHTML=t.image_data?`<img src="${safe(t.image_data).replace(/"/g,'&quot;')}" alt="podgląd">`:'';
    if($('toolNbpState'))$('toolNbpState').textContent=t.eur_rate_date&&t.eur_rate?`NBP: ${(+t.eur_rate).toFixed(4)} PLN · tabela ${t.eur_rate_table||'A'} · ${t.eur_rate_date}`:'Po wyborze daty kurs EUR pobierze się automatycznie z NBP.';
    calcPln();
    $('toolModal')?.classList.add('show');
    setTimeout(()=>$('toolName')?.focus(),30);
  }catch(e){ console.error(e); notify(`Nie udało się otworzyć edycji narzędzia (${e?.code||e?.message||'błąd'})`); }
}
async function ensureRate(){
  const date=$('toolPurchaseDate')?.value||'',eur=n($('toolPriceEur')?.value),rate=n($('toolEurRate')?.value);
  if(!date||eur<=0||rate>0)return;
  try{
    const d=await api1540('/api/nbp/eur-rate?date='+encodeURIComponent(date));
    if($('toolEurRate'))$('toolEurRate').value=(+d.rate||0).toFixed(4);
    if($('toolEurRateDate'))$('toolEurRateDate').value=d.effective_date||date;
    if($('toolEurRateTable'))$('toolEurRateTable').value=d.table||'';
    if($('toolPricePln'))$('toolPricePln').value=(eur*(+d.rate||0)).toFixed(2);
    calcPln();
  }catch(_){ /* user can keep manual rate */ }
}
async function saveToolUnified(e){
  e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
  if(saving)return;
  saving=true;
  const btn=e.submitter||$('toolForm')?.querySelector('button[type="submit"]');if(btn)btn.disabled=true;
  try{
    await ensureRate();
    const d={
      name:$('toolName')?.value||'',category:$('toolCategory')?.value||'',manufacturer:$('toolManufacturer')?.value||'',model:$('toolModel')?.value||'',catalog_no:$('toolCatalog')?.value||'',serial_no:$('toolSerial')?.value||'',
      location_id:$('toolLocation')?.value||'',quantity:$('toolQty')?.value||1,purchase_price_pln:$('toolPricePln')?.value||0,purchase_price_eur:$('toolPriceEur')?.value||0,eur_rate:$('toolEurRate')?.value||0,
      eur_rate_date:$('toolEurRateDate')?.value||'',eur_rate_table:$('toolEurRateTable')?.value||'',invoice_no:$('toolInvoice')?.value||'',supplier_id:$('toolSupplier')?.value||'',purchase_date:$('toolPurchaseDate')?.value||'',image_data:$('toolImageData')?.value||'',notes:$('toolNotes')?.value||''
    };
    const id=+$('toolId')?.value||0;
    const r=await api1540(id?'/api/tool/'+id:'/api/tool',{method:id?'PUT':'POST',body:JSON.stringify(d)});
    $('toolModal')?.classList.remove('show');
    notify(id?'Narzędzie zapisane':'Narzędzie dodane');
    document.querySelector('nav [data-page="tools"]')?.click();
    return r;
  }catch(err){
    console.error(err);
    notify(`Nie udało się zapisać narzędzia: ${err?.data?.message||err?.code||err?.message||'błąd'}`);
  }finally{saving=false;if(btn)btn.disabled=false;}
}

document.addEventListener('click',e=>{
  const b=e.target.closest?.('[data-tool-edit]');
  if(!b)return;
  e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
  openEditTool(+b.dataset.toolEdit);
},true);
$('toolForm')?.addEventListener('submit',saveToolUnified,true);
['toolPriceEur','toolEurRate','toolPricePln'].forEach(id=>$(id)?.addEventListener('input',calcPln));
window.__MB_TOOL_EDITOR_1540__={open:openEditTool};
})();
