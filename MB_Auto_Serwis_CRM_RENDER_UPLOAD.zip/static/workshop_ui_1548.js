/* MB Auto Serwis CRM 15.4.8 — UI shell behavior only. */
(()=>{
  'use strict';
  const $=id=>document.getElementById(id);
  const body=document.body;
  const title=$('title');
  const globalSearch=$('globalCrmSearch');
  const sidebarToggle=$('sidebarToggle');
  const topTheme=$('topThemeBtn');
  const topUserName=$('topUserName');
  const topUserRole=$('topUserRole');
  const userBadge=$('currentUserBadge');

  const appShell=$('app');
  function applySidebarState(collapsed,persist=true){
    body.classList.toggle('sidebar-collapsed',!!collapsed);
    const width=collapsed?'76px':'258px';
    if(appShell){
      appShell.style.setProperty('--mb-sidebar-width',width);
      appShell.style.setProperty('grid-template-columns',`${width} minmax(0,1fr)`,'important');
    }
    if(sidebarToggle){
      sidebarToggle.textContent=collapsed?'›':'‹';
      sidebarToggle.setAttribute('aria-expanded',collapsed?'false':'true');
      sidebarToggle.title=collapsed?'Rozwiń menu':'Zwiń menu';
    }
    if(persist){try{localStorage.setItem('mbas_sidebar_collapsed',collapsed?'1':'0')}catch(e){}}
    requestAnimationFrame(()=>requestAnimationFrame(()=>window.dispatchEvent(new Event('resize'))));
  }
  let initialCollapsed=false;
  try{initialCollapsed=localStorage.getItem('mbas_sidebar_collapsed')==='1'}catch(e){}
  applySidebarState(initialCollapsed,false);
  sidebarToggle?.addEventListener('click',()=>applySidebarState(!body.classList.contains('sidebar-collapsed')));
  topTheme?.addEventListener('click',()=>$('themeToggle')?.click());

  const pageMap={
    products:'productSearch',tools:'toolSearch',movements:'moveSearch',documents:'documentSearch',contractors:'contractorSearch',alternatives:'altSearch'
  };
  function activePage(){
    const b=[...document.querySelectorAll('nav [data-page]')].find(x=>x.classList.contains('active'));
    return b?.dataset.page||'dashboard';
  }
  function applyGlobalSearch(){
    const targetId=pageMap[activePage()];
    if(!targetId){
      const nav=[...document.querySelectorAll('nav [data-page]')].find(b=>b.textContent.toLowerCase().includes((globalSearch?.value||'').trim().toLowerCase()));
      if(nav && (globalSearch?.value||'').trim())nav.click();
      return;
    }
    const el=$(targetId); if(!el)return;
    el.value=globalSearch.value;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    const btn=$(targetId+'Btn')||$('productSearchBtn');
    if(activePage()==='products'&&btn)btn.click();
  }
  globalSearch?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();applyGlobalSearch()}});
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();globalSearch?.focus();globalSearch?.select()}});

  const subtitles={
    'Dashboard magazynu':'Szybki podgląd stanów, wartości magazynu i najważniejszych alertów.',
    'Kartoteka części':'Wyszukiwanie, stany, ceny i dane części Mercedes-Benz w jednym miejscu.',
    'Ruchy magazynowe':'Historia przyjęć, wydań i korekt magazynowych.',
    'Dokumenty magazynowe':'Dokumenty PZ, RW, WZ i korekty magazynowe.',
    'Zamienniki i odpowiedniki':'Powiązania części OE oraz odpowiedników.',
    'Dostawcy':'Kartoteka dostawców i dane kontaktowe.',
    'Lokalizacje magazynowe':'Regały, półki i miejsca składowania części.',
    'Kontrahenci / NIP':'Kartoteka firm i pobieranie danych po NIP.',
    'Kartoteka narzędzi':'Wyposażenie warsztatu, koszty zakupu i lokalizacje.',
    'Mercedes B2B Bridge':'Integracja z portalami Mercedes-Benz.',
    'Sklep WooCommerce BETA':'Publikacja i synchronizacja produktów ze sklepem.'
  };
  function updateHeader(){
    if(!title)return;
    const p=title.parentElement?.querySelector('p');
    if(p){
      const badge=p.querySelector('.release-badge');
      const text=subtitles[title.textContent.trim()]||'MB Auto Serwis · system magazynowy i narzędziowy.';
      p.childNodes.forEach(n=>{if(n.nodeType===3)n.textContent=''});
      p.insertBefore(document.createTextNode(text+' '),badge||null);
    }
    const page=activePage();
    if(globalSearch){
      globalSearch.placeholder=page==='products'?'Szukaj części, OEM, SKU...':page==='tools'?'Szukaj narzędzia, numeru, faktury...':'Szukaj w systemie...';
    }
  }
  new MutationObserver(updateHeader).observe(title,{childList:true,characterData:true,subtree:true});
  document.querySelectorAll('nav [data-page]').forEach(b=>b.addEventListener('click',()=>setTimeout(updateHeader,0)));

  function mirrorUser(){
    const raw=(userBadge?.textContent||'Użytkownik').trim();
    const parts=raw.split('·').map(s=>s.trim());
    if(topUserName)topUserName.textContent=parts[0]||'Użytkownik';
    if(topUserRole)topUserRole.textContent=parts[1]||'MB Auto Serwis';
    const avatar=$('topUserAvatar'); if(avatar){const t=(parts[0]||'MB').split(/\s+/).filter(Boolean);avatar.textContent=(t[0]?.[0]||'M')+(t[1]?.[0]||'B')}
  }
  if(userBadge)new MutationObserver(mirrorUser).observe(userBadge,{childList:true,characterData:true,subtree:true});
  mirrorUser(); updateHeader();
})();
