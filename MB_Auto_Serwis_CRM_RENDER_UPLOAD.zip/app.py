
import base64, csv, ctypes, hashlib, hmac, io, json, os, re, secrets, sqlite3, ssl, tempfile, threading, time, urllib.parse, urllib.request, urllib.error, webbrowser, zipfile, shutil, subprocess, posixpath, xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from http import cookies
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape
try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    Image = ImageDraw = ImageFont = None


HOST=os.environ.get("MBMAG_HOST","127.0.0.1")
PORT=int(os.environ.get("PORT", os.environ.get("MBMAG_PORT", "8767")))
APP_VERSION="15.6.4"
APP_DIR=Path(__file__).resolve().parent
STATIC_DIR=APP_DIR/"static"
DATA_DIR=Path(os.environ.get("MBMAG_DATA_DIR") or (Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "MBAutoSerwisMagazyn"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
def ui_build():
    # Detect changes even when two unpacked folders use the same version number.
    payload=b"".join((STATIC_DIR/n).read_bytes() for n in ("index.html","audited.js","keyboard.js","v125.js","v150.js","v1541.js","mercedes_1547.css","mercedes_1547.js","workshop_ui_1548.css","workshop_ui_1548.js","mbas_premium_1550.css","products_premium_1556.css","mbas_premium_1550.js","v1561.js","theme-toggle.js") if (STATIC_DIR/n).exists())
    return hashlib.sha256(payload).hexdigest()[:16]
DB_PATH=DATA_DIR/"magazyn.sqlite3"
INTEGRATIONS_PATH=DATA_DIR/"integrations.json"
B2B_TOKEN_PATH=DATA_DIR/"b2b_bridge_token.txt"
UI_PREFS_PATH=DATA_DIR/"ui_preferences.json"
B2B_EXPORT_DIR=Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Documents" / "MB Auto Serwis" / "B2B Export"
SALES_DB_PATH=Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "MBAutoSerwisSalesCRM" / "sales.sqlite3"
SESSION_TTL=12*60*60
SESSIONS={}
SESSIONS_LOCK=threading.Lock()
LOGIN_ATTEMPTS={}
LOGIN_LOCK=threading.Lock()
SYNC_LOCK=threading.Lock()

MOVE_TYPES={
    "PZ": 1,      # przyjęcie
    "ZW": 1,      # zwrot
    "RW": -1,     # wydanie na warsztat
    "WZ": -1,     # sprzedaż / wydanie
    "KOREKTA+": 1,
    "KOREKTA-": -1,
}
MOVE_LABELS={
    "PZ":"Przyjęcie magazynowe",
    "ZW":"Zwrot na magazyn",
    "RW":"Rozchód wewnętrzny / warsztat",
    "WZ":"Wydanie / sprzedaż",
    "KOREKTA+":"Korekta dodatnia",
    "KOREKTA-":"Korekta ujemna",
}

def db():
    c=sqlite3.connect(DB_PATH, timeout=20)
    c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=FULL")
    return c

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, password_salt TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS suppliers(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, phone TEXT, email TEXT, nip TEXT, notes TEXT, active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS locations(
          id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, name TEXT, notes TEXT, active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS tools(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL, category TEXT, manufacturer TEXT, model TEXT, catalog_no TEXT, serial_no TEXT,
          location_id INTEGER, quantity REAL NOT NULL DEFAULT 1, purchase_price_pln REAL NOT NULL DEFAULT 0,
          purchase_price_eur REAL NOT NULL DEFAULT 0, eur_rate REAL NOT NULL DEFAULT 0, invoice_no TEXT,
          supplier_id INTEGER, purchase_date TEXT, image_data TEXT, notes TEXT, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          FOREIGN KEY(location_id) REFERENCES locations(id), FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
        );
        CREATE INDEX IF NOT EXISTS idx_tools_name ON tools(name);
        CREATE INDEX IF NOT EXISTS idx_tools_catalog ON tools(catalog_no);
        CREATE INDEX IF NOT EXISTS idx_tools_serial ON tools(serial_no);
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          sku TEXT, oem_no TEXT, barcode TEXT, name TEXT NOT NULL, category TEXT,
          supplier_id INTEGER, location_id INTEGER,
          stock_qty REAL NOT NULL DEFAULT 0,
          min_qty REAL NOT NULL DEFAULT 0,
          purchase_price REAL NOT NULL DEFAULT 0,
          sale_price REAL NOT NULL DEFAULT 0,
          unit TEXT NOT NULL DEFAULT 'szt.',
          notes TEXT, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
          FOREIGN KEY(location_id) REFERENCES locations(id)
        );
        CREATE UNIQUE INDEX IF NOT EXISTS ux_products_sku ON products(sku) WHERE sku IS NOT NULL AND sku<>'';
        CREATE UNIQUE INDEX IF NOT EXISTS ux_products_oem ON products(oem_no) WHERE oem_no IS NOT NULL AND oem_no<>'';
        CREATE UNIQUE INDEX IF NOT EXISTS ux_products_barcode ON products(barcode) WHERE barcode IS NOT NULL AND barcode<>'';
        CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
        CREATE TABLE IF NOT EXISTS movements(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          document_no TEXT NOT NULL UNIQUE,
          move_type TEXT NOT NULL,
          move_date TEXT NOT NULL,
          product_id INTEGER NOT NULL,
          quantity REAL NOT NULL,
          unit_price REAL NOT NULL DEFAULT 0,
          reference_no TEXT,
          motowarsztat_order_no TEXT,
          shop_order_no TEXT,
          supplier_id INTEGER,
          note TEXT,
          created_at TEXT NOT NULL,
          FOREIGN KEY(product_id) REFERENCES products(id),
          FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
        );
        CREATE INDEX IF NOT EXISTS idx_movements_date ON movements(move_date);
        CREATE INDEX IF NOT EXISTS idx_movements_product ON movements(product_id);
        CREATE TABLE IF NOT EXISTS external_sync_lines(
          source TEXT NOT NULL, external_doc TEXT NOT NULL, external_line TEXT NOT NULL,
          sku TEXT, oem_no TEXT, product_id INTEGER, desired_qty REAL NOT NULL DEFAULT 0,
          applied_qty REAL NOT NULL DEFAULT 0, last_status TEXT, last_seen TEXT NOT NULL,
          PRIMARY KEY(source,external_doc,external_line)
        );
        CREATE TABLE IF NOT EXISTS integration_issues(
          id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, external_doc TEXT, external_line TEXT,
          sku TEXT, oem_no TEXT, item_name TEXT, quantity REAL NOT NULL DEFAULT 0, issue_type TEXT NOT NULL,
          message TEXT, status TEXT NOT NULL DEFAULT 'OPEN', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          UNIQUE(source,external_doc,external_line,issue_type)
        );
        CREATE TABLE IF NOT EXISTS integration_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, synced_at TEXT NOT NULL, result TEXT NOT NULL,
          records_seen INTEGER NOT NULL DEFAULT 0, movements_created INTEGER NOT NULL DEFAULT 0, issues_count INTEGER NOT NULL DEFAULT 0, message TEXT
        );
        CREATE TABLE IF NOT EXISTS substitute_groups(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS product_substitute_group(
          product_id INTEGER PRIMARY KEY, group_id INTEGER NOT NULL,
          FOREIGN KEY(product_id) REFERENCES products(id), FOREIGN KEY(group_id) REFERENCES substitute_groups(id)
        );
        CREATE TABLE IF NOT EXISTS external_substitutes(
          id INTEGER PRIMARY KEY AUTOINCREMENT, group_id INTEGER NOT NULL, source TEXT NOT NULL, external_sku TEXT, external_index TEXT,
          brand TEXT, name TEXT, description TEXT, last_stock REAL, last_price_net REAL, last_price_gross REAL, updated_at TEXT NOT NULL,
          UNIQUE(group_id,source,external_sku,external_index), FOREIGN KEY(group_id) REFERENCES substitute_groups(id)
        );
        CREATE TABLE IF NOT EXISTS b2b_captures(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          captured_at TEXT NOT NULL,
          page_title TEXT,
          page_url TEXT,
          source_host TEXT,
          vin TEXT,
          selected_text TEXT,
          raw_text TEXT NOT NULL,
          parts_json TEXT NOT NULL DEFAULT '[]',
          operations_json TEXT NOT NULL DEFAULT '[]',
          status TEXT NOT NULL DEFAULT 'NEW'
        );
        CREATE INDEX IF NOT EXISTS idx_b2b_captures_date ON b2b_captures(captured_at);
        CREATE TABLE IF NOT EXISTS b2b_import_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          import_key TEXT NOT NULL UNIQUE,
          import_type TEXT NOT NULL,
          imported_at TEXT NOT NULL,
          page_url TEXT,
          order_no TEXT,
          purchase_date TEXT,
          supplier_name TEXT,
          items_count INTEGER NOT NULL DEFAULT 0,
          movements_count INTEGER NOT NULL DEFAULT 0,
          summary_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS idx_b2b_import_log_date ON b2b_import_log(imported_at);
        CREATE TABLE IF NOT EXISTS product_aliases(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          alias_no TEXT NOT NULL UNIQUE,
          alias_type TEXT NOT NULL DEFAULT 'MB_RELATED',
          note TEXT,
          created_at TEXT NOT NULL,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_product_alias_product ON product_aliases(product_id);
        CREATE TABLE IF NOT EXISTS mercedes_part_relations(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          related_oem TEXT NOT NULL,
          relation_type TEXT NOT NULL DEFAULT 'SUBSTITUTE',
          note TEXT,
          created_at TEXT NOT NULL,
          UNIQUE(product_id,related_oem,relation_type),
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_mb_rel_product ON mercedes_part_relations(product_id);
        CREATE INDEX IF NOT EXISTS idx_mb_rel_oem ON mercedes_part_relations(related_oem);
        CREATE TABLE IF NOT EXISTS contractors(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          nip TEXT UNIQUE,
          regon TEXT,
          krs TEXT,
          address TEXT,
          vat_status TEXT,
          phone TEXT,
          email TEXT,
          role TEXT NOT NULL DEFAULT 'Klient',
          mf_request_id TEXT,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS mb_availability_cache(
          product_id INTEGER PRIMARY KEY,
          status_code TEXT NOT NULL DEFAULT 'UNKNOWN',
          dealer_name TEXT,
          checked_oem TEXT,
          checked_at TEXT,
          source_url TEXT,
          raw_label TEXT,
          details_json TEXT NOT NULL DEFAULT '{}',
          error TEXT,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS mb_availability_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          requested_oem TEXT,
          codes_json TEXT NOT NULL DEFAULT '[]',
          requested_at TEXT NOT NULL,
          started_at TEXT,
          finished_at TEXT,
          status TEXT NOT NULL DEFAULT 'PENDING',
          attempts INTEGER NOT NULL DEFAULT 0,
          error TEXT,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_mb_av_req_status ON mb_availability_requests(status,requested_at);
        CREATE TABLE IF NOT EXISTS b2b_enrich_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          requested_oem TEXT NOT NULL,
          requested_at TEXT NOT NULL,
          started_at TEXT,
          finished_at TEXT,
          status TEXT NOT NULL DEFAULT 'PENDING',
          attempts INTEGER NOT NULL DEFAULT 0,
          error TEXT,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_b2b_enrich_status ON b2b_enrich_requests(status,requested_at);
        CREATE TABLE IF NOT EXISTS b2b_manual_search_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          requested_oem TEXT NOT NULL,
          requested_at TEXT NOT NULL,
          started_at TEXT,
          finished_at TEXT,
          status TEXT NOT NULL DEFAULT 'PENDING',
          attempts INTEGER NOT NULL DEFAULT 0,
          error TEXT,
          result_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS idx_b2b_manual_search_status ON b2b_manual_search_requests(status,requested_at);
        CREATE TABLE IF NOT EXISTS tool_b2b_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tool_id INTEGER NOT NULL,
          requested_catalog_no TEXT NOT NULL,
          requested_at TEXT NOT NULL,
          started_at TEXT,
          finished_at TEXT,
          status TEXT NOT NULL DEFAULT 'PENDING',
          attempts INTEGER NOT NULL DEFAULT 0,
          error TEXT,
          FOREIGN KEY(tool_id) REFERENCES tools(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_tool_b2b_status ON tool_b2b_requests(status,requested_at);
        CREATE TABLE IF NOT EXISTS purchase_carts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'OPEN',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS purchase_cart_items(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          cart_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          quantity REAL NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(cart_id,product_id),
          FOREIGN KEY(cart_id) REFERENCES purchase_carts(id) ON DELETE CASCADE,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS b2b_cart_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          cart_id INTEGER NOT NULL,
          cart_item_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          requested_oem TEXT NOT NULL,
          quantity REAL NOT NULL DEFAULT 1,
          requested_at TEXT NOT NULL,
          started_at TEXT,
          finished_at TEXT,
          status TEXT NOT NULL DEFAULT 'PENDING',
          final_oem TEXT,
          message TEXT,
          attempts INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY(cart_id) REFERENCES purchase_carts(id) ON DELETE CASCADE,
          FOREIGN KEY(cart_item_id) REFERENCES purchase_cart_items(id) ON DELETE CASCADE,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_b2b_cart_status ON b2b_cart_requests(status,requested_at);
        CREATE TABLE IF NOT EXISTS quick_catalog_entries(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          requested_oem TEXT NOT NULL,
          product_id INTEGER NOT NULL,
          source TEXT NOT NULL DEFAULT 'MANUAL',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(requested_oem,product_id),
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_quick_catalog_product ON quick_catalog_entries(product_id);
        CREATE INDEX IF NOT EXISTS idx_quick_catalog_updated ON quick_catalog_entries(updated_at);
        """)
        # v6 - dokumenty magazynowe, karta produktu i rysunek B2B
        pcols={r["name"] for r in c.execute("PRAGMA table_info(products)").fetchall()}
        if "preview_image" not in pcols:
            c.execute("ALTER TABLE products ADD COLUMN preview_image TEXT")
        if "source_url" not in pcols:
            c.execute("ALTER TABLE products ADD COLUMN source_url TEXT")
        if "diagram_position" not in pcols:
            c.execute("ALTER TABLE products ADD COLUMN diagram_position TEXT")
        if "diagram_marker_x" not in pcols:
            c.execute("ALTER TABLE products ADD COLUMN diagram_marker_x REAL")
        if "diagram_marker_y" not in pcols:
            c.execute("ALTER TABLE products ADD COLUMN diagram_marker_y REAL")
        if "diagram_fingerprint" not in pcols:
            c.execute("ALTER TABLE products ADD COLUMN diagram_fingerprint TEXT")
        lcols={r["name"] for r in c.execute("PRAGMA table_info(locations)").fetchall()}
        if "size_class" not in lcols:
            c.execute("ALTER TABLE locations ADD COLUMN size_class TEXT NOT NULL DEFAULT 'ANY'")
        if "capacity" not in lcols:
            c.execute("ALTER TABLE locations ADD COLUMN capacity INTEGER NOT NULL DEFAULT 0")
        if "storage_type" not in lcols:
            c.execute("ALTER TABLE locations ADD COLUMN storage_type TEXT NOT NULL DEFAULT 'GENERAL'")
        # v15.1 - inteligentny magazyn: gabaryt + wiele SKU w jednej lokalizacji
        pcols={r["name"] for r in c.execute("PRAGMA table_info(products)").fetchall()}
        if "size_class_override" not in pcols:
            c.execute("ALTER TABLE products ADD COLUMN size_class_override TEXT")
        c.execute("""CREATE TABLE IF NOT EXISTS product_locations(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          location_id INTEGER NOT NULL,
          quantity REAL NOT NULL DEFAULT 0,
          is_primary INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(product_id,location_id),
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,
          FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE CASCADE
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_product_locations_location ON product_locations(location_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_product_locations_product ON product_locations(product_id)")
        now_backfill=datetime.now().isoformat(timespec="seconds")
        c.execute("""INSERT OR IGNORE INTO product_locations(product_id,location_id,quantity,is_primary,created_at,updated_at)
                     SELECT id,location_id,stock_qty,1,?,? FROM products WHERE location_id IS NOT NULL""",(now_backfill,now_backfill))
        qcols={r["name"] for r in c.execute("PRAGMA table_info(quick_catalog_entries)").fetchall()}
        if "auto_location" not in qcols:
            c.execute("ALTER TABLE quick_catalog_entries ADD COLUMN auto_location INTEGER NOT NULL DEFAULT 1")
        c.execute("""CREATE TABLE IF NOT EXISTS b2b_runtime_status(
          id INTEGER PRIMARY KEY CHECK(id=1),
          last_seen TEXT,
          page_url TEXT,
          page_title TEXT,
          dealer_name TEXT,
          extension_version TEXT,
          last_error TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS mercedes_portal_status(
          source TEXT PRIMARY KEY,
          last_seen TEXT,
          page_url TEXT,
          page_title TEXT,
          dealer_name TEXT,
          extension_version TEXT,
          capabilities_json TEXT NOT NULL DEFAULT '{}',
          last_error TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS partsinfo_enrich_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER NOT NULL,
          requested_oem TEXT NOT NULL,
          requested_at TEXT NOT NULL,
          started_at TEXT,
          finished_at TEXT,
          status TEXT NOT NULL DEFAULT 'PENDING',
          attempts INTEGER NOT NULL DEFAULT 0,
          error TEXT,
          warning TEXT,
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_partsinfo_enrich_status ON partsinfo_enrich_requests(status,requested_at)")
        c.execute("""CREATE TABLE IF NOT EXISTS mercedes_diagram_hotspots(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          diagram_fingerprint TEXT NOT NULL,
          position TEXT NOT NULL,
          oem_no TEXT,
          name TEXT,
          marker_x REAL,
          marker_y REAL,
          source_url TEXT,
          updated_at TEXT NOT NULL,
          UNIQUE(diagram_fingerprint,position,oem_no)
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_mercedes_hotspots_fp ON mercedes_diagram_hotspots(diagram_fingerprint)")
        c.execute("""CREATE TABLE IF NOT EXISTS intercars_product_links(
          product_id INTEGER PRIMARY KEY, ic_sku TEXT, ic_index TEXT, brand TEXT, tecdoc TEXT, article_number TEXT,
          eans_json TEXT NOT NULL DEFAULT '[]', location_code TEXT, stock_qty REAL NOT NULL DEFAULT 0, stock_json TEXT NOT NULL DEFAULT '[]',
          list_price_net REAL NOT NULL DEFAULT 0, customer_price_net REAL NOT NULL DEFAULT 0, customer_price_gross REAL NOT NULL DEFAULT 0,
          currency TEXT, checked_at TEXT, raw_json TEXT NOT NULL DEFAULT '{}',
          FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ic_links_sku ON intercars_product_links(ic_sku)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ic_links_index ON intercars_product_links(ic_index)")
        c.execute("""CREATE TABLE IF NOT EXISTS intercars_catalog_cache(
          cache_key TEXT PRIMARY KEY, ic_sku TEXT, ic_index TEXT, article_number TEXT, tecdoc TEXT, brand TEXT, name TEXT,
          eans_text TEXT NOT NULL DEFAULT '', norm_blob TEXT NOT NULL DEFAULT '', item_json TEXT NOT NULL DEFAULT '{}', updated_at TEXT NOT NULL
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ic_cache_sku ON intercars_catalog_cache(ic_sku)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ic_cache_index ON intercars_catalog_cache(ic_index)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ic_cache_article ON intercars_catalog_cache(article_number)")
        c.execute("""CREATE TABLE IF NOT EXISTS intercars_oe_links(
          id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, oem_no TEXT, link_key TEXT NOT NULL,
          ic_sku TEXT, ic_index TEXT, brand TEXT, name TEXT, article_number TEXT, tecdoc TEXT, eans_json TEXT NOT NULL DEFAULT '[]',
          image_url TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          UNIQUE(product_id,link_key), FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ic_oe_product ON intercars_oe_links(product_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ic_oe_oem ON intercars_oe_links(oem_no)")
        avcols={r["name"] for r in c.execute("PRAGMA table_info(mb_availability_cache)").fetchall()}
        if "source" not in avcols:
            c.execute("ALTER TABLE mb_availability_cache ADD COLUMN source TEXT")
        pcols2={r["name"] for r in c.execute("PRAGMA table_info(products)").fetchall()}
        if "catalog_source" not in pcols2:
            c.execute("ALTER TABLE products ADD COLUMN catalog_source TEXT")
        if "catalog_checked_at" not in pcols2:
            c.execute("ALTER TABLE products ADD COLUMN catalog_checked_at TEXT")
        # 14.0: po restarcie aplikacji nie zostawiaj zleceń przejętych przez starą
        # kartę/wersję rozszerzenia jako WORKING. Przeglądarka pobierze je ponownie.
        for _tbl in ("partsinfo_enrich_requests","b2b_enrich_requests","b2b_manual_search_requests","mb_availability_requests","tool_b2b_requests"):
            try:
                c.execute(f"UPDATE {_tbl} SET status='PENDING',started_at=NULL,error='Wznowione po restarcie 15.0' WHERE status='WORKING'")
            except Exception:
                pass
        if "commerce_checked_at" not in pcols2:
            c.execute("ALTER TABLE products ADD COLUMN commerce_checked_at TEXT")
        mcols={r["name"] for r in c.execute("PRAGMA table_info(movements)").fetchall()}
        if "document_id" not in mcols:
            c.execute("ALTER TABLE movements ADD COLUMN document_id INTEGER")
        c.execute("""CREATE TABLE IF NOT EXISTS warehouse_documents(
          id INTEGER PRIMARY KEY AUTOINCREMENT, document_no TEXT NOT NULL UNIQUE, doc_type TEXT NOT NULL, doc_date TEXT NOT NULL,
          external_no TEXT, supplier_id INTEGER, source TEXT, notes TEXT, created_at TEXT NOT NULL,
          FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_whdocs_date ON warehouse_documents(doc_date)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_whdocs_external ON warehouse_documents(external_no)")
        # Grupuj starsze ruchy z tym samym numerem zewnętrznym w jeden dokument.
        groups=c.execute("""SELECT move_type,move_date,reference_no,supplier_id,MIN(document_no) parent_no
                            FROM movements WHERE document_id IS NULL AND COALESCE(reference_no,'')<>''
                            GROUP BY move_type,move_date,reference_no,supplier_id""").fetchall()
        for g in groups:
            try:
                c.execute("""INSERT OR IGNORE INTO warehouse_documents(document_no,doc_type,doc_date,external_no,supplier_id,source,notes,created_at)
                             VALUES(?,?,?,?,?,?,?,?)""",
                          (g["parent_no"],g["move_type"],g["move_date"],g["reference_no"],g["supplier_id"],"Migracja","Dokument utworzony z istniejących ruchów",datetime.now().isoformat(timespec="seconds")))
                dr=c.execute("SELECT id FROM warehouse_documents WHERE document_no=?",(g["parent_no"],)).fetchone()
                if dr:
                    c.execute("""UPDATE movements SET document_id=? WHERE document_id IS NULL AND move_type=? AND move_date=? AND reference_no=? AND
                                 ((supplier_id IS NULL AND ? IS NULL) OR supplier_id=?)""",
                              (dr["id"],g["move_type"],g["move_date"],g["reference_no"],g["supplier_id"],g["supplier_id"]))
            except Exception:
                pass
        singles=c.execute("SELECT * FROM movements WHERE document_id IS NULL ORDER BY id").fetchall()
        for m in singles:
            try:
                c.execute("""INSERT OR IGNORE INTO warehouse_documents(document_no,doc_type,doc_date,external_no,supplier_id,source,notes,created_at)
                             VALUES(?,?,?,?,?,?,?,?)""",
                          (m["document_no"],m["move_type"],m["move_date"],m["reference_no"],m["supplier_id"],"Migracja",m["note"],m["created_at"]))
                dr=c.execute("SELECT id FROM warehouse_documents WHERE document_no=?",(m["document_no"],)).fetchone()
                if dr:c.execute("UPDATE movements SET document_id=? WHERE id=?",(dr["id"],m["id"]))
            except Exception:
                pass
        # v12.7 - użytkownicy, uprawnienia, ceny sprzedaży i historia eksportów
        ucols={r["name"] for r in c.execute("PRAGMA table_info(users)").fetchall()}
        for col,ddl in [
            ("username","TEXT"),("display_name","TEXT"),("role","TEXT NOT NULL DEFAULT 'EMPLOYEE'"),
            ("permissions_json","TEXT NOT NULL DEFAULT '[]'"),("active","INTEGER NOT NULL DEFAULT 1"),
            ("must_change_password","INTEGER NOT NULL DEFAULT 0"),("last_login","TEXT"),("updated_at","TEXT")
        ]:
            if col not in ucols:c.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
        # istniejące pojedyncze konto staje się administratorem
        rows=c.execute("SELECT id,username FROM users ORDER BY id").fetchall()
        for i,r in enumerate(rows):
            uname=clean(r["username"],80) if r["username"] else ("admin" if i==0 else f"user{r['id']}")
            role="ADMIN" if i==0 else "EMPLOYEE"
            perms='["*"]' if i==0 else '[]'
            c.execute("UPDATE users SET username=COALESCE(NULLIF(username,''),?),display_name=COALESCE(NULLIF(display_name,''),?),role=COALESCE(NULLIF(role,''),?),permissions_json=CASE WHEN permissions_json IS NULL OR permissions_json='' THEN ? ELSE permissions_json END,active=COALESCE(active,1),updated_at=COALESCE(updated_at,created_at) WHERE id=?",
                      (uname,"Administrator" if i==0 else uname,role,perms,r["id"]))
        # Ważna migracja 12.7: w starszych bazach kolumna role była dodawana z domyślną
        # wartością EMPLOYEE. W efekcie dotychczasowy właściciel mógł stracić prawa administratora.
        # Jeżeli baza nie ma żadnego administratora, pierwsze istniejące konto staje się administratorem.
        if rows and c.execute("SELECT COUNT(*) FROM users WHERE role='ADMIN' AND active=1").fetchone()[0]==0:
            first_id=rows[0]["id"]
            c.execute("UPDATE users SET role='ADMIN',permissions_json='[\"*\"]',active=1,display_name=COALESCE(NULLIF(display_name,''),'Administrator'),updated_at=? WHERE id=?",
                      (datetime.now().isoformat(timespec="seconds"),first_id))
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_users_username ON users(username COLLATE NOCASE)")

        pcols3={r["name"] for r in c.execute("PRAGMA table_info(products)").fetchall()}
        if "woo_publish_enabled" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN woo_publish_enabled INTEGER NOT NULL DEFAULT 0")
        if "woo_product_id" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN woo_product_id INTEGER")
        if "woo_sync_status" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN woo_sync_status TEXT NOT NULL DEFAULT 'NIEPUBLIKOWANY'")
        if "woo_last_sync" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN woo_last_sync TEXT")
        if "woo_last_error" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN woo_last_error TEXT")
        if "margin_pct" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN margin_pct REAL NOT NULL DEFAULT 0")
        if "vat_rate" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN vat_rate REAL NOT NULL DEFAULT 23")
        if "sell_price_net" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN sell_price_net REAL NOT NULL DEFAULT 0")
        if "pricing_mode" not in pcols3:c.execute("ALTER TABLE products ADD COLUMN pricing_mode TEXT NOT NULL DEFAULT 'MARKUP'")
        c.execute("UPDATE products SET pricing_mode='MARKUP' WHERE pricing_mode IS NULL OR pricing_mode NOT IN ('MARKUP','MARGIN')")
        c.execute("UPDATE products SET sell_price_net=CASE WHEN sell_price_net<=0 AND sale_price>0 THEN sale_price WHEN sell_price_net<=0 THEN purchase_price ELSE sell_price_net END")
        c.execute("UPDATE products SET margin_pct=CASE WHEN purchase_price>0 AND sell_price_net>0 AND ABS(margin_pct)<0.0001 THEN ROUND((sell_price_net/purchase_price-1)*100,2) ELSE margin_pct END")
        c.execute("""CREATE TABLE IF NOT EXISTS pricing_settings(
          id INTEGER PRIMARY KEY CHECK(id=1), vat_rate REAL NOT NULL DEFAULT 23, pricing_mode TEXT NOT NULL DEFAULT 'MARKUP',
          pricing_pct REAL NOT NULL DEFAULT 0, updated_at TEXT NOT NULL
        )""")
        c.execute("INSERT OR IGNORE INTO pricing_settings(id,vat_rate,pricing_mode,pricing_pct,updated_at) VALUES(1,23,'MARKUP',0,?)",(datetime.now().isoformat(timespec="seconds"),))

        c.execute("""CREATE TABLE IF NOT EXISTS audit_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,username TEXT,method TEXT NOT NULL,path TEXT NOT NULL,
          permission TEXT,created_at TEXT NOT NULL,outcome TEXT NOT NULL DEFAULT 'PENDING',details TEXT,
          FOREIGN KEY(user_id) REFERENCES users(id)
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_log(created_at)")
        c.execute("""CREATE TABLE IF NOT EXISTS b2b_export_history(
          id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,user_id INTEGER,username TEXT,file_name TEXT NOT NULL,
          file_path TEXT NOT NULL,item_count INTEGER NOT NULL DEFAULT 0,vin TEXT,note TEXT,
          FOREIGN KEY(user_id) REFERENCES users(id)
        )""")
        tcols={r["name"] for r in c.execute("PRAGMA table_info(tools)").fetchall()}
        if "b2b_availability" not in tcols:c.execute("ALTER TABLE tools ADD COLUMN b2b_availability TEXT")
        if "b2b_checked_at" not in tcols:c.execute("ALTER TABLE tools ADD COLUMN b2b_checked_at TEXT")
        if "b2b_source_url" not in tcols:c.execute("ALTER TABLE tools ADD COLUMN b2b_source_url TEXT")
        if "eur_rate_date" not in tcols:c.execute("ALTER TABLE tools ADD COLUMN eur_rate_date TEXT")
        if "eur_rate_table" not in tcols:c.execute("ALTER TABLE tools ADD COLUMN eur_rate_table TEXT")
        # 15.2.3 — kod kreskowy nadawany automatycznie także starszym kartotekom.
        try:
            for _p in c.execute("SELECT id FROM products WHERE barcode IS NULL OR barcode='' ORDER BY id").fetchall():
                ensure_product_barcode(c,_p["id"])
        except Exception:
            pass
        # Po każdej migracji połącz już istniejące relacje Mercedes z lokalnymi kartotekami.
        # Dzięki temu zamienniki zaimportowane w różnej kolejności zaczynają działać bez ponownego importu.
        try:
            reconcile_mercedes_substitutes(c)
        except Exception:
            pass

def pwd_hash(password,salt=None):
    sb=secrets.token_bytes(16) if salt is None else base64.b64decode(salt)
    dg=hashlib.pbkdf2_hmac("sha256",password.encode(),sb,310000)
    return base64.b64encode(sb).decode(),base64.b64encode(dg).decode()

def verify_password(password,salt,expected):
    _,got=pwd_hash(password,salt)
    return hmac.compare_digest(got,expected)

def setup_required():
    with db() as c:return c.execute("SELECT COUNT(*) FROM users").fetchone()[0]==0

def user_dict(row):
    if not row:return None
    d=dict(row)
    try:d["permissions"]=json.loads(d.get("permissions_json") or "[]")
    except Exception:d["permissions"]=[]
    d.pop("password_salt",None);d.pop("password_hash",None);d.pop("permissions_json",None)
    return d

def get_user_by_id(user_id):
    with db() as c:return c.execute("SELECT * FROM users WHERE id=?",(user_id,)).fetchone()

def has_permission(session,perm):
    if not session:return False
    if session.get("role")=="ADMIN":return True
    perms=session.get("permissions") or []
    return "*" in perms or perm in perms

def permission_for_request(path,method):
    if method not in ("POST","PUT","DELETE"):return None
    if path.startswith("/api/account/"):return None
    rules=[
      ("/api/users","users_admin"),("/api/user/","users_admin"),("/api/database","data_admin"),("/api/quick-catalog","products_edit"),
      ("/api/integrations","integrations_edit"),("/api/intercars","integrations_edit"),("/api/woo","integrations_edit"),("/api/shop-beta","integrations_edit"),
      ("/api/product","products_edit"),("/api/pricing","products_edit"),("/api/movement","stock_edit"),("/api/document","documents_edit"),
      ("/api/alternative","substitutes_edit"),("/api/tool","tools_edit"),("/api/supplier","suppliers_edit"),
      ("/api/location","locations_edit"),("/api/contractor","contractors_edit"),("/api/b2b/upload-xlsx","b2b_import")
    ]
    for prefix,perm in rules:
        if path.startswith(prefix):return perm
    return "write_general"

def audit_start(session,method,path,perm):
    try:
        with db() as c:
            cur=c.execute("INSERT INTO audit_log(user_id,username,method,path,permission,created_at,outcome) VALUES(?,?,?,?,?,?,?)",
                          (session.get("user_id"),session.get("username"),method,clean(path,500),perm or "",datetime.now().isoformat(timespec="seconds"),"PENDING"))
            return cur.lastrowid
    except Exception:return None

def audit_finish(audit_id,outcome,details=""):
    if not audit_id:return
    try:
        with db() as c:c.execute("UPDATE audit_log SET outcome=?,details=? WHERE id=?",(clean(outcome,80),clean(details,500),audit_id))
    except Exception:pass

def new_session(user):
    sid=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24)
    ud=user_dict(user) if not isinstance(user,dict) else dict(user)
    perms=ud.get("permissions") or []
    with SESSIONS_LOCK:SESSIONS[sid]={"csrf":csrf,"expires":time.time()+SESSION_TTL,"user_id":ud.get("id"),"username":ud.get("username") or "admin","display_name":ud.get("display_name") or ud.get("username") or "Administrator","role":ud.get("role") or "EMPLOYEE","permissions":perms}
    return sid,csrf

def get_session(cookie_header):
    if not cookie_header:return None,None
    sc=cookies.SimpleCookie()
    try:sc.load(cookie_header)
    except Exception:return None,None
    m=sc.get("mbmag_session")
    if not m:return None,None
    sid=m.value
    with SESSIONS_LOCK:
        s=SESSIONS.get(sid)
        if not s:return None,None
        if s["expires"]<time.time():
            SESSIONS.pop(sid,None);return None,None
        s["expires"]=time.time()+SESSION_TTL
    # odśwież rolę/uprawnienia z bazy, aby blokada konta działała natychmiast
    try:
        r=get_user_by_id(s.get("user_id"))
        if not r or not int(r["active"] or 0):
            with SESSIONS_LOCK:SESSIONS.pop(sid,None)
            return None,None
        u=user_dict(r);s.update({"username":u.get("username"),"display_name":u.get("display_name"),"role":u.get("role"),"permissions":u.get("permissions") or []})
    except Exception:pass
    return sid,s

def clean(v,n=1000): return str(v or "").strip()[:n]
def fnum(v):
    try:return float(v or 0)
    except Exception:return 0.0
def inum(v):
    if v in (None,""):return None
    try:return int(v)
    except Exception:return None

def normalize_pricing_mode(v):
    mode=clean(v,20).upper()
    return mode if mode in ("MARKUP","MARGIN") else "MARKUP"

def calc_sell_net(purchase,pct,mode="MARKUP"):
    purchase=max(0,fnum(purchase));pct=fnum(pct);mode=normalize_pricing_mode(mode)
    if purchase<=0:return 0.0
    if mode=="MARGIN":
        # Marża = (sprzedaż-zakup)/sprzedaż. 100% i więcej nie ma sensu matematycznego.
        pct=max(-100,min(99.99,pct));den=1-(pct/100.0)
        return round(purchase/den,2) if den>0 else 0.0
    pct=max(-100,pct)
    return round(purchase*(1+pct/100.0),2)

def pricing_pct_from_prices(purchase,sell,mode="MARKUP"):
    purchase=max(0,fnum(purchase));sell=max(0,fnum(sell));mode=normalize_pricing_mode(mode)
    if purchase<=0 or sell<=0:return 0.0
    if mode=="MARGIN":return round(((sell-purchase)/sell)*100.0,2)
    return round(((sell/purchase)-1)*100.0,2)

def get_pricing_settings(c):
    r=c.execute("SELECT vat_rate,pricing_mode,pricing_pct,updated_at FROM pricing_settings WHERE id=1").fetchone()
    if not r:return {"vat_rate":23.0,"pricing_mode":"MARKUP","pricing_pct":0.0,"updated_at":""}
    return {"vat_rate":max(0,fnum(r["vat_rate"])),"pricing_mode":normalize_pricing_mode(r["pricing_mode"]),"pricing_pct":fnum(r["pricing_pct"]),"updated_at":clean(r["updated_at"],40)}


class DATA_BLOB(ctypes.Structure):
    _fields_=[("cbData",ctypes.c_ulong),("pbData",ctypes.POINTER(ctypes.c_ubyte))]


def clean_mb_availability_label(status,raw=""):
    status=clean(status,30).upper()
    labels={
        "DEALER":"Dostępne u dealera",
        "CENTRAL":"Dostępne w magazynie centralnym",
        "GERMANY":"Dostępne w Niemczech",
        "UNAVAILABLE":"Niedostępne",
        "UNKNOWN":"Status nieustalony",
        "ERROR":"Błąd odczytu dostępności",
    }
    value=clean(raw,500)
    # B2B często wkłada do aria/title ciągi klas CSS; tego nie pokazujemy użytkownikowi.
    noisy=bool(re.search(r"(?:cursor|d-flex|align-items|justify-content|status-|xy-|class=|display-|flex-|padding-|margin-)",value,re.I))
    if noisy or len(value)>120 or (value and value.count("-")>=6):
        value=""
    if not value or value.lower() in {"green","yellow","red","unknown"}:
        return labels.get(status,"Status nieustalony")
    return value

def _blob(data):
    buf=ctypes.create_string_buffer(data)
    return buf,DATA_BLOB(len(data),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))

def protect_secret(value):
    raw=(value or "").encode("utf-8")
    if not raw:return ""
    if os.name!="nt":return "fallback:"+base64.b64encode(raw).decode()
    in_buf,in_blob=_blob(raw);out_blob=DATA_BLOB()
    ok=ctypes.windll.crypt32.CryptProtectData(ctypes.byref(in_blob),None,None,None,None,0,ctypes.byref(out_blob))
    if not ok:raise OSError("DPAPI protect failed")
    try:return "dpapi:"+base64.b64encode(ctypes.string_at(out_blob.pbData,out_blob.cbData)).decode()
    finally:ctypes.windll.kernel32.LocalFree(out_blob.pbData)

def unprotect_secret(value):
    if not value:return ""
    if value.startswith("fallback:"):return base64.b64decode(value.split(":",1)[1]).decode()
    if not value.startswith("dpapi:") or os.name!="nt":return ""
    raw=base64.b64decode(value.split(":",1)[1]);in_buf,in_blob=_blob(raw);out_blob=DATA_BLOB()
    ok=ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(in_blob),None,None,None,None,0,ctypes.byref(out_blob))
    if not ok:raise OSError("DPAPI unprotect failed")
    try:return ctypes.string_at(out_blob.pbData,out_blob.cbData).decode()
    finally:ctypes.windll.kernel32.LocalFree(out_blob.pbData)

def read_integrations():
    out={
      "woo_url":"https://sklep.mbautoserwis.com","woo_key":"","woo_secret":"","woo_auto_enabled":False,"woo_auto_minutes":10,\
      "woo_catalog_beta_enabled":False,"woo_catalog_status":"draft","woo_catalog_price_mode":"gross",\
      "woo_orders_sync_cursor":"",\
      "ic_base_url":"https://api.webapi.intercars.eu/ic","ic_token_url":"https://is.webapi.intercars.eu/oauth2/token",\
      "ic_client_id":"","ic_client_secret":"","ic_location":"","ic_ship_to":""
    }
    if INTEGRATIONS_PATH.exists():
        try:
            raw=json.loads(INTEGRATIONS_PATH.read_text(encoding="utf-8"))
            for k in ("woo_url","woo_catalog_status","woo_catalog_price_mode","woo_orders_sync_cursor","ic_base_url","ic_token_url","ic_location","ic_ship_to"):
                if raw.get(k):out[k]=raw[k]
            out["woo_auto_enabled"]=bool(raw.get("woo_auto_enabled",False));out["woo_catalog_beta_enabled"]=bool(raw.get("woo_catalog_beta_enabled",False))
            try:out["woo_auto_minutes"]=max(1,min(1440,int(raw.get("woo_auto_minutes",10))))
            except Exception:out["woo_auto_minutes"]=10
            for k in ("woo_key","woo_secret","ic_client_id","ic_client_secret"):
                out[k]=unprotect_secret(raw.get(k,""))
        except Exception:pass
    return out

def save_integrations(data):
    old=read_integrations()
    obj={}
    for k in ("woo_url","woo_catalog_status","woo_catalog_price_mode","woo_orders_sync_cursor","ic_base_url","ic_token_url","ic_location","ic_ship_to"):
        obj[k]=clean(data.get(k) or old[k],400).rstrip("/")
    obj["woo_auto_enabled"]=bool(data.get("woo_auto_enabled",old.get("woo_auto_enabled",False)));obj["woo_catalog_beta_enabled"]=bool(data.get("woo_catalog_beta_enabled",old.get("woo_catalog_beta_enabled",False)))
    try:obj["woo_auto_minutes"]=max(1,min(1440,int(data.get("woo_auto_minutes",old.get("woo_auto_minutes",10)))))
    except Exception:obj["woo_auto_minutes"]=10
    for k in ("woo_key","woo_secret","ic_client_id","ic_client_secret"):
        val=data.get(k) or old[k]
        obj[k]=protect_secret(val)
    INTEGRATIONS_PATH.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")


def read_ui_preferences():
    out={"theme":"light"}
    try:
        if UI_PREFS_PATH.exists():
            raw=json.loads(UI_PREFS_PATH.read_text(encoding="utf-8"))
            if raw.get("theme") in ("light","dark"):out["theme"]=raw["theme"]
    except Exception:pass
    return out

def save_ui_preferences(data):
    theme=clean((data or {}).get("theme"),20).lower()
    if theme not in ("light","dark"):raise ValueError("bad_theme")
    obj={"theme":theme,"updated_at":datetime.now().isoformat(timespec="seconds")}
    tmp=UI_PREFS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
    os.replace(tmp,UI_PREFS_PATH)
    return obj

def get_b2b_token():
    try:
        token=B2B_TOKEN_PATH.read_text(encoding="utf-8").strip()
        if len(token)>=32:return token
    except Exception:pass
    token=secrets.token_urlsafe(36)
    B2B_TOKEN_PATH.write_text(token,encoding="utf-8")
    return token

def regenerate_b2b_token():
    token=secrets.token_urlsafe(36)
    B2B_TOKEN_PATH.write_text(token,encoding="utf-8")
    return token

def normalize_mb_part(value):
    return re.sub(r"[\s.\-]+","",str(value or "")).upper()

def normalize_lookup_code(value):
    return re.sub(r"[^A-Z0-9]+","",str(value or "").upper())

def auto_barcode_seed(oem_no="",sku=""):
    code=normalize_lookup_code(oem_no or sku)
    return code[:120] if code else ""

def ensure_product_barcode(c,product_id):
    row=c.execute("SELECT id,oem_no,sku,barcode FROM products WHERE id=?",(product_id,)).fetchone()
    if not row:return ""
    current=clean(row["barcode"],120)
    if current:return current
    seed=auto_barcode_seed(row["oem_no"],row["sku"])
    if seed and not c.execute("SELECT id FROM products WHERE barcode=? AND id<>?",(seed,product_id)).fetchone():
        c.execute("UPDATE products SET barcode=? WHERE id=?",(seed,product_id));return seed
    base=f"MBAS{int(product_id):010d}";candidate=base;n=0
    while c.execute("SELECT id FROM products WHERE barcode=? AND id<>?",(candidate,product_id)).fetchone():
        n+=1;candidate=f"{base}{n:02d}"
    c.execute("UPDATE products SET barcode=? WHERE id=?",(candidate,product_id))
    return candidate

def parse_b2b_text(raw_text):
    text=str(raw_text or "")[:350000]
    lines=[]
    for x in text.splitlines():
        x=re.sub(r"\s+"," ",x).strip()
        if x and (not lines or lines[-1]!=x):
            lines.append(x)
    joined="\n".join(lines)

    vin=""
    vm=re.search(r"(?<![A-Z0-9])([A-HJ-NPR-Z0-9]{17})(?![A-Z0-9])",joined,re.I)
    if vm:vin=vm.group(1).upper()

    part_re=re.compile(r"(?<![A-Z0-9])([A-Z]\s*\d{3}[\s.\-]*\d{3}[\s.\-]*\d{2}[\s.\-]*\d{2}(?:[\s.\-]*\d{2})?)(?![A-Z0-9])",re.I)
    parts=[];seen=set()
    for line in lines:
        for m in part_re.finditer(line):
            code=normalize_mb_part(m.group(1))
            if code in seen:continue
            seen.add(code)
            parts.append({"code":code,"context":line[:500]})
            if len(parts)>=120:break
        if len(parts)>=120:break

    time_re=re.compile(r"(?<!\w)(\d{1,3}(?:[.,]\d{1,2})?)\s*(h|hr|hrs|std\.?|godz\.?|godziny?|hours?|aw|ze)(?!\w)",re.I)
    op_re=re.compile(r"(?<!\w)((?:[A-Z]{1,4}\s*)?\d{2,3}[-/]\d{3,5}(?:[-/]\d{2})?)(?!\w)",re.I)
    operations=[];seen_ops=set()
    for line in lines:
        tm=time_re.search(line)
        if not tm:continue
        opm=op_re.search(line)
        code=(opm.group(1).strip() if opm else "")
        value=tm.group(1).replace(",",".")
        unit=tm.group(2).lower().rstrip(".")
        key=(code,value,unit,line[:220])
        if key in seen_ops:continue
        seen_ops.add(key)
        operations.append({"code":code,"value":value,"unit":unit,"context":line[:700]})
        if len(operations)>=180:break
    return vin,parts,operations


def ensure_supplier(c,name):
    name=clean(name,250) or "Mercedes-Benz"
    row=c.execute("SELECT id FROM suppliers WHERE lower(name)=lower(?) LIMIT 1",(name,)).fetchone()
    if row:return row["id"]
    cur=c.execute("INSERT INTO suppliers(name,notes,active) VALUES(?,?,1)",(name,"Utworzony automatycznie przez MB B2B Bridge"))
    return cur.lastrowid

def save_b2b_availability_from_item(c,product_id,item):
    status=clean(item.get("availability_status"),30).upper()
    if status not in ("DEALER","CENTRAL","GERMANY","UNAVAILABLE","UNKNOWN"):return
    now=datetime.now().isoformat(timespec="seconds")
    c.execute("""INSERT INTO mb_availability_cache(product_id,status_code,dealer_name,checked_oem,checked_at,source_url,raw_label,details_json,error,source)
                 VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(product_id) DO UPDATE SET status_code=excluded.status_code,dealer_name=excluded.dealer_name,checked_oem=excluded.checked_oem,checked_at=excluded.checked_at,source_url=excluded.source_url,raw_label=excluded.raw_label,details_json=excluded.details_json,error=NULL,source='B2B_IMPORT'""",
              (product_id,status,clean(item.get("availability_dealer"),300),normalize_mb_part(item.get("oem_no")),now,clean(item.get("source_url"),1500),clean_mb_availability_label(status,item.get("availability_label")),json.dumps(item.get("availability_details") if isinstance(item.get("availability_details"),dict) else {},ensure_ascii=False),"","B2B_IMPORT"))

def upsert_diagram_hotspot(c,diagram_fingerprint,position,oem_no,name,marker_x,marker_y,source_url,updated_at=None):
    """Legacy-safe hotspot upsert. Does not require a UNIQUE constraint from newer DB schemas."""
    fp=clean(diagram_fingerprint,80);pos=clean(position,30);oem=normalize_mb_part(oem_no);name=clean(name,300)
    if not fp or not pos:return False
    try:x=float(marker_x);y=float(marker_y)
    except Exception:return False
    if not (0<=x<=1 and 0<=y<=1):return False
    now=updated_at or datetime.now().isoformat(timespec="seconds")
    row=c.execute("""SELECT id FROM mercedes_diagram_hotspots
                     WHERE diagram_fingerprint=? AND position=? AND COALESCE(oem_no,'')=COALESCE(?,'')
                     ORDER BY id DESC LIMIT 1""",(fp,pos,oem)).fetchone()
    if row:
        row_id=row["id"] if isinstance(row,sqlite3.Row) else row[0]
        c.execute("UPDATE mercedes_diagram_hotspots SET name=?,marker_x=?,marker_y=?,source_url=?,updated_at=? WHERE id=?",
                  (name,x,y,clean(source_url,1500),now,row_id))
        # Usuń ewentualne duplikaty ze starych baz bez ograniczenia UNIQUE.
        c.execute("DELETE FROM mercedes_diagram_hotspots WHERE diagram_fingerprint=? AND position=? AND COALESCE(oem_no,'')=COALESCE(?,'') AND id<>?",
                  (fp,pos,oem,row_id))
    else:
        c.execute("""INSERT INTO mercedes_diagram_hotspots(diagram_fingerprint,position,oem_no,name,marker_x,marker_y,source_url,updated_at)
                     VALUES(?,?,?,?,?,?,?,?)""",(fp,pos,oem,name,x,y,clean(source_url,1500),now))
    return True

def save_b2b_hotspots(c,product_id,item):
    p=c.execute("SELECT diagram_fingerprint,oem_no,name,diagram_position,diagram_marker_x,diagram_marker_y,source_url FROM products WHERE id=?",(product_id,)).fetchone()
    if not p:return
    fp=clean(p["diagram_fingerprint"],80)
    if not fp:return
    now=datetime.now().isoformat(timespec="seconds");rows=item.get("diagram_hotspots") if isinstance(item.get("diagram_hotspots"),list) else []
    if p["diagram_position"] and p["diagram_marker_x"] is not None and p["diagram_marker_y"] is not None:rows=[{"position":p["diagram_position"],"oem_no":p["oem_no"],"name":p["name"],"x":p["diagram_marker_x"],"y":p["diagram_marker_y"]},*rows]
    for h in rows[:500]:
        if not isinstance(h,dict):continue
        pos=clean(h.get("position"),30);oem=normalize_mb_part(h.get("oem_no"));name=clean(h.get("name"),300)
        try:x=float(h.get("x"));y=float(h.get("y"))
        except Exception:continue
        if not pos or not (0<=x<=1 and 0<=y<=1):continue
        upsert_diagram_hotspot(c,fp,pos,oem,name,x,y,item.get("source_url") or p["source_url"],now)

def b2b_upsert_product(c,item,supplier_id,create_stock_zero=True):
    now=datetime.now().isoformat(timespec="seconds")
    sku=clean(item.get("sku"),120)
    oem=normalize_mb_part(item.get("oem_no"))
    related=[normalize_mb_part(x) for x in (item.get("related_numbers") or []) if normalize_mb_part(x)]
    name=clean(item.get("name"),300) or (f"Mercedes-Benz OEM {oem}" if oem else (sku or "Część Mercedes-Benz"))
    purchase=max(0,fnum(item.get("purchase_price")))
    suggested=max(0,fnum(item.get("suggested_price")))
    preview=clean(item.get("preview_image"),6_000_000)
    source_url=clean(item.get("source_url"),1500)
    diagram_fingerprint=hashlib.sha256(preview.encode("utf-8",errors="ignore")).hexdigest()[:32] if preview else ""
    diagram_position=clean(item.get("diagram_position"),30)
    try: diagram_marker_x=float(item.get("diagram_marker_x")) if item.get("diagram_marker_x") is not None else None
    except Exception: diagram_marker_x=None
    try: diagram_marker_y=float(item.get("diagram_marker_y")) if item.get("diagram_marker_y") is not None else None
    except Exception: diagram_marker_y=None
    if diagram_marker_x is not None and not (0 <= diagram_marker_x <= 1): diagram_marker_x=None
    if diagram_marker_y is not None and not (0 <= diagram_marker_y <= 1): diagram_marker_y=None
    row=b2b_find_product(c,sku,oem,related)
    if row:
        pid=row["id"]
        old_oem=normalize_mb_part(row["oem_no"])
        if oem and oem!=old_oem:
            other=c.execute("SELECT id FROM products WHERE oem_no=? AND id<>?",(oem,pid)).fetchone()
            if not other:
                # Zmieniamy numer główny tylko wtedy, gdy obecny numer występuje w B2B jako numer powiązany
                # nowej pozycji. W przeciwnym razie nowy numer trafia do aliasów, aby nie "przerzucać"
                # numeru głównego przy imporcie tej samej części z innego widoku.
                if old_oem and old_oem in related:
                    add_product_alias(c,pid,old_oem,"MB_PREVIOUS","Poprzedni numer Mercedes")
                    c.execute("UPDATE products SET oem_no=? WHERE id=?",(oem,pid))
                else:
                    add_product_alias(c,pid,oem,"MB_RELATED","Numer powiązany z B2B")
        effective_purchase=purchase if purchase>0 else fnum(row["purchase_price"])
        pricing_mode=normalize_pricing_mode(row["pricing_mode"] if "pricing_mode" in row.keys() else "MARKUP")
        pricing_pct=fnum(row["margin_pct"])
        # 15.6.3: B2B nazwa produktu + poprawny krok narzutu; cena katalogowa nadal jest domyślną ceną sprzedaży netto.
        # Marża/narzut staje się wartością informacyjną wyliczoną z zakupu i ceny katalogowej.
        if suggested>0:
            recalculated_sell=suggested
            recalculated_pct=pricing_pct_from_prices(effective_purchase,suggested,pricing_mode) if effective_purchase>0 else pricing_pct
        else:
            recalculated_sell=calc_sell_net(effective_purchase,pricing_pct,pricing_mode) if purchase>0 else fnum(row["sell_price_net"] if "sell_price_net" in row.keys() else 0)
            recalculated_pct=pricing_pct
        c.execute("""UPDATE products SET
            sku=CASE WHEN ?<>'' THEN ? ELSE sku END,
            name=CASE WHEN length(?)>=3 THEN ? ELSE name END,
            supplier_id=COALESCE(?,supplier_id),
            barcode=CASE WHEN (barcode IS NULL OR barcode='') AND ?<>'' THEN ? ELSE barcode END,
            purchase_price=CASE WHEN ?>0 THEN ? ELSE purchase_price END,
            sale_price=CASE WHEN ?>0 THEN ? ELSE sale_price END,
            sell_price_net=CASE WHEN ?>0 THEN ? ELSE sell_price_net END,
            margin_pct=CASE WHEN ?>0 THEN ? ELSE margin_pct END,
            preview_image=CASE WHEN (preview_image IS NULL OR preview_image='') AND ?<>'' THEN ? ELSE preview_image END,
            source_url=CASE WHEN ?<>'' THEN ? ELSE source_url END,
            diagram_position=CASE WHEN ?<>'' THEN ? ELSE diagram_position END,
            diagram_marker_x=COALESCE(?,diagram_marker_x),
            diagram_marker_y=COALESCE(?,diagram_marker_y),
            diagram_fingerprint=CASE WHEN ?<>'' THEN ? ELSE diagram_fingerprint END,
            category=CASE WHEN category IS NULL OR category='' THEN 'Mercedes B2B' ELSE category END,
            catalog_source='B2B',catalog_checked_at=?,commerce_checked_at=?,active=1,updated_at=?
            WHERE id=?""",
            (sku,sku,name,name,supplier_id,oem,oem,purchase,purchase,suggested,suggested,recalculated_sell,recalculated_sell,suggested,recalculated_pct,preview,preview,source_url,source_url,diagram_position,diagram_position,diagram_marker_x,diagram_marker_y,diagram_fingerprint,diagram_fingerprint,now,now,now,pid))
        ensure_product_barcode(c,pid)
        for rel in related:
            if rel!=oem:add_product_alias(c,pid,rel,"MB_RELATED","Numer powiązany z B2B")
        return pid,False
    barcode=oem or sku
    ps=get_pricing_settings(c);pricing_mode=ps["pricing_mode"];pricing_pct=ps["pricing_pct"];vat_rate=ps["vat_rate"]
    sell_net=suggested if suggested>0 else (calc_sell_net(purchase,pricing_pct,pricing_mode) if purchase>0 else 0)
    if suggested>0 and purchase>0:pricing_pct=pricing_pct_from_prices(purchase,suggested,pricing_mode)
    cur=c.execute("""INSERT INTO products(
        sku,oem_no,barcode,name,category,supplier_id,stock_qty,min_qty,purchase_price,sale_price,margin_pct,vat_rate,pricing_mode,sell_price_net,unit,notes,active,created_at,updated_at,preview_image,source_url,diagram_position,diagram_marker_x,diagram_marker_y,diagram_fingerprint
    ) VALUES(?,?,?,?,?,?,0,0,?,?,?,?,?,?,?, 'Utworzono przez MB B2B Bridge',1,?,?,?,?,?,?,?,?)""",
    (sku,oem,barcode,name,"Mercedes B2B",supplier_id,purchase,suggested,pricing_pct,vat_rate,pricing_mode,sell_net,clean(item.get("unit"),20) or "szt.",now,now,preview,source_url,diagram_position,diagram_marker_x,diagram_marker_y,diagram_fingerprint))
    pid=cur.lastrowid
    ensure_product_barcode(c,pid)
    c.execute("UPDATE products SET catalog_source='B2B',catalog_checked_at=?,commerce_checked_at=? WHERE id=?",(now,now,pid))
    for rel in related:
        if rel!=oem:add_product_alias(c,pid,rel,"MB_RELATED","Numer powiązany z B2B")
    return pid,True

def b2b_import_key(import_type,page_url,order_no,purchase_date,supplier_name,items):
    compact=[]
    for x in items:
        compact.append({
            "sku":clean(x.get("sku"),120),
            "oem":normalize_mb_part(x.get("oem_no")),
            "name":clean(x.get("name"),300),
            "qty":round(abs(fnum(x.get("quantity") or 1)),4),
            "buy":round(max(0,fnum(x.get("purchase_price"))),4),
            "rrp":round(max(0,fnum(x.get("suggested_price"))),4)
        })
    raw=json.dumps({
        "type":import_type,"url":clean(page_url,1500),"order":clean(order_no,150),
        "date":clean(purchase_date,20),"supplier":clean(supplier_name,250),"items":compact
    },ensure_ascii=False,sort_keys=True,separators=(",",":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def add_product_alias(c,product_id,alias_no,alias_type="MB_RELATED",note=""):
    alias=normalize_mb_part(alias_no)
    if not alias:return
    prod=c.execute("SELECT oem_no FROM products WHERE id=?",(product_id,)).fetchone()
    if prod and normalize_mb_part(prod["oem_no"])==alias:return
    existing=c.execute("SELECT product_id FROM product_aliases WHERE alias_no=?",(alias,)).fetchone()
    if existing:
        return
    try:
        c.execute("INSERT INTO product_aliases(product_id,alias_no,alias_type,note,created_at) VALUES(?,?,?,?,?)",
                  (product_id,alias,alias_type,clean(note,500),datetime.now().isoformat(timespec="seconds")))
    except sqlite3.IntegrityError:
        pass

def save_mercedes_number_relations(c,product_id,item):
    now=datetime.now().isoformat(timespec="seconds")
    replacement=[]
    for key in ("replacement_numbers","related_numbers"):
        vals=item.get(key) if isinstance(item.get(key),list) else []
        for x in vals:
            n=normalize_mb_part(x)
            if n and n not in replacement: replacement.append(n)
    main=normalize_mb_part(item.get("oem_no") or item.get("sku"))
    for n in replacement:
        if n and n!=main:
            add_product_alias(c,product_id,n,"MB_PREVIOUS","Numer poprzedni / zastępujący Mercedes B2B")

    subs=[]
    for x in (item.get("substitute_numbers") if isinstance(item.get("substitute_numbers"),list) else []):
        n=normalize_mb_part(x)
        if n and n!=main and n not in subs:subs.append(n)
    for n in subs:
        c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at) VALUES(?,?,?,?,?)
                     ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                  (product_id,n,"SUBSTITUTE","Zamiennik / logistyczny zamiennik Mercedes B2B",now))
        other=find_product_by_any_code(c,n)
        if other and int(other["id"])!=int(product_id):
            link_substitutes(c,int(product_id),int(other["id"]))
            if main:
                c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at) VALUES(?,?,?,?,?)
                             ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                          (int(other["id"]),main,"SUBSTITUTE","Powiązanie wzajemne z Mercedes B2B",now))

    # Kierunkowe zastąpienia z Parts Information. Dzięki temu można wskazać najnowszy numer
    # bez traktowania wszystkich numerów z rysunku jako równoważnych aliasów.
    links=item.get("replacement_links") if isinstance(item.get("replacement_links"),list) else []
    for edge in links[:200]:
        if not isinstance(edge,dict):continue
        frm=normalize_mb_part(edge.get("from"));to=normalize_mb_part(edge.get("to"))
        if not frm or not to or frm==to:continue
        if main and frm==main:
            c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at) VALUES(?,?,?,?,?)
                         ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                      (product_id,to,"REPLACED_BY","Nowszy numer wg Mercedes Parts Information",now))
        if main and to==main:
            c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at) VALUES(?,?,?,?,?)
                         ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                      (product_id,frm,"REPLACES","Poprzedni numer wg Mercedes Parts Information",now))
    latest=normalize_mb_part(item.get("latest_oem"))
    if main and latest and latest!=main:
        c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at) VALUES(?,?,?,?,?)
                     ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                  (product_id,latest,"REPLACED_BY","Najnowszy numer wg łańcucha zastąpień Mercedes Parts Information",now))

    # Gdy kartoteka zamiennika powstanie dopiero teraz, połącz ją ze starszymi relacjami.
    if main:
        refs=c.execute("""SELECT DISTINCT r.product_id,p.oem_no,p.sku FROM mercedes_part_relations r
                          JOIN products p ON p.id=r.product_id
                          WHERE r.related_oem=? AND r.relation_type='SUBSTITUTE' AND r.product_id<>?""",
                       (main,product_id)).fetchall()
        for ref in refs:
            other_id=int(ref["product_id"])
            link_substitutes(c,int(product_id),other_id)
            ref_code=normalize_mb_part(ref["oem_no"] or ref["sku"])
            if ref_code:
                c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at) VALUES(?,?,?,?,?)
                             ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                          (product_id,ref_code,"SUBSTITUTE","Powiązanie wzajemne z istniejącej relacji B2B",now))

def find_product_by_any_code(c,code):
    raw=clean(code,200)
    norm=normalize_lookup_code(raw)
    sqlnorm=lambda field:f"REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPPER(COALESCE({field},'')),' ',''),'-',''),'.',''),'_',''),'/','')"
    row=c.execute(f"""SELECT p.* FROM products p
                     WHERE ({sqlnorm('p.barcode')}=? OR {sqlnorm('p.sku')}=? OR {sqlnorm('p.oem_no')}=?)
                     ORDER BY p.active DESC,p.id LIMIT 1""",(norm,norm,norm)).fetchone()
    if row:return row
    a=c.execute(f"""SELECT p.* FROM product_aliases a JOIN products p ON p.id=a.product_id
                   WHERE {sqlnorm('a.alias_no')}=? ORDER BY p.active DESC,p.id LIMIT 1""",(norm,)).fetchone()
    if a:return a
    ic=c.execute("""SELECT p.* FROM intercars_product_links il JOIN products p ON p.id=il.product_id
                    WHERE il.ic_sku=? OR il.ic_index=? OR il.eans_json LIKE ?
                    ORDER BY p.active DESC,p.id LIMIT 1""",(raw,raw,'%"'+raw+'"%')).fetchone()
    return ic

def b2b_find_product(c,sku,oem,related=None):
    codes=[normalize_mb_part(oem),clean(sku,120)]
    for x in (related or []):codes.append(normalize_mb_part(x))
    for code in codes:
        if not code:continue
        r=find_product_by_any_code(c,code)
        if r:return r
    return None

def normalize_polish_date(value):
    s=clean(value,30)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}",s):return s
    m=re.fullmatch(r"(\d{1,2})[./-](\d{1,2})[./-](20\d{2})",s)
    if m:return f"{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
    return datetime.now().strftime("%Y-%m-%d")

def nbp_eur_rate_for_date(value):
    """NBP table A EUR rate for date; weekends/holidays use the latest earlier publication."""
    d=normalize_polish_date(value)
    try: base=datetime.strptime(d,"%Y-%m-%d")
    except Exception: raise ValueError("Nieprawidłowa data")
    start=(base-timedelta(days=10)).strftime("%Y-%m-%d")
    url=f"https://api.nbp.pl/api/exchangerates/rates/a/eur/{start}/{d}/?format=json"
    req=urllib.request.Request(url,headers={"Accept":"application/json","User-Agent":"MB-Auto-Serwis-Magazyn/15.3.5"})
    try:
        with urllib.request.urlopen(req,timeout=12,context=ssl.create_default_context()) as r:
            obj=json.loads(r.read().decode("utf-8"))
        rates=obj.get("rates") or []
        if not rates: raise ValueError("Brak notowań EUR w zakresie")
        rr=rates[-1]
        return {"rate":round(float(rr.get("mid") or 0),4),"effective_date":clean(rr.get("effectiveDate") or d,10),"table":clean(rr.get("no") or "A",80)}
    except urllib.error.HTTPError as e:
        raise ValueError(f"NBP HTTP {e.code}")
    except Exception as e:
        if isinstance(e,ValueError): raise
        raise ValueError("Nie udało się pobrać kursu NBP")


def _xlsx_col_idx(ref):
    letters=''.join(ch for ch in str(ref or '') if ch.isalpha()).upper()
    n=0
    for ch in letters:n=n*26+(ord(ch)-64)
    return n

def _xlsx_text(si, ns):
    return ''.join((t.text or '') for t in si.iter(ns+'t'))

def _excel_date_for_import(v):
    if v is None:return ''
    if isinstance(v,(int,float)):
        if 20000 <= float(v) <= 80000:
            try:return (datetime(1899,12,30)+timedelta(days=float(v))).strftime('%Y-%m-%d')
            except Exception:return ''
        return ''
    s=clean(v,40).strip()
    if not s or s in ('------','---','-','#VALUE!'):return ''
    if re.fullmatch(r'\d+(?:\.\d+)?',s):
        try:
            f=float(s)
            if 20000<=f<=80000:return (datetime(1899,12,30)+timedelta(days=f)).strftime('%Y-%m-%d')
        except Exception:pass
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}',s):return s
    m=re.fullmatch(r'(\d{1,2})[./-](\d{1,2})[./-](20\d{2})',s)
    if m:return f'{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}'
    return ''

def _import_num(v):
    if v is None:return 0.0
    if isinstance(v,(int,float)):return float(v)
    s=str(v).strip().replace('\xa0',' ').replace(',','.');m=re.search(r'-?\d+(?:\.\d+)?',s)
    try:return float(m.group(0)) if m else 0.0
    except Exception:return 0.0

def _import_str(v):
    if v is None:return ''
    if isinstance(v,float) and v.is_integer():return str(int(v))
    s=str(v).strip()
    return '' if s in ('#VALUE!','------','---','-') else s

def parse_tools_inventory_xlsx(raw):
    """Parse the workshop tool inventory spreadsheet without external Excel dependencies.
    Supports regular cells and Excel rich-value in-cell images (the format used by the user's file).
    """
    ns='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    relns='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
    pkgns='{http://schemas.openxmlformats.org/package/2006/relationships}'
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=set(z.namelist())
        shared=[]
        if 'xl/sharedStrings.xml' in names:
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[_xlsx_text(si,ns) for si in root.findall(ns+'si')]
        sheet_name='xl/worksheets/sheet1.xml'
        try:
            wb=ET.fromstring(z.read('xl/workbook.xml'));rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
            relmap={x.attrib.get('Id'):x.attrib.get('Target') for x in rels.findall(pkgns+'Relationship')}
            sh=wb.find('.//'+ns+'sheet')
            rid=sh.attrib.get(relns+'id') if sh is not None else None
            target=relmap.get(rid,'worksheets/sheet1.xml')
            sheet_name=posixpath.normpath(posixpath.join('xl',target))
        except Exception:pass
        image_by_vm={}
        try:
            rdns='{http://schemas.microsoft.com/office/spreadsheetml/2017/richdata}'
            rrns='{http://schemas.microsoft.com/office/spreadsheetml/2022/richvaluerel}'
            rvroot=ET.fromstring(z.read('xl/richData/rdrichvalue.xml'))
            rich=[[v.text or '' for v in rv.findall(rdns+'v')] for rv in rvroot.findall(rdns+'rv')]
            rrroot=ET.fromstring(z.read('xl/richData/richValueRel.xml'))
            relids=[x.attrib.get(relns+'id') for x in rrroot.findall(rrns+'rel')]
            xrels=ET.fromstring(z.read('xl/richData/_rels/richValueRel.xml.rels'))
            targets={x.attrib.get('Id'):x.attrib.get('Target') for x in xrels.findall(pkgns+'Relationship')}
            for vm,vals in enumerate(rich,1):
                if not vals:continue
                try:idx=int(vals[0]);rid=relids[idx];target=targets.get(rid,'')
                except Exception:continue
                member=posixpath.normpath(posixpath.join('xl/richData',target))
                if member not in names:continue
                ext=Path(member).suffix.lower();mime='image/jpeg' if ext in ('.jpg','.jpeg') else ('image/webp' if ext=='.webp' else 'image/png')
                image_by_vm[vm]='data:'+mime+';base64,'+base64.b64encode(z.read(member)).decode('ascii')
        except Exception:pass
        root=ET.fromstring(z.read(sheet_name));rows=[]
        for row in root.findall('.//'+ns+'row'):
            rn=int(row.attrib.get('r','0') or 0);cells={};vms={}
            for c in row.findall(ns+'c'):
                ref=c.attrib.get('r','');ci=_xlsx_col_idx(ref);typ=c.attrib.get('t','');ve=c.find(ns+'v');val=ve.text if ve is not None else None
                if typ=='s' and val is not None:
                    try:val=shared[int(val)]
                    except Exception:val=''
                elif typ=='inlineStr':
                    val=''.join((t.text or '') for t in c.iter(ns+'t'))
                elif typ=='b':val=True if val=='1' else False
                elif typ=='e':val=''
                elif val is not None:
                    try:
                        f=float(val);val=int(f) if f.is_integer() else f
                    except Exception:pass
                cells[ci]=val
                if c.attrib.get('vm'):
                    try:vms[ci]=int(c.attrib['vm'])
                    except Exception:pass
            if rn<3:continue
            catalog=_import_str(cells.get(2));desc=_import_str(cells.get(3))
            if not catalog and not desc:continue
            if not catalog:continue
            price=max(0,_import_num(cells.get(4)));currency=_import_str(cells.get(5)).upper() or ('PLN' if 'PLN' in _import_str(cells.get(4)).upper() else '')
            qty=max(0,_import_num(cells.get(6))) or 1;purchase_date=_excel_date_for_import(cells.get(7));invoice=_import_str(cells.get(8));location=_import_str(cells.get(9))
            image=image_by_vm.get(vms.get(10),'')
            name=desc or ('Mercedes-Benz '+catalog if catalog.upper().startswith('W') else catalog)
            manufacturer='Mercedes-Benz' if catalog.upper().startswith('W') or 'XENTRY' in name.upper() else ''
            category='Diagnostyka Mercedes-Benz' if 'XENTRY' in name.upper() else ('Narzędzia specjalne Mercedes-Benz' if catalog.upper().startswith('W') else 'Wyposażenie warsztatu')
            rows.append({'source_row':rn,'catalog_no':catalog,'name':name,'category':category,'manufacturer':manufacturer,'price':price,'currency':currency,'quantity':qty,'purchase_date':purchase_date,'invoice_no':invoice,'location':location,'image_data':image})
        return rows

def _tool_import_signature(item):
    code=normalize_lookup_code(item.get('catalog_no')) or clean(item.get('catalog_no'),160).upper()
    eur=round(fnum(item.get('purchase_price_eur')),4);pln=round(fnum(item.get('purchase_price_pln')),2)
    price_key=('EUR',eur) if eur>0 else ('PLN',pln)
    return (code,clean(item.get('invoice_no'),160).upper(),clean(item.get('purchase_date'),10),round(fnum(item.get('quantity')),4),price_key)

def _location_for_tool_import(c,label):
    label=clean(label,160)
    if not label:return None
    r=c.execute("SELECT id FROM locations WHERE lower(code)=lower(?) OR lower(COALESCE(name,''))=lower(?) ORDER BY id LIMIT 1",(label,label)).fetchone()
    if r:return r['id']
    code=re.sub(r'[^A-Z0-9]+','-',label.upper()).strip('-')[:45] or 'NARZEDZIA'
    base=code;n=2
    while c.execute('SELECT 1 FROM locations WHERE code=?',(code,)).fetchone():
        code=(base[:40]+'-'+str(n));n+=1
    cur=c.execute("INSERT INTO locations(code,name,notes,active) VALUES(?,?,?,1)",(code,label,'Utworzono automatycznie przy imporcie narzędzi z Excel'))
    return cur.lastrowid

def mf_lookup_nip(nip):
    n=re.sub(r"\D","",str(nip or ""))
    if len(n)!=10:raise ValueError("NIP musi mieć 10 cyfr")
    date=datetime.now().strftime("%Y-%m-%d")
    url=f"https://wl-api.mf.gov.pl/api/search/nip/{n}?date={date}"
    req=urllib.request.Request(url,headers={"Accept":"application/json","User-Agent":"MB-Auto-Serwis-Magazyn/5.0"})
    with urllib.request.urlopen(req,timeout=20,context=ssl.create_default_context()) as r:
        obj=json.loads(r.read().decode("utf-8"))
    result=obj.get("result") or {}
    subj=result.get("subject") or {}
    if not subj:raise ValueError("Nie znaleziono firmy dla tego NIP")
    return {
        "name":clean(subj.get("name"),300),
        "nip":clean(subj.get("nip") or n,20),
        "regon":clean(subj.get("regon"),30),
        "krs":clean(subj.get("krs"),30),
        "address":clean(subj.get("workingAddress") or subj.get("residenceAddress"),500),
        "vat_status":clean(subj.get("statusVat"),80),
        "request_id":clean(result.get("requestId"),120),
    }

def extract_scan_code(raw):
    s=clean(raw,500)
    part_re=re.compile(r"([A-Z]\s*\d{3}[\s.\-]*\d{3}[\s.\-]*\d{2}[\s.\-]*\d{2}(?:[\s.\-]*\d{2})?)",re.I)
    m=part_re.search(s)
    if m:return normalize_mb_part(m.group(1))
    return s.strip()

def wc_request(url,key,secret):
    token=base64.b64encode(f"{key}:{secret}".encode()).decode()
    req=urllib.request.Request(url,headers={"Authorization":"Basic "+token,"Accept":"application/json","User-Agent":"MB-Magazyn/2.0"})
    return urllib.request.urlopen(req,timeout=35,context=ssl.create_default_context())

def ic_token():
    cfg=read_integrations()
    if not cfg["ic_client_id"] or not cfg["ic_client_secret"]:raise ValueError("Brak ClientID/ClientSecret Inter Cars")
    basic=base64.b64encode(f"{cfg['ic_client_id']}:{cfg['ic_client_secret']}".encode()).decode()
    data=urllib.parse.urlencode({"grant_type":"client_credentials","scope":"allinone"}).encode()
    req=urllib.request.Request(cfg["ic_token_url"],data=data,headers={"Authorization":"Basic "+basic,"Content-Type":"application/x-www-form-urlencoded","Accept":"application/json"},method="POST")
    with urllib.request.urlopen(req,timeout=30,context=ssl.create_default_context()) as r:
        obj=json.loads(r.read().decode("utf-8"))
    token=obj.get("access_token")
    if not token:raise ValueError("Brak access_token w odpowiedzi Inter Cars")
    return token

def ic_call(path,method="GET",params=None,body=None,token=None):
    cfg=read_integrations();token=token or ic_token();url=cfg["ic_base_url"]+path
    if params:url+="?"+urllib.parse.urlencode(params)
    data=None if body is None else json.dumps(body).encode("utf-8")
    headers={"Authorization":"Bearer "+token,"Accept":"application/json","Accept-Language":"pl","User-Agent":"MB-Magazyn/2.0"}
    if data is not None:headers["Content-Type"]="application/json"
    req=urllib.request.Request(url,data=data,headers=headers,method=method)
    with urllib.request.urlopen(req,timeout=35,context=ssl.create_default_context()) as r:
        raw=r.read().decode("utf-8")
        return json.loads(raw) if raw else None

def normalize_ic_items(obj):
    if isinstance(obj,list):items=obj
    elif isinstance(obj,dict):
        items=None
        for k in ("content","products","items","results","data","lines"):
            if isinstance(obj.get(k),list):items=obj[k];break
        if items is None:items=[obj] if obj else []
    else:items=[]
    out=[]
    def pick(d,*keys):
        for k in keys:
            if isinstance(d,dict) and d.get(k) not in (None,""):return d.get(k)
        return ""
    for x in items:
        if not isinstance(x,dict):continue
        eans=pick(x,"eans","barcodes","BARCODES")
        if isinstance(eans,str):eans=[v.strip() for v in re.split(r"[,;| ]+",eans) if v.strip()]
        elif not isinstance(eans,list):eans=[]
        out.append({
          "sku":clean(pick(x,"sku","SKU","towKod","towkod","tow_kod"),120),
          "index":clean(pick(x,"index","icIndex","ic_index","articleNumber","ARTICLE_NUMBER"),160),
          "brand":clean(pick(x,"brand","manufacturer","manufacturerName","producer"),160),
          "name":clean(pick(x,"name","shortDescription","label","title"),300),
          "description":clean(pick(x,"description","longDescription"),1600),
          "tecdoc":clean(pick(x,"tecDoc","tecdoc","TEC_DOC"),160),
          "article_number":clean(pick(x,"articleNumber","ARTICLE_NUMBER"),160),
          "eans":[clean(v,80) for v in eans if clean(v,80)],
          "unit":clean(pick(x,"unit","UNIT"),30),
          "image_url":clean(pick(x,"imageUrl","imageURL","image","pictureUrl","photoUrl"),1200),
          "blocked_return":bool(pick(x,"blockedReturn","blocked_return")),
          "raw":x
        })
    return out

def ic_norm(value):
    return re.sub(r"[^A-Z0-9]", "", clean(value,300).upper())

def cache_ic_items(c,items):
    now=datetime.now().isoformat(timespec="seconds")
    for item in items or []:
        sku=clean(item.get("sku"),120);idx=clean(item.get("index"),160);article=clean(item.get("article_number"),160);td=clean(item.get("tecdoc"),160)
        if not sku and not idx and not article:continue
        key=("sku:"+sku) if sku else (("index:"+idx) if idx else "article:"+article)
        eans=item.get("eans") if isinstance(item.get("eans"),list) else []
        fields=[sku,idx,article,td,clean(item.get("brand"),160),clean(item.get("name"),300),clean(item.get("description"),1000),*eans]
        norm_blob=" ".join(sorted({ic_norm(x) for x in fields if ic_norm(x)}))
        safe={k:v for k,v in item.items() if k!="raw"}
        c.execute("""INSERT INTO intercars_catalog_cache(cache_key,ic_sku,ic_index,article_number,tecdoc,brand,name,eans_text,norm_blob,item_json,updated_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(cache_key) DO UPDATE SET ic_sku=excluded.ic_sku,ic_index=excluded.ic_index,article_number=excluded.article_number,tecdoc=excluded.tecdoc,brand=excluded.brand,name=excluded.name,eans_text=excluded.eans_text,norm_blob=excluded.norm_blob,item_json=excluded.item_json,updated_at=excluded.updated_at""",
                  (key,sku,idx,article,td,clean(item.get("brand"),160),clean(item.get("name"),300)," ".join(eans),norm_blob,json.dumps(safe,ensure_ascii=False),now))

def local_ic_search(c,query,limit=50):
    nq=ic_norm(query)
    if not nq:return []
    rows=c.execute("SELECT * FROM intercars_catalog_cache WHERE norm_blob LIKE ? ORDER BY updated_at DESC LIMIT 500",("%"+nq+"%",)).fetchall()
    scored=[]
    for r in rows:
        try:item=json.loads(r["item_json"] or "{}")
        except Exception:item={}
        codes=[item.get("sku"),item.get("index"),item.get("article_number"),item.get("tecdoc"),*(item.get("eans") or [])]
        norms=[ic_norm(x) for x in codes if x]
        score=0
        if nq in norms:score=100
        elif any(x.startswith(nq) or nq.startswith(x) for x in norms if x):score=80
        elif any(nq in x for x in norms):score=65
        else:score=40
        item["source"]="cache"
        scored.append((score,item))
    scored.sort(key=lambda x:(-x[0],clean(x[1].get("brand"),100),clean(x[1].get("index"),100)))
    return [x[1] for x in scored[:limit]]

def save_ic_oe_link(c,product_id,item):
    prow=c.execute("SELECT oem_no,sku FROM products WHERE id=?",(product_id,)).fetchone()
    if not prow:return
    sku=clean(item.get("sku"),120);idx=clean(item.get("index"),160);article=clean(item.get("article_number"),160)
    key=("sku:"+sku) if sku else (("index:"+idx) if idx else ("article:"+article if article else ""))
    if not key:return
    now=datetime.now().isoformat(timespec="seconds");eans=item.get("eans") if isinstance(item.get("eans"),list) else []
    oem=normalize_mb_part(prow["oem_no"] or prow["sku"] or "")
    c.execute("""INSERT INTO intercars_oe_links(product_id,oem_no,link_key,ic_sku,ic_index,brand,name,article_number,tecdoc,eans_json,image_url,created_at,updated_at)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(product_id,link_key) DO UPDATE SET oem_no=excluded.oem_no,ic_sku=excluded.ic_sku,ic_index=excluded.ic_index,brand=excluded.brand,name=excluded.name,article_number=excluded.article_number,tecdoc=excluded.tecdoc,eans_json=excluded.eans_json,image_url=excluded.image_url,updated_at=excluded.updated_at""",
              (product_id,oem,key,sku,idx,clean(item.get("brand"),160),clean(item.get("name"),300),article,clean(item.get("tecdoc"),160),json.dumps(eans,ensure_ascii=False),clean(item.get("image_url"),1200),now,now))

def ic_remote_search(query,mode="auto",token=None):
    token=token or ic_token();query=clean(query,160);results=[];seen=set()
    variants=[]
    for v in (query, re.sub(r"[\s.\-_/]+","",query), re.sub(r"\s+"," ",query).strip()):
        if v and v not in variants:variants.append(v)
    calls=[]
    if mode=="sku":calls=[("sku",query)]
    elif mode=="index":calls=[("index",query)]
    else:
        # Auto: indeks jest najczęstszy w IC; SKU próbujemy dodatkowo dla kodów alfanumerycznych.
        calls += [("index",v) for v in variants[:3]]
        if re.fullmatch(r"[A-Za-z0-9]+",query or ""):calls.insert(0,("sku",query))
    for field,val in calls:
        try:obj=ic_call("/catalog/products",params={field:val},token=token)
        except urllib.error.HTTPError as e:
            if e.code in (400,404):continue
            raise
        for item in normalize_ic_items(obj):
            key=(item.get("sku") or "")+"|"+(item.get("index") or "")
            if key in seen:continue
            seen.add(key);results.append(item)
    if results:results=enrich_ic(results,token)
    return results

def enrich_ic(items,token=None):
    token=token or ic_token();cfg=read_integrations();skus=[x["sku"] for x in items if x.get("sku")][:100]
    stock_by_sku={};price_by_sku={}
    if skus:
        params={"sku":",".join(skus)}
        if cfg.get("ic_location"):params["location"]=cfg["ic_location"]
        if cfg.get("ic_ship_to"):params["shipTo"]=cfg["ic_ship_to"]
        try:
            st=ic_call("/inventory/stock",params=params,token=token)
            for x in st if isinstance(st,list) else []:stock_by_sku.setdefault(str(x.get("sku") or ""),[]).append(x)
        except Exception:pass
        try:
            body={"lines":[{"sku":sku,"quantity":1} for sku in skus]}
            if cfg.get("ic_location"):body["location"]=[v.strip() for v in str(cfg["ic_location"]).split(",") if v.strip()]
            if cfg.get("ic_ship_to"):body["shipTo"]=cfg["ic_ship_to"]
            qt=ic_call("/pricing/quote",method="POST",body=body,token=token)
            qlines=qt.get("lines",[]) if isinstance(qt,dict) else (qt if isinstance(qt,list) else [])
            for x in qlines:
                pr=x.get("price") or {};price_by_sku[str(x.get("sku") or "")]={"list_net":fnum(pr.get("listPriceNet")),"net":fnum(pr.get("customerPriceNet")),"gross":fnum(pr.get("customerPriceGross")),"currency":clean(pr.get("currencyCode"),10) or "PLN","eans":x.get("eans") if isinstance(x.get("eans"),list) else []}
        except Exception:pass
    for x in items:
        rows=stock_by_sku.get(x.get("sku"),[])
        x["stock_locations"]=[{"location":clean(r.get("location"),50),"availability":fnum(r.get("availability")),"latestDeliveryDate":clean(r.get("latestDeliveryDate"),30),"orderDateTimeTo":clean(r.get("orderDateTimeTo"),50)} for r in rows]
        x["stock"]=sum(fnum(r.get("availability")) for r in rows)
        pr=price_by_sku.get(x.get("sku"),{});x["list_price_net"]=pr.get("list_net",0);x["price_net"]=pr.get("net",0);x["price_gross"]=pr.get("gross",0);x["currency"]=pr.get("currency","PLN")
        if not x.get("eans") and pr.get("eans"):x["eans"]=[clean(v,80) for v in pr["eans"] if clean(v,80)]
    return items

def save_ic_link(c,product_id,item):
    now=datetime.now().isoformat(timespec="seconds");eans=item.get("eans") if isinstance(item.get("eans"),list) else [];stocks=item.get("stock_locations") if isinstance(item.get("stock_locations"),list) else []
    c.execute("""INSERT INTO intercars_product_links(product_id,ic_sku,ic_index,brand,tecdoc,article_number,eans_json,location_code,stock_qty,stock_json,list_price_net,customer_price_net,customer_price_gross,currency,checked_at,raw_json)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(product_id) DO UPDATE SET ic_sku=excluded.ic_sku,ic_index=excluded.ic_index,brand=excluded.brand,tecdoc=excluded.tecdoc,article_number=excluded.article_number,eans_json=excluded.eans_json,location_code=excluded.location_code,stock_qty=excluded.stock_qty,stock_json=excluded.stock_json,list_price_net=excluded.list_price_net,customer_price_net=excluded.customer_price_net,customer_price_gross=excluded.customer_price_gross,currency=excluded.currency,checked_at=excluded.checked_at,raw_json=excluded.raw_json""",
              (product_id,clean(item.get("sku"),120),clean(item.get("index"),160),clean(item.get("brand"),160),clean(item.get("tecdoc"),160),clean(item.get("article_number"),160),json.dumps(eans,ensure_ascii=False),clean(read_integrations().get("ic_location"),100),fnum(item.get("stock")),json.dumps(stocks,ensure_ascii=False),fnum(item.get("list_price_net")),fnum(item.get("price_net")),fnum(item.get("price_gross")),clean(item.get("currency"),10) or "PLN",now,json.dumps(item.get("raw") or {},ensure_ascii=False)))
    if eans:
        row=c.execute("SELECT barcode FROM products WHERE id=?",(product_id,)).fetchone()
        if row and not clean(row["barcode"],120):c.execute("UPDATE products SET barcode=?,updated_at=? WHERE id=?",(clean(eans[0],120),now,product_id))

def refresh_ic_link(c,product_id,token=None):
    link=c.execute("SELECT * FROM intercars_product_links WHERE product_id=?",(product_id,)).fetchone()
    if not link:return None
    token=token or ic_token();mode="sku" if clean(link["ic_sku"],120) else "index";query=clean(link["ic_sku"] if mode=="sku" else link["ic_index"],160)
    if not query:return None
    obj=ic_call("/catalog/products",params={mode:query},token=token);items=normalize_ic_items(obj)
    if not items:return None
    item=next((x for x in items if (mode=="sku" and x.get("sku")==query) or (mode=="index" and x.get("index")==query)),items[0]);item=enrich_ic([item],token)[0];save_ic_link(c,product_id,item);save_ic_oe_link(c,product_id,item);cache_ic_items(c,[item]);return item

def find_product(c,sku="",oem="",woo_product_id=0):
    sku=clean(sku,120);oem=clean(oem,120);woo_product_id=inum(woo_product_id)
    # WooCommerce Product ID jest najpewniejszym powiązaniem po publikacji z CRM.
    if woo_product_id:
        r=c.execute("SELECT * FROM products WHERE active=1 AND woo_product_id=?",(woo_product_id,)).fetchone()
        if r:return r
    if sku:
        r=c.execute("SELECT * FROM products WHERE active=1 AND sku=?",(sku,)).fetchone()
        if r:return r
    if oem:
        r=c.execute("SELECT * FROM products WHERE active=1 AND oem_no=?",(oem,)).fetchone()
        if r:return r
    # Woo potrafi zwrócić SKU bez spacji/myślników. Porównuj także wersję znormalizowaną.
    target=normalize_lookup_code(sku or oem)
    if target:
        for r in c.execute("SELECT * FROM products WHERE active=1 AND (COALESCE(sku,'')<>'' OR COALESCE(oem_no,'')<>'' OR COALESCE(barcode,'')<>'')").fetchall():
            if target in {normalize_lookup_code(r["sku"]),normalize_lookup_code(r["oem_no"]),normalize_lookup_code(r["barcode"])}:
                return r
    return None

def upsert_issue(c,source,external_doc,external_line,sku,oem,name,qty,itype,message):
    now=datetime.now().isoformat(timespec="seconds")
    c.execute("""INSERT INTO integration_issues(source,external_doc,external_line,sku,oem_no,item_name,quantity,issue_type,message,status,created_at,updated_at)
                 VALUES(?,?,?,?,?,?,?,?,?,'OPEN',?,?)
                 ON CONFLICT(source,external_doc,external_line,issue_type) DO UPDATE SET sku=excluded.sku,oem_no=excluded.oem_no,item_name=excluded.item_name,quantity=excluded.quantity,message=excluded.message,status='OPEN',updated_at=excluded.updated_at""",
              (source,external_doc,external_line,sku,oem,name,qty,itype,message,now,now))

def close_issues(c,source,external_doc,external_line):
    c.execute("UPDATE integration_issues SET status='RESOLVED',updated_at=? WHERE source=? AND external_doc=? AND external_line=? AND status='OPEN'",(datetime.now().isoformat(timespec="seconds"),source,external_doc,external_line))

def create_auto_move(c,move_type,date,product_id,qty,price,reference,moto_order="",shop_order="",note=""):
    p=c.execute("SELECT stock_qty FROM products WHERE id=? AND active=1",(product_id,)).fetchone()
    if not p:return None,"product_not_found"
    delta=MOVE_TYPES[move_type]*abs(qty);new_qty=float(p["stock_qty"])+delta
    if new_qty < -0.000001:return None,f"insufficient_stock:{p['stock_qty']}"
    doc=next_doc(c,move_type,date);now=datetime.now().isoformat(timespec="seconds")
    cur=c.execute("""INSERT INTO movements(document_no,move_type,move_date,product_id,quantity,unit_price,reference_no,motowarsztat_order_no,shop_order_no,supplier_id,note,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",(doc,move_type,date,product_id,delta,price,reference,moto_order,shop_order,None,note,now))
    c.execute("UPDATE products SET stock_qty=?,updated_at=? WHERE id=?",(new_qty,now,product_id));return cur.lastrowid,doc

def apply_external_line(c,source,external_doc,external_line,sku,oem,item_name,desired_qty,status,date,shop_order="",moto_order="",external_product_id=0):
    now=datetime.now().isoformat(timespec="seconds")
    row=c.execute("SELECT * FROM external_sync_lines WHERE source=? AND external_doc=? AND external_line=?",(source,external_doc,external_line)).fetchone()
    applied=float(row["applied_qty"]) if row else 0.0
    # Linie oznaczone jako historia po wadliwej pierwszej synchronizacji nigdy nie tworzą ruchów.
    if row and clean(row["last_status"],80)=="HISTORICAL_IGNORE" and not row["product_id"]:
        close_issues(c,source,external_doc,external_line)
        c.execute("UPDATE external_sync_lines SET last_seen=? WHERE source=? AND external_doc=? AND external_line=?",(now,source,external_doc,external_line))
        return 0,0
    product=c.execute("SELECT * FROM products WHERE id=? AND active=1",(row["product_id"],)).fetchone() if row and row["product_id"] else find_product(c,sku,oem,external_product_id)
    # Jeżeli nie ma już nic do zastosowania (np. anulowane stare zamówienie), brak mapowania nie jest problemem.
    if not product and abs(desired_qty-applied)<=0.000001:
        close_issues(c,source,external_doc,external_line)
        return 0,0
    if not product:
        extra=f" Woo product ID: {inum(external_product_id)}." if inum(external_product_id) else ""
        upsert_issue(c,source,external_doc,external_line,sku,oem,item_name,desired_qty,"UNMATCHED_PRODUCT","Brak pasującego SKU/OEM/Woo ID w magazynie."+extra)
        c.execute("""INSERT INTO external_sync_lines(source,external_doc,external_line,sku,oem_no,product_id,desired_qty,applied_qty,last_status,last_seen)
                     VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(source,external_doc,external_line) DO UPDATE SET sku=excluded.sku,oem_no=excluded.oem_no,desired_qty=excluded.desired_qty,last_status=excluded.last_status,last_seen=excluded.last_seen""",
                  (source,external_doc,external_line,sku,oem,None,desired_qty,applied,status,now));return 0,1
    delta=desired_qty-applied;made=0
    if abs(delta)>0.000001:
        move_type=("WZ" if source=="woocommerce" else "RW") if delta>0 else "ZW"
        note=("Automatyczne WZ WooCommerce" if source=="woocommerce" else "Automatyczne RW MotoWarsztat") if delta>0 else "Automatyczny zwrot / korekta integracji"
        mid,res=create_auto_move(c,move_type,date,product["id"],abs(delta),float(product["purchase_price"] or 0),f"{source}:{external_doc}:{external_line}",moto_order,shop_order,note)
        if not mid:
            upsert_issue(c,source,external_doc,external_line,sku,oem,item_name,desired_qty,"STOCK_ERROR",res);return 0,1
        applied=desired_qty;made=1
    close_issues(c,source,external_doc,external_line)
    c.execute("""INSERT INTO external_sync_lines(source,external_doc,external_line,sku,oem_no,product_id,desired_qty,applied_qty,last_status,last_seen)
                 VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(source,external_doc,external_line) DO UPDATE SET sku=excluded.sku,oem_no=excluded.oem_no,product_id=excluded.product_id,desired_qty=excluded.desired_qty,applied_qty=excluded.applied_qty,last_status=excluded.last_status,last_seen=excluded.last_seen""",
              (source,external_doc,external_line,sku,oem,product["id"],desired_qty,applied,status,now));return made,0

def sync_woo_orders(order_rows):
    seen=made=issues=0
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        for o in order_rows:
            seen+=1;oid=str(o.get("id") or o.get("wc_id") or "");number=str(o.get("number") or oid);status=clean(o.get("status"),40);date=clean(o.get("date_created"),40)[:10] or datetime.now().strftime("%Y-%m-%d");active=status in ("processing","completed")
            for it in (o.get("line_items") or []):
                line=str(it.get("id") or it.get("item_wc_id") or "");sku=clean(it.get("sku"),120);qty=abs(fnum(it.get("quantity")));desired=qty if active else 0.0
                m,i=apply_external_line(c,"woocommerce",oid,line,sku,"",clean(it.get("name"),300),desired,status,date,shop_order="#"+number,external_product_id=inum(it.get("product_id")));made+=m;issues+=i
        c.execute("INSERT INTO integration_log(source,synced_at,result,records_seen,movements_created,issues_count,message) VALUES(?,?,?,?,?,?,?)",("woocommerce",datetime.now().isoformat(timespec="seconds"),"OK",seen,made,issues,"Synchronizacja zamówień"));c.commit()
    return seen,made,issues

def _utc_iso_now():
    return datetime.utcnow().replace(microsecond=0).isoformat()+"Z"

def _parse_iso_utc(value):
    v=clean(value,80).strip()
    if not v:return None
    try:return datetime.fromisoformat(v.replace("Z","+00:00")).replace(tzinfo=None)
    except Exception:return None

def _save_woo_cursor(value):
    # Zachowaj wszystkie bieżące ustawienia i sekrety, zmieniając wyłącznie kursor.
    cfg=read_integrations();cfg["woo_orders_sync_cursor"]=value;save_integrations(cfg)

def _initialize_woo_sync_baseline():
    cursor=_utc_iso_now();now=datetime.now().isoformat(timespec="seconds")
    with db() as c:
        old_issues=c.execute("SELECT COUNT(*) FROM integration_issues WHERE source='woocommerce' AND status='OPEN'").fetchone()[0]
        # Dotychczasowe nierozpoznane linie bez wykonanego ruchu pochodzą ze starego importu całej historii.
        c.execute("UPDATE integration_issues SET status='HISTORICAL',message=message||' | Pominięto po aktualizacji 15.3.7: historia sprzed uruchomienia synchronizacji.',updated_at=? WHERE source='woocommerce' AND status='OPEN'",(now,))
        c.execute("UPDATE external_sync_lines SET last_status='HISTORICAL_IGNORE',last_seen=? WHERE source='woocommerce' AND product_id IS NULL AND ABS(COALESCE(applied_qty,0))<0.000001",(now,))
        c.execute("INSERT INTO integration_log(source,synced_at,result,records_seen,movements_created,issues_count,message) VALUES(?,?,?,?,?,?,?)",("woocommerce",now,"BASELINE",0,0,0,f"Start synchronizacji od teraz. Zamknięto {old_issues} historycznych problemów."))
    _save_woo_cursor(cursor)
    return cursor,int(old_issues)

def sync_woo_direct():
    cfg=read_integrations()
    if not cfg["woo_key"] or not cfg["woo_secret"]:raise ValueError("Brak klucza WooCommerce")
    cursor=clean(cfg.get("woo_orders_sync_cursor"),80)
    if not cursor:
        baseline,closed=_initialize_woo_sync_baseline()
        return 0,0,0,{"baseline_initialized":True,"historical_issues_closed":closed,"sync_from":baseline}
    sync_started=_utc_iso_now()
    dt=_parse_iso_utc(cursor) or datetime.utcnow()
    # 5 minut nakładki zabezpiecza przed zmianą zamówienia dokładnie podczas synchronizacji.
    modified_after=(dt-timedelta(minutes=5)).replace(microsecond=0).isoformat()+"Z"
    base=cfg["woo_url"].rstrip("/")+"/wp-json/wc/v3/orders";page=1;orders=[]
    while page<=500:
        qs=urllib.parse.urlencode({"per_page":100,"page":page,"orderby":"date","order":"asc","modified_after":modified_after,"dates_are_gmt":"true"})
        with wc_request(base+"?"+qs,cfg["woo_key"],cfg["woo_secret"]) as r:
            arr=json.loads(r.read().decode("utf-8"));pages=int(r.headers.get("X-WP-TotalPages","0") or 0)
        if not isinstance(arr,list):raise ValueError("Nieprawidłowa odpowiedź WooCommerce")
        orders.extend(arr)
        if not arr or (pages and page>=pages) or (not pages and len(arr)<100):break
        page+=1
    seen,made,issues=sync_woo_orders(orders)
    _save_woo_cursor(sync_started)
    return seen,made,issues,{"baseline_initialized":False,"historical_issues_closed":0,"sync_from":modified_after}

def sync_local_sales():
    if not SALES_DB_PATH.exists():raise FileNotFoundError("Nie znaleziono lokalnej bazy CRM sprzedaży")
    s=sqlite3.connect(f"file:{SALES_DB_PATH}?mode=ro",uri=True);s.row_factory=sqlite3.Row;orders=[]
    for o in s.execute("SELECT * FROM orders ORDER BY date_created"):
        d=dict(o);d["id"]=o["wc_id"];d["line_items"]=[dict(x) for x in s.execute("SELECT * FROM order_items WHERE order_wc_id=?",(o["wc_id"],))];orders.append(d)
    s.close();return sync_woo_orders(orders)

def ensure_group(c,product_id):
    r=c.execute("SELECT group_id FROM product_substitute_group WHERE product_id=?",(product_id,)).fetchone()
    if r:return r["group_id"]
    cur=c.execute("INSERT INTO substitute_groups(name,created_at) VALUES(?,?)",(f"Zamienniki {product_id}",datetime.now().isoformat(timespec="seconds")));gid=cur.lastrowid
    c.execute("INSERT INTO product_substitute_group(product_id,group_id) VALUES(?,?)",(product_id,gid));return gid

def link_substitutes(c,p1,p2):
    g1=c.execute("SELECT group_id FROM product_substitute_group WHERE product_id=?",(p1,)).fetchone();g2=c.execute("SELECT group_id FROM product_substitute_group WHERE product_id=?",(p2,)).fetchone()
    if not g1 and not g2:
        gid=ensure_group(c,p1);c.execute("INSERT OR REPLACE INTO product_substitute_group(product_id,group_id) VALUES(?,?)",(p2,gid));return gid
    if g1 and not g2:
        c.execute("INSERT OR REPLACE INTO product_substitute_group(product_id,group_id) VALUES(?,?)",(p2,g1["group_id"]));return g1["group_id"]
    if g2 and not g1:
        c.execute("INSERT OR REPLACE INTO product_substitute_group(product_id,group_id) VALUES(?,?)",(p1,g2["group_id"]));return g2["group_id"]
    if g1["group_id"]!=g2["group_id"]:
        keep=g1["group_id"];drop=g2["group_id"];c.execute("UPDATE product_substitute_group SET group_id=? WHERE group_id=?",(keep,drop));c.execute("UPDATE external_substitutes SET group_id=? WHERE group_id=?",(keep,drop));c.execute("DELETE FROM substitute_groups WHERE id=?",(drop,));return keep
    return g1["group_id"]

def reconcile_mercedes_substitutes(c):
    """Łączy istniejące relacje SUBSTITUTE z lokalnymi kartotekami i uzupełnia relację w obie strony."""
    rows=c.execute("""SELECT r.product_id,r.related_oem,p.oem_no,p.sku
                      FROM mercedes_part_relations r JOIN products p ON p.id=r.product_id
                      WHERE r.relation_type='SUBSTITUTE'""").fetchall()
    now=datetime.now().isoformat(timespec="seconds")
    linked=0
    for r in rows:
        other=find_product_by_any_code(c,r["related_oem"])
        if not other or int(other["id"])==int(r["product_id"]):
            continue
        link_substitutes(c,int(r["product_id"]),int(other["id"]))
        linked+=1
        source_code=normalize_mb_part(r["oem_no"] or r["sku"])
        if source_code:
            c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at)
                         VALUES(?,?,?,?,?)
                         ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                      (int(other["id"]),source_code,"SUBSTITUTE","Powiązanie wzajemne utworzone automatycznie",now))
    return linked

def get_open_cart(c):
    r=c.execute("SELECT * FROM purchase_carts WHERE status='OPEN' ORDER BY id DESC LIMIT 1").fetchone()
    if r:return r
    now=datetime.now().isoformat(timespec="seconds")
    cur=c.execute("INSERT INTO purchase_carts(name,status,created_at,updated_at) VALUES(?,?,?,?)",("Zamówienie Mercedes","OPEN",now,now))
    return c.execute("SELECT * FROM purchase_carts WHERE id=?",(cur.lastrowid,)).fetchone()

def request_b2b_enrich(c,product_id,oem,force=False):
    code=normalize_mb_part(oem)
    if not code:return None
    existing=c.execute("SELECT id,status FROM b2b_enrich_requests WHERE product_id=? AND status IN ('PENDING','WORKING') ORDER BY id DESC LIMIT 1",(product_id,)).fetchone()
    if existing and not force:return existing["id"]
    if existing and force:
        c.execute("UPDATE b2b_enrich_requests SET status='ERROR',finished_at=?,error='Ponowienie ręczne' WHERE id=?",(datetime.now().isoformat(timespec="seconds"),existing["id"]))
    now=datetime.now().isoformat(timespec="seconds")
    cur=c.execute("INSERT INTO b2b_enrich_requests(product_id,requested_oem,requested_at,status) VALUES(?,?,?,'PENDING')",(product_id,code,now))
    return cur.lastrowid

def request_partsinfo_enrich(c,product_id,oem,force=False):
    code=normalize_mb_part(oem)
    if not code:return None
    existing=c.execute("SELECT id,status FROM partsinfo_enrich_requests WHERE product_id=? AND status IN ('PENDING','WORKING') ORDER BY id DESC LIMIT 1",(product_id,)).fetchone()
    if existing and not force:return existing["id"]
    if existing and force:
        c.execute("UPDATE partsinfo_enrich_requests SET status='ERROR',finished_at=?,error='Ponowienie ręczne' WHERE id=?",(datetime.now().isoformat(timespec="seconds"),existing["id"]))
    now=datetime.now().isoformat(timespec="seconds")
    cur=c.execute("INSERT INTO partsinfo_enrich_requests(product_id,requested_oem,requested_at,status) VALUES(?,?,?,'PENDING')",(product_id,code,now))
    return cur.lastrowid

def request_availability(c,product_id,oem,force=False):
    code=normalize_mb_part(oem)
    if not code:return None
    now=datetime.now().isoformat(timespec="seconds")
    existing=c.execute("SELECT id,status FROM mb_availability_requests WHERE product_id=? AND status IN ('PENDING','WORKING') ORDER BY id DESC LIMIT 1",(product_id,)).fetchone()
    if existing and not force:return existing["id"]
    if existing and force:
        c.execute("UPDATE mb_availability_requests SET status='ERROR',finished_at=?,error='Ponowienie ręczne' WHERE id=?",(now,existing["id"]))
    cur=c.execute("INSERT INTO mb_availability_requests(product_id,requested_oem,codes_json,requested_at,status) VALUES(?,?,?,?, 'PENDING')",(product_id,code,json.dumps([code],ensure_ascii=False),now))
    return cur.lastrowid

def extract_quick_catalog_codes(value):
    """Extract Mercedes-style part numbers from pasted text/CSV without inventing data."""
    if isinstance(value,list):
        text="\n".join(str(x or "") for x in value)
    else:
        text=str(value or "")
    text=text[:250000]
    out=[];seen=set()
    # Typical Mercedes numbers: A2053306510, A000986200016, N000000009504 etc.
    rx=re.compile(r"(?<![A-Z0-9])([A-Z]{1,3}(?:[\s.\-/]*\d){8,14})(?![A-Z0-9])",re.I)
    for m in rx.finditer(text):
        code=normalize_mb_part(m.group(1)).replace("/","")
        if 8<=len(code)<=18 and code not in seen:
            seen.add(code);out.append(code)
    # One-code-per-line / CSV fallback. This also accepts less common MB prefixes.
    for chunk in re.split(r"[\n\r,;\t]+",text):
        code=normalize_mb_part(chunk).replace("/","")
        if 8<=len(code)<=18 and re.fullmatch(r"[A-Z0-9]+",code) and re.search(r"[A-Z]",code) and re.search(r"\d",code) and code not in seen:
            seen.add(code);out.append(code)
    return out[:500]


def infer_part_size_profile(name="",category="",override=""):
    ov=clean(override,10).upper()
    if ov in ("XS","S","M","L","XL"):
        return {"size_class":ov,"source":"MANUAL","confidence":1.0,"reason":"Ręcznie ustawiony gabaryt dla kartoteki"}
    text=(clean(name,300)+" "+clean(category,200)).lower()
    groups={
      "XL":("skrzynia rozdzielcza","skrzynia bieg","silnik kompletn","zderzak","drzwi","maska","szyba","wał napęd","most napęd","dyferencjał","zbiornik paliwa","podsufitka"),
      "L":("wahacz","amortyzator","sprężyna","tarcza ham","chłodnica","intercooler","alternator","rozrusznik","pompa wysok","kolektor","półoś","przekładnia kier","osłona podwozia"),
      "XS":("oring","o-ring","podkład","spinka","klips","pierścień uszczeln","pierscien uszczeln","zawlecz","nit","śruba m","sruba m","nakrętka","uszczelka miedz","uszczelniacz mały"),
      "S":("uszczelk","śruba","sruba","nakręt","tulejka","wkładka gwint","bezpiecznik","przekaźnik","żarów","zarow","wtycz","czujnik","świeca","swieca","spinka"),
      "M":("filtr","pompa","zawór","zawor","przewód","przewod","rolka","napinacz","cewka","termostat","poduszka silnika")
    }
    for cls in ("XL","L","XS","S","M"):
        hit=next((k for k in groups[cls] if k in text),None)
        if hit:return {"size_class":cls,"source":"AUTO","confidence":0.9,"reason":f"Rozpoznano po nazwie/kategorii: {hit}"}
    return {"size_class":"M","source":"AUTO","confidence":0.45,"reason":"Brak jednoznacznego dopasowania — domyślnie M"}

def infer_part_size_class(name="",category="",override=""):
    return infer_part_size_profile(name,category,override)["size_class"]

def location_default_capacity(size):
    return {"XS":12,"S":8,"M":4,"L":2,"XL":1}.get(size,6)

def location_category_affinity(text):
    t=(text or "").lower()
    if any(k in t for k in ("olej","5w30","5w-30","5w40","5w-40","0w20","0w-20","0w30","0w-30","atf","gear oil","transmission oil")):return "OLEJE"
    if any(k in t for k in ("uszczelk","o-ring","oring","podkład","spinka","klips")):return "DROBNICA_USZCZELKI"
    if any(k in t for k in ("śruba","sruba","nakręt","zawlecz","nit")):return "ELEMENTY_ZLACZNE"
    if "filtr" in t:return "FILTRY"
    if any(k in t for k in ("czujnik","przekaźnik","bezpiecznik","wtycz")):return "ELEKTRYKA"
    return "OGOLNA"

def next_auto_location_code(c):
    nums=[]
    for r in c.execute("SELECT code FROM locations WHERE code LIKE 'A-01-%'").fetchall():
        m=re.fullmatch(r"A-01-(\d+)", clean(r["code"],40).upper())
        if m:
            try:nums.append(int(m.group(1)))
            except Exception:pass
    n=(max(nums) if nums else 0)+1
    while c.execute("SELECT 1 FROM locations WHERE UPPER(code)=UPPER(?)",(f"A-01-{n:02d}",)).fetchone():n+=1
    return f"A-01-{n:02d}"

def next_oil_location_code(c):
    nums=[]
    for r in c.execute("SELECT code FROM locations WHERE code LIKE 'OL-01-%'").fetchall():
        m=re.fullmatch(r"OL-01-(\d+)", clean(r["code"],40).upper())
        if m:
            try:nums.append(int(m.group(1)))
            except Exception:pass
    n=(max(nums) if nums else 0)+1
    while c.execute("SELECT 1 FROM locations WHERE UPPER(code)=UPPER(?)",(f"OL-01-{n:02d}",)).fetchone():n+=1
    return f"OL-01-{n:02d}"

def assign_product_to_location(c,product_id,location_id,make_primary=True):
    now=datetime.now().isoformat(timespec="seconds")
    p=c.execute("SELECT stock_qty FROM products WHERE id=?",(product_id,)).fetchone()
    if not p:return
    if make_primary:c.execute("UPDATE product_locations SET is_primary=0,updated_at=? WHERE product_id=?",(now,product_id))
    c.execute("""INSERT INTO product_locations(product_id,location_id,quantity,is_primary,created_at,updated_at) VALUES(?,?,?,?,?,?)
                 ON CONFLICT(product_id,location_id) DO UPDATE SET is_primary=excluded.is_primary,updated_at=excluded.updated_at""",
              (product_id,location_id,max(0,fnum(p["stock_qty"])),1 if make_primary else 0,now,now))
    if make_primary:c.execute("UPDATE products SET location_id=?,updated_at=? WHERE id=?",(location_id,now,product_id))

def suggest_location_for_product(c,product_id,assign=False,create_if_missing=False):
    p=c.execute("SELECT id,name,category,location_id,size_class_override FROM products WHERE id=?",(product_id,)).fetchone()
    if not p:return None
    profile=infer_part_size_profile(p["name"],p["category"],p["size_class_override"])
    size=profile["size_class"]; affinity=location_category_affinity((p["name"] or "")+" "+(p["category"] or ""))
    rows=c.execute("""SELECT l.id,l.code,l.name,COALESCE(l.size_class,'ANY') size_class,COALESCE(l.capacity,0) capacity,COALESCE(l.storage_type,'GENERAL') storage_type,
                      (SELECT COUNT(DISTINCT pl.product_id) FROM product_locations pl JOIN products px ON px.id=pl.product_id WHERE pl.location_id=l.id AND px.active=1) occupied
                      FROM locations l WHERE l.active=1 ORDER BY l.code""").fetchall()
    candidates=[]
    for r in rows:
        sc=clean(r["size_class"],20).upper() or "ANY"
        st=clean(r["storage_type"],30).upper() or "GENERAL"
        is_oil=(affinity=="OLEJE")
        if is_oil and st!="OIL":continue
        if (not is_oil) and st=="OIL":continue
        if sc not in ("ANY",size):continue
        cap=max(0,inum(r["capacity"]));occ=max(0,inum(r["occupied"]))
        if cap and occ>=cap:continue
        occ_rows=c.execute("""SELECT p.name,p.category FROM product_locations pl JOIN products p ON p.id=pl.product_id
                              WHERE pl.location_id=? AND p.active=1 LIMIT 30""",(r["id"],)).fetchall()
        affinities=[location_category_affinity((x["name"] or "")+" "+(x["category"] or "")) for x in occ_rows]
        affinity_penalty=0 if not affinities or affinity in affinities else 0.35
        size_penalty=0 if sc==size else 0.6
        fill=(occ/cap) if cap else occ/50.0
        candidates.append((size_penalty+affinity_penalty+fill,occ,dict(r)))
    created=False
    if candidates:
        candidates.sort(key=lambda x:(x[0],x[1],x[2].get("code") or ""));loc=candidates[0][2]
    elif create_if_missing:
        is_oil=(affinity=="OLEJE")
        code=next_oil_location_code(c) if is_oil else next_auto_location_code(c);cap=location_default_capacity(size)
        storage_type="OIL" if is_oil else "GENERAL"
        name=(f"Oleje · {size}" if is_oil else f"Auto {size} · {affinity.replace('_',' ').title()}")
        cur=c.execute("INSERT INTO locations(code,name,notes,size_class,capacity,storage_type,active) VALUES(?,?,?,?,?,?,1)",
                      (code,name,"Utworzono przez Auto lokalizacja",size,cap,storage_type))
        loc=dict(c.execute("SELECT id,code,name,size_class,capacity,storage_type FROM locations WHERE id=?",(cur.lastrowid,)).fetchone());loc["occupied"]=0;created=True
    else:
        return {**profile,"location":None,"reason":"Brak pasującej lokalizacji z wolnym miejscem."}
    if assign:assign_product_to_location(c,product_id,loc["id"],True)
    return {**profile,"location":loc,"assigned":bool(assign),"created":created,"affinity":affinity}

def create_auto_location_for_product(c,product_id):
    return suggest_location_for_product(c,product_id,assign=True,create_if_missing=True)

def maybe_auto_assign_quick_location(c,product_id):
    q=c.execute("SELECT auto_location FROM quick_catalog_entries WHERE product_id=? ORDER BY id DESC LIMIT 1",(product_id,)).fetchone()
    if not q or not inum(q["auto_location"]):return None
    p=c.execute("SELECT location_id,name FROM products WHERE id=?",(product_id,)).fetchone()
    if not p or p["location_id"] or clean(p["name"],300).upper().startswith("MERCEDES-BENZ OEM "):return None
    return suggest_location_for_product(c,product_id,assign=True,create_if_missing=True)

def quick_catalog_state(pi_status,b2b_status,name):
    pi=(pi_status or "").upper();b2b=(b2b_status or "").upper();generic=clean(name,300).upper().startswith("MERCEDES-BENZ OEM ")
    if pi=="DONE" and b2b=="DONE":return "VERIFY" if generic else "READY"
    if pi=="ERROR" or b2b=="ERROR":return "VERIFY"
    if pi=="WORKING" or b2b=="WORKING":return "WORKING"
    if pi=="PENDING" or b2b=="PENDING":return "QUEUED"
    if pi=="DONE" or b2b=="DONE":return "PARTIAL"
    return "NEW"

def quick_catalog_rows(c):
    rows=c.execute("""SELECT q.id,q.requested_oem,q.product_id,q.source,q.created_at,q.updated_at,
                      p.name,p.oem_no,p.sku,p.category,p.location_id,p.active,p.preview_image,p.diagram_position,
                      COALESCE(q.auto_location,1) auto_location,COALESCE(l.size_class,'ANY') location_size_class,
                      p.catalog_checked_at,p.commerce_checked_at,l.code location_code,
                      (SELECT mr.related_oem FROM mercedes_part_relations mr WHERE mr.product_id=p.id AND mr.relation_type='REPLACED_BY' ORDER BY mr.id DESC LIMIT 1) latest_oem,
                      (SELECT r.status FROM partsinfo_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) pi_status,
                      (SELECT r.error FROM partsinfo_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) pi_error,
                      (SELECT r.warning FROM partsinfo_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) pi_warning,
                      (SELECT r.attempts FROM partsinfo_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) pi_attempts,
                      (SELECT r.status FROM b2b_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) b2b_status,
                      (SELECT r.error FROM b2b_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) b2b_error,
                      av.status_code mb_status_code,av.raw_label mb_status_label,av.checked_at mb_checked_at,
                      p.purchase_price,p.sale_price,p.sell_price_net,p.vat_rate,p.margin_pct,p.pricing_mode
                      FROM quick_catalog_entries q JOIN products p ON p.id=q.product_id
                      LEFT JOIN locations l ON l.id=p.location_id
                      LEFT JOIN mb_availability_cache av ON av.product_id=p.id
                      ORDER BY q.updated_at DESC,q.id DESC LIMIT 1000""").fetchall()
    out=[]
    for r in rows:
        d=dict(r);d["state"]=quick_catalog_state(d.get("pi_status"),d.get("b2b_status"),d.get("name"))
        d["name_known"]=not clean(d.get("name"),300).upper().startswith("MERCEDES-BENZ OEM ")
        d["has_diagram"]=bool(d.get("preview_image"));out.append(d)
    return out

def set_product_stock_target(c,product_id,target_qty,reference_no="INWENTARYZACJA",note="Ustawienie stanu docelowego",source="System"):
    target=max(0,float(target_qty or 0));p=c.execute("SELECT id,name,stock_qty,purchase_price FROM products WHERE id=? AND active=1",(product_id,)).fetchone()
    if not p: raise ValueError("product_not_found")
    current=float(p["stock_qty"] or 0);delta=target-current
    if abs(delta)<0.000001:return {"changed":False,"old":current,"new":target,"document_no":""}
    typ="KOREKTA+" if delta>0 else "KOREKTA-";date=datetime.now().strftime("%Y-%m-%d");now=datetime.now().isoformat(timespec="seconds")
    doc_id,doc=create_warehouse_document(c,typ,date,reference_no,None,source,note)
    c.execute("""INSERT INTO movements(document_no,move_type,move_date,product_id,quantity,unit_price,reference_no,note,created_at,document_id)
                 VALUES(?,?,?,?,?,?,?,?,?,?)""",(doc,typ,date,product_id,delta,max(0,float(p["purchase_price"] or 0)),reference_no,note,now,doc_id))
    c.execute("UPDATE products SET stock_qty=?,updated_at=? WHERE id=?",(target,now,product_id))
    return {"changed":True,"old":current,"new":target,"document_no":doc}

def chrome_executable():
    candidates=[]
    if os.name=="nt":
        for env in ("PROGRAMFILES","PROGRAMFILES(X86)","LOCALAPPDATA"):
            base=os.environ.get(env)
            if base:candidates.append(Path(base)/"Google"/"Chrome"/"Application"/"chrome.exe")
    for cmd in ("google-chrome","google-chrome-stable","chromium","chromium-browser"):
        found=shutil.which(cmd)
        if found:candidates.append(Path(found))
    for x in candidates:
        try:
            if x.exists():return str(x)
        except Exception:pass
    return ""

def open_url_in_chrome(url):
    url=clean(url,1800)
    if not re.match(r"^https://(?:[^/]+\.)?mercedes-benz\.com/|^https://b2bconnect\.mercedes-benz\.com/|^https://aftersales\.mercedes-benz\.com/",url,re.I):
        raise ValueError("url_not_allowed")
    exe=chrome_executable()
    if not exe:raise FileNotFoundError("chrome_not_found")
    subprocess.Popen([exe,"--new-tab",url],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return exe

class WooAPIError(Exception):
    def __init__(self,status,code,message,data=None):
        self.status=int(status or 0);self.code=clean(code,160) or "woo_http";self.message=clean(message,700) or f"WooCommerce HTTP {self.status}";self.data=data or {}
        super().__init__(f"{self.code}: {self.message} (HTTP {self.status})")

def woo_call_json(method,path,payload=None,params=None):
    """WooCommerce REST API request.

    Primary auth is HTTP Basic over HTTPS. Some FastCGI/proxy hosts strip the
    Authorization header; WooCommerce officially recommends query-string auth
    as a fallback in that specific case. We retry only for auth-header style
    failures and only over HTTPS.
    """
    cfg=read_integrations();base=cfg["woo_url"].rstrip("/")+"/wp-json/wc/v3"
    key=cfg.get("woo_key") or "";secret=cfg.get("woo_secret") or ""
    if not key or not secret:raise ValueError("Brak kluczy WooCommerce")
    body=None if payload is None else json.dumps(payload,ensure_ascii=False).encode("utf-8")
    auth=base64.b64encode(f"{key}:{secret}".encode("utf-8")).decode("ascii")

    def _request(query_auth=False):
        q=dict(params or {})
        headers={"Content-Type":"application/json","Accept":"application/json","User-Agent":"MB-Auto-Serwis-Magazyn/15.3.8"}
        if query_auth:
            q["consumer_key"]=key;q["consumer_secret"]=secret
        else:
            headers["Authorization"]="Basic "+auth
        url=base.rstrip("/")+path
        if q:url+="?"+urllib.parse.urlencode(q)
        req=urllib.request.Request(url,data=body,method=method,headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=30) as r:
                raw=r.read().decode("utf-8")
                return json.loads(raw or "{}")
        except urllib.error.HTTPError as e:
            raw=""
            try:raw=e.read().decode("utf-8","replace")
            except Exception:pass
            try:obj=json.loads(raw) if raw else {}
            except Exception:obj={}
            raise WooAPIError(e.code,obj.get("code") or "woo_http",obj.get("message") or raw or f"WooCommerce HTTP {e.code}",obj) from e

    try:
        return _request(False)
    except WooAPIError as e:
        auth_text=(str(e.code)+" "+str(e.message)).lower()
        auth_header_problem=(
            "consumer key is missing" in auth_text or
            "consumer key missing" in auth_text or
            "consumer_key_missing" in auth_text or
            "woocommerce_rest_authentication_error" in auth_text or
            (e.status==401 and "consumer" in auth_text and "key" in auth_text)
        )
        if base.lower().startswith("https://") and auth_header_problem:
            try:return _request(True)
            except WooAPIError:raise
        raise

def _woo_image_error(exc):
    text=(getattr(exc,"code","")+" "+getattr(exc,"message","")).lower()
    return any(x in text for x in ("image","obraz","zdję","upload","download","media","woocommerce_product_image"))



def _guess_ext_from_mime(mime):
    mime=(mime or '').lower()
    if 'png' in mime:return '.png'
    if 'webp' in mime:return '.webp'
    return '.jpg'

def _decode_image_source(src):
    src=clean(src,6_000_000)
    if not src:return (None,None,None)
    if src.startswith('data:image/'):
        m=re.match(r'^data:(image/[^;]+);base64,(.+)$', src, re.I|re.S)
        if not m:return (None,None,None)
        mime=m.group(1).lower();data=base64.b64decode(m.group(2));return (data,mime,_guess_ext_from_mime(mime))
    if src.startswith('http://') or src.startswith('https://'):
        req=urllib.request.Request(src,headers={'User-Agent':'MB-Auto-Serwis-Magazyn/15.3.9'})
        with urllib.request.urlopen(req,timeout=30) as r:
            mime=(r.headers.get_content_type() or 'image/jpeg').lower()
            data=r.read()
        return (data,mime,_guess_ext_from_mime(mime))
    return (None,None,None)

def _annotate_image_bytes(img_bytes, code):
    if not img_bytes or not code or Image is None:return None
    try:
        im=Image.open(io.BytesIO(img_bytes)).convert('RGBA')
        w,h=im.size
        bar_h=max(44, int(h*0.12))
        overlay=Image.new('RGBA', (w,h), (0,0,0,0))
        draw=ImageDraw.Draw(overlay)
        draw.rectangle((0,h-bar_h,w,h), fill=(18,32,62,225))
        font=ImageFont.load_default()
        txt=f'Numer części: {code}'
        tw=draw.textbbox((0,0), txt, font=font)[2]
        tx=max(16, (w-tw)//2)
        ty=h-bar_h + max(8, (bar_h-12)//2)
        draw.text((tx,ty), txt, fill=(255,255,255,255), font=font)
        out=Image.alpha_composite(im, overlay).convert('RGB')
        buf=io.BytesIO();out.save(buf, format='JPEG', quality=92, optimize=True)
        return buf.getvalue()
    except Exception:
        return None

class WPAPIError(Exception):
    def __init__(self,status,code,message,data=None):
        self.status=int(status or 0);self.code=clean(code,160) or 'wp_http';self.message=clean(message,700) or f'WordPress HTTP {self.status}';self.data=data or {}
        super().__init__(f"{self.code}: {self.message} (HTTP {self.status})")

def wp_media_upload(image_bytes, filename, mime_type='image/jpeg'):
    cfg=read_integrations();site=(cfg.get('woo_url') or '').rstrip('/')
    key=cfg.get('woo_key') or '';secret=cfg.get('woo_secret') or ''
    if not site or not key or not secret:raise ValueError('Brak ustawień WooCommerce')
    auth=base64.b64encode(f'{key}:{secret}'.encode('utf-8')).decode('ascii')
    media_url=site + '/wp-json/wp/v2/media'
    body=image_bytes
    def _request(query_auth=False):
        q={}
        headers={'Content-Type':mime_type or 'image/jpeg','Accept':'application/json','User-Agent':'MB-Auto-Serwis-Magazyn/15.3.9','Content-Disposition':f'attachment; filename="{filename}"'}
        if query_auth:
            q['consumer_key']=key;q['consumer_secret']=secret
        else:
            headers['Authorization']='Basic '+auth
        url=media_url + (('?' + urllib.parse.urlencode(q)) if q else '')
        req=urllib.request.Request(url,data=body,method='POST',headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=60) as r:
                raw=r.read().decode('utf-8','replace')
                return json.loads(raw or '{}')
        except urllib.error.HTTPError as e:
            raw=''
            try:raw=e.read().decode('utf-8','replace')
            except Exception:pass
            try:obj=json.loads(raw) if raw else {}
            except Exception:obj={}
            raise WPAPIError(e.code,obj.get('code') or 'wp_http',obj.get('message') or raw or f'WordPress HTTP {e.code}',obj) from e
    try:
        return _request(False)
    except WPAPIError as e:
        auth_text=(str(e.code)+' '+str(e.message)).lower()
        auth_header_problem=('authentication' in auth_text or 'consumer' in auth_text or 'rest_not_logged_in' in auth_text or e.status in (401,403))
        if site.lower().startswith('https://') and auth_header_problem:
            return _request(True)
        raise

def woo_prepare_images(p, code, title):
    img=clean(p.get('preview_image') if isinstance(p, dict) else p['preview_image'],6_000_000)
    if not img:return ([], None)
    try:
        img_bytes,mime,ext=_decode_image_source(img)
        if not img_bytes:return ([], 'Nie udało się odczytać źródłowego zdjęcia produktu.')
        safe=(re.sub(r'[^A-Za-z0-9._-]+','_', code or 'produkt').strip('_') or 'produkt')
        uploaded=[];warnings=[]
        base=wp_media_upload(img_bytes, f'{safe}{ext or '.jpg'}', mime or 'image/jpeg')
        if inum(base.get('id')):uploaded.append({'id': inum(base.get('id'))})
        else:warnings.append('Nie udało się wysłać głównego zdjęcia do WordPress.')
        annotated=_annotate_image_bytes(img_bytes, code)
        if annotated:
            ann=wp_media_upload(annotated, f'{safe}_oznaczenie.jpg', 'image/jpeg')
            if inum(ann.get('id')):uploaded.append({'id': inum(ann.get('id'))})
            else:warnings.append('Nie udało się wysłać wersji zdjęcia z numerem części.')
        return (uploaded, '; '.join([w for w in warnings if w]) or None)
    except Exception as e:
        return ([], clean(e,500) or 'Nie udało się przygotować zdjęć do WooCommerce.')

def woo_product_payload(p,cfg,status_override=None):
    code=normalize_mb_part(p["oem_no"] or p["sku"] or p["barcode"] or "")
    name=clean(p["name"],300) or ("Mercedes-Benz "+code if code else "Część Mercedes-Benz")
    title=(f"{name} — {code}" if code and code not in name.upper().replace(" ","") else name)[:300]
    net=max(0,float(p["sell_price_net"] or p["sale_price"] or 0));vat=max(0,float(p["vat_rate"] or 23));gross=round(net*(1+vat/100),2)
    price=gross if cfg.get("woo_catalog_price_mode","gross")=="gross" else net
    payload={"name":title,"type":"simple","status":status_override if status_override in ("draft","pending","private","publish") else (cfg.get("woo_catalog_status","draft") if cfg.get("woo_catalog_status") in ("draft","pending","private","publish") else "draft"),"catalog_visibility":"visible","sku":code or clean(p["sku"],120),"regular_price":f"{price:.2f}","manage_stock":True,"stock_quantity":max(0,int(round(float(p["stock_qty"] or 0)))),"stock_status":"instock" if float(p["stock_qty"] or 0)>0 else "outofstock","backorders":"no","tax_status":"taxable","short_description":f"Oryginalna część Mercedes-Benz. Numer OE: {code}. {name}" if code else name,"description":f"<p>{name}</p><p><strong>Numer OE Mercedes-Benz:</strong> {code}</p><p>Produkt z oferty MB Auto Serwis. Przed zakupem zalecamy weryfikację dopasowania części do pojazdu.</p>" if code else f"<p>{name}</p><p>Produkt z oferty MB Auto Serwis.</p>","meta_data":[{"key":"_mbas_oem","value":code},{"key":"_mbas_source","value":"MB Auto Serwis CRM"}]}
    return payload

def next_warehouse_doc(c,doc_type,date):
    year=(date or datetime.now().strftime("%Y-%m-%d"))[:4]
    prefix=f"{doc_type}/{year}/"
    rows=c.execute("SELECT document_no FROM warehouse_documents WHERE document_no LIKE ?",(prefix+"%",)).fetchall()
    nums=[]
    for r in rows:
        tail=str(r["document_no"]).split("/")[-1]
        try:nums.append(int(re.sub(r"\D","",tail) or 0))
        except Exception:pass
    return f"{prefix}{(max(nums) if nums else 0)+1:05d}"

def create_warehouse_document(c,doc_type,date,external_no="",supplier_id=None,source="",notes=""):
    no=next_warehouse_doc(c,doc_type,date)
    cur=c.execute("""INSERT INTO warehouse_documents(document_no,doc_type,doc_date,external_no,supplier_id,source,notes,created_at)
                     VALUES(?,?,?,?,?,?,?,?)""",
                  (no,doc_type,date,clean(external_no,150),supplier_id,clean(source,120),clean(notes,2000),datetime.now().isoformat(timespec="seconds")))
    return cur.lastrowid,no

def next_doc(c,move_type,date):
    year=(date or datetime.now().strftime("%Y-%m-%d"))[:4]
    prefix=f"{move_type}/{year}/"
    rows=c.execute("SELECT document_no FROM movements WHERE document_no LIKE ?",(prefix+"%",)).fetchall()
    nums=[]
    for r in rows:
        try:nums.append(int(r["document_no"].split("/")[-1]))
        except Exception:pass
    return f"{prefix}{(max(nums) if nums else 0)+1:05d}"


def make_b2b_upload_xlsx(items):
    """Build an upload workbook compatible with the user-provided B2BConnectUpload template."""
    template=APP_DIR/"B2BConnectUpload.xlsx"
    if not template.exists():
        raise FileNotFoundError("Brak szablonu B2BConnectUpload.xlsx")
    with zipfile.ZipFile(template,"r") as zin:
        files={name:zin.read(name) for name in zin.namelist()}
    sheet_name="xl/worksheets/sheet1.xml"
    xml=files[sheet_name].decode("utf-8-sig")
    rows=['<row r="1"><c r="A1" s="1" t="s"><v>0</v></c><c r="B1" s="1" t="s"><v>1</v></c><c r="C1" s="1" t="s"><v>2</v></c><c r="D1" s="1" t="s"><v>3</v></c><c r="E1" s="1" t="s"><v>4</v></c><c r="F1" s="1" t="s"><v>5</v></c></row>']
    def inline_cell(ref,val):
        return f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{xml_escape(str(val or ""))}</t></is></c>'
    for i,item in enumerate(items,start=2):
        oem=normalize_mb_part(item.get("oem_no") or item.get("sku") or "")
        qty=max(1,int(round(fnum(item.get("quantity") or 1))))
        vin=clean(item.get("vin"),80)
        person=clean(item.get("person"),160)
        desc=clean(item.get("description") or item.get("name"),300)
        note=clean(item.get("note"),300)
        cells=[inline_cell(f"A{i}",oem),f'<c r="B{i}"><v>{qty}</v></c>',inline_cell(f"C{i}",vin),inline_cell(f"D{i}",person),inline_cell(f"E{i}",desc),inline_cell(f"F{i}",note)]
        rows.append(f'<row r="{i}">'+''.join(cells)+'</row>')
    xml=re.sub(r'<dimension ref="[^"]+"/>',f'<dimension ref="A1:F{max(1,len(items)+1)}"/>',xml,count=1)
    xml=re.sub(r'<sheetData>.*?</sheetData>','<sheetData>'+''.join(rows)+'</sheetData>',xml,count=1,flags=re.S)
    files[sheet_name]=xml.encode("utf-8")
    out=io.BytesIO()
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as zout:
        for name,data in files.items():zout.writestr(name,data)
    return out.getvalue()

class Handler(BaseHTTPRequestHandler):
    server_version="MBMagazyn/15.0-PREMIUM-FINAL"
    def log_message(self,fmt,*args):return
    def security_headers(self):
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("X-Frame-Options","DENY")
        self.send_header("Referrer-Policy","no-referrer")
        self.send_header("Permissions-Policy","camera=(), microphone=(), geolocation=()")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
    def send_json(self,obj,status=200,headers=None):
        if getattr(self,"_audit_id",None):
            audit_finish(self._audit_id,"OK" if status<400 else f"ERROR {status}",obj.get("error","") if isinstance(obj,dict) else "")
            self._audit_id=None
        b=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(status);self.security_headers()
        self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Length",str(len(b)))
        if headers:
            for k,v in headers.items():self.send_header(k,v)
        self.end_headers();self.wfile.write(b)
    def read_json(self):
        try:
            n=int(self.headers.get("Content-Length","0"))
            if n>10_000_000:return None
            return json.loads(self.rfile.read(n).decode() or "{}")
        except Exception:return None
    def auth(self,csrf=False,perm=None):
        sid,s=get_session(self.headers.get("Cookie"))
        if not s:self.send_json({"error":"unauthorized"},401);return None
        if csrf and not hmac.compare_digest(self.headers.get("X-CSRF-Token",""),s["csrf"]):
            self.send_json({"error":"csrf"},403);return None
        required=perm or (permission_for_request(urllib.parse.urlparse(self.path).path,self.command) if csrf else None)
        if required and not has_permission(s,required):
            self.send_json({"error":"forbidden","permission":required},403);return None
        if csrf and self.command in ("POST","PUT","DELETE") and not getattr(self,"_audit_id",None):
            self._audit_id=audit_start(s,self.command,urllib.parse.urlparse(self.path).path,required)
        return sid,s
    def send_bridge_json(self,obj,status=200):
        b=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(status)
        self.security_headers()
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type, X-MB-Bridge-Token")
        self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def valid_b2b_token(self):
        supplied=self.headers.get("X-MB-Bridge-Token","")
        expected=get_b2b_token()
        return bool(supplied) and hmac.compare_digest(supplied,expected)

    def do_OPTIONS(self):
        self.send_response(204)
        self.security_headers()
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type, X-MB-Bridge-Token")
        self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
        self.end_headers()

    def serve_static(self,name,ctype):
        p=STATIC_DIR/name
        if not p.exists() or not p.is_file():return self.send_error(404)
        b=p.read_bytes();self.send_response(200);self.security_headers();self.send_header("Cache-Control","no-store, no-cache, must-revalidate, max-age=0");self.send_header("Pragma","no-cache");self.send_header("Expires","0");self.send_header("Content-Type",ctype);self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)

    def do_GET(self):
        u=urllib.parse.urlparse(self.path);path=u.path
        if path=="/healthz":return self.send_json({"ok":True,"version":APP_VERSION})
        if path=="/":return self.serve_static("index.html","text/html; charset=utf-8")
        if path.startswith("/static/"):
            name=path[8:]
            if "/" in name or "\\" in name or ".." in name:return self.send_error(404)
            ct="text/plain; charset=utf-8"
            if name.endswith(".css"):ct="text/css; charset=utf-8"
            elif name.endswith(".js"):ct="application/javascript; charset=utf-8"
            return self.serve_static(name,ct)
        if path=="/api/app-version":
            return self.send_json({"ok":True,"app":"MB Auto Serwis - System Magazynowy","version":APP_VERSION,"ui_build":ui_build()})
        if path=="/api/ui-preferences":
            return self.send_json({"ok":True,"preferences":read_ui_preferences()})
        if path=="/api/session":
            sid,s=get_session(self.headers.get("Cookie"))
            return self.send_json({"logged_in":bool(s),"setup_required":setup_required(),"csrf":s["csrf"] if s else None,"user":({"id":s.get("user_id"),"username":s.get("username"),"display_name":s.get("display_name"),"role":s.get("role"),"permissions":s.get("permissions") or []} if s else None)})
        if path=="/api/b2b/bridge/ping":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            return self.send_bridge_json({"ok":True,"service":"MB B2B Bridge"})
        if path=="/api/b2b/availability/next":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            now=datetime.now();now_s=now.isoformat(timespec="seconds")
            stale=(now.timestamp()-75)
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                # Odzyskaj zlecenie, jeśli poprzednia karta B2B je porzuciła.
                working=c.execute("SELECT id,started_at FROM mb_availability_requests WHERE status='WORKING' ORDER BY id LIMIT 10").fetchall()
                for w in working:
                    try:
                        ts=datetime.fromisoformat(w["started_at"]).timestamp() if w["started_at"] else 0
                        if ts<stale:c.execute("UPDATE mb_availability_requests SET status='PENDING',started_at=NULL,error='Ponowienie po przerwanym sprawdzeniu' WHERE id=?",(w["id"],))
                    except Exception:pass
                # Tryb 13.0: B2B nie przegląda całej kartoteki samoczynnie.
                # Sprawdzamy tylko pozycje świadomie zlecone przez użytkownika
                # (przycisk „Sprawdź teraz”, import Parts Information lub „Pobierz dane Mercedes”).
                r=c.execute("SELECT * FROM mb_availability_requests WHERE status='PENDING' ORDER BY id ASC LIMIT 1").fetchone()
                if not r:
                    c.commit();return self.send_bridge_json({"ok":True,"request":None})
                c.execute("UPDATE mb_availability_requests SET status='WORKING',started_at=?,attempts=attempts+1,error=NULL WHERE id=?",(now_s,r["id"]))
                c.commit()
                prod=c.execute("SELECT id,name,oem_no,sku FROM products WHERE id=?",(r["product_id"],)).fetchone()
            try:codes=json.loads(r["codes_json"] or "[]")
            except Exception:codes=[]
            return self.send_bridge_json({"ok":True,"request":{"id":r["id"],"product_id":r["product_id"],"requested_oem":r["requested_oem"],"codes":codes,"product":dict(prod) if prod else None}})
        if path=="/api/b2b/enrich/next":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            now=datetime.now();now_s=now.isoformat(timespec="seconds");stale=now.timestamp()-90
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                # Ręczne wyszukiwanie z formularza „Nowa część” korzysta z tej samej
                # automatyki B2B, ale bez tworzenia produktu w bazie. Ujemny request_id
                # odróżnia takie zlecenie od zwykłego enrich produktu i działa również
                # ze starszym Bridge 15.0.8.
                for w in c.execute("SELECT id,started_at FROM b2b_manual_search_requests WHERE status='WORKING' LIMIT 20").fetchall():
                    try:
                        if (datetime.fromisoformat(w["started_at"]).timestamp() if w["started_at"] else 0)<stale:c.execute("UPDATE b2b_manual_search_requests SET status='PENDING',started_at=NULL WHERE id=?",(w["id"],))
                    except Exception:pass
                mr=c.execute("SELECT * FROM b2b_manual_search_requests WHERE status='PENDING' ORDER BY id ASC LIMIT 1").fetchone()
                if mr:
                    c.execute("UPDATE b2b_manual_search_requests SET status='WORKING',started_at=?,attempts=attempts+1,error=NULL WHERE id=?",(now_s,mr["id"]));c.commit()
                    return self.send_bridge_json({"ok":True,"request":{"id":-int(mr["id"]),"product_id":0,"requested_oem":mr["requested_oem"],"product":None,"manual_search":True}})
                for w in c.execute("SELECT id,started_at FROM b2b_enrich_requests WHERE status='WORKING' LIMIT 20").fetchall():
                    try:
                        if (datetime.fromisoformat(w["started_at"]).timestamp() if w["started_at"] else 0)<stale:c.execute("UPDATE b2b_enrich_requests SET status='PENDING',started_at=NULL WHERE id=?",(w["id"],))
                    except Exception:pass
                r=c.execute("SELECT * FROM b2b_enrich_requests WHERE status='PENDING' ORDER BY id ASC LIMIT 1").fetchone()
                if not r:c.commit();return self.send_bridge_json({"ok":True,"request":None})
                c.execute("UPDATE b2b_enrich_requests SET status='WORKING',started_at=?,attempts=attempts+1,error=NULL WHERE id=?",(now_s,r["id"]));c.commit()
                p=c.execute("SELECT id,name,oem_no,sku FROM products WHERE id=?",(r["product_id"],)).fetchone()
            return self.send_bridge_json({"ok":True,"request":{"id":r["id"],"product_id":r["product_id"],"requested_oem":r["requested_oem"],"product":dict(p) if p else None}})

        if path=="/api/tools/b2b/enrich/next":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            now=datetime.now();now_s=now.isoformat(timespec="seconds");stale=now.timestamp()-90
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                for w in c.execute("SELECT id,started_at FROM tool_b2b_requests WHERE status='WORKING' LIMIT 20").fetchall():
                    try:
                        if (datetime.fromisoformat(w["started_at"]).timestamp() if w["started_at"] else 0)<stale:
                            c.execute("UPDATE tool_b2b_requests SET status='PENDING',started_at=NULL,error='Ponowienie po przerwanym odczycie B2B' WHERE id=?",(w["id"],))
                    except Exception:pass
                r=c.execute("SELECT * FROM tool_b2b_requests WHERE status='PENDING' ORDER BY id ASC LIMIT 1").fetchone()
                if not r:c.commit();return self.send_bridge_json({"ok":True,"request":None})
                c.execute("UPDATE tool_b2b_requests SET status='WORKING',started_at=?,attempts=attempts+1,error=NULL WHERE id=?",(now_s,r["id"]));c.commit()
                t=c.execute("SELECT id,name,catalog_no,purchase_price_eur,image_data FROM tools WHERE id=?",(r["tool_id"],)).fetchone()
            return self.send_bridge_json({"ok":True,"request":{"id":r["id"],"tool_id":r["tool_id"],"requested_catalog_no":r["requested_catalog_no"],"tool":dict(t) if t else None}})

        if path=="/api/partsinfo/enrich/next":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            now=datetime.now();now_s=now.isoformat(timespec="seconds");stale=now.timestamp()-90
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                for w in c.execute("SELECT id,started_at FROM partsinfo_enrich_requests WHERE status='WORKING' LIMIT 20").fetchall():
                    try:
                        if (datetime.fromisoformat(w["started_at"]).timestamp() if w["started_at"] else 0)<stale:
                            c.execute("UPDATE partsinfo_enrich_requests SET status='PENDING',started_at=NULL,error='Ponowienie po przerwanym odczycie Parts Information' WHERE id=?",(w["id"],))
                    except Exception:pass
                r=c.execute("SELECT * FROM partsinfo_enrich_requests WHERE status='PENDING' ORDER BY id ASC LIMIT 1").fetchone()
                if not r:
                    c.commit();return self.send_bridge_json({"ok":True,"request":None})
                c.execute("UPDATE partsinfo_enrich_requests SET status='WORKING',started_at=?,attempts=attempts+1,error=NULL,warning=NULL WHERE id=?",(now_s,r["id"]))
                c.commit()
                p=c.execute("SELECT id,name,oem_no,sku FROM products WHERE id=?",(r["product_id"],)).fetchone()
            return self.send_bridge_json({"ok":True,"request":{"id":r["id"],"product_id":r["product_id"],"requested_oem":r["requested_oem"],"product":dict(p) if p else None}})

        if path=="/api/mercedes/portal-status":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            with db() as c:
                rows=c.execute("SELECT * FROM mercedes_portal_status ORDER BY source").fetchall()
            out=[]
            for r in rows:
                d=dict(r)
                try:d["capabilities"]=json.loads(d.pop("capabilities_json") or "{}")
                except Exception:d["capabilities"]={}
                out.append(d)
            return self.send_bridge_json({"ok":True,"portals":out})

        if path=="/api/b2b/cart/next":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            now=datetime.now();now_s=now.isoformat(timespec="seconds");stale=now.timestamp()-120
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                for w in c.execute("SELECT id,started_at FROM b2b_cart_requests WHERE status='WORKING' LIMIT 20").fetchall():
                    try:
                        if (datetime.fromisoformat(w["started_at"]).timestamp() if w["started_at"] else 0)<stale:c.execute("UPDATE b2b_cart_requests SET status='PENDING',started_at=NULL WHERE id=?",(w["id"],))
                    except Exception:pass
                r=c.execute("SELECT * FROM b2b_cart_requests WHERE status='PENDING' ORDER BY id ASC LIMIT 1").fetchone()
                if not r:c.commit();return self.send_bridge_json({"ok":True,"request":None})
                c.execute("UPDATE b2b_cart_requests SET status='WORKING',started_at=?,attempts=attempts+1,message=NULL WHERE id=?",(now_s,r["id"]));c.commit()
                p=c.execute("SELECT id,name,oem_no,sku FROM products WHERE id=?",(r["product_id"],)).fetchone()
            return self.send_bridge_json({"ok":True,"request":{"id":r["id"],"cart_id":r["cart_id"],"cart_item_id":r["cart_item_id"],"product_id":r["product_id"],"requested_oem":r["requested_oem"],"quantity":r["quantity"],"product":dict(p) if p else None}})

        a=self.auth()
        if not a:return
        sid,session=a

        if path=="/api/b2b/manual-search/status":
            q=urllib.parse.parse_qs(u.query);rid=inum(q.get("id",[0])[0])
            if rid<=0:return self.send_json({"error":"bad_id"},400)
            with db() as c:r=c.execute("SELECT * FROM b2b_manual_search_requests WHERE id=?",(rid,)).fetchone()
            if not r:return self.send_json({"error":"not_found"},404)
            d=dict(r)
            try:d["item"]=json.loads(d.pop("result_json") or "{}")
            except Exception:d["item"]={}
            return self.send_json({"ok":True,"request":d})

        if path=="/api/users":
            if not has_permission(session,"users_admin"):return self.send_json({"error":"forbidden"},403)
            with db() as c:rows=c.execute("SELECT id,username,display_name,role,permissions_json,active,must_change_password,last_login,created_at,updated_at FROM users ORDER BY role='ADMIN' DESC,display_name,username").fetchall()
            out=[]
            for r in rows:
                d=dict(r)
                try:d["permissions"]=json.loads(d.pop("permissions_json") or "[]")
                except Exception:d["permissions"]=[]
                out.append(d)
            return self.send_json({"users":out,"available_permissions":[
                ["products_edit","Edycja kartoteki części"],["stock_edit","Ruchy magazynowe PZ/RW/WZ"],["documents_edit","Edycja dokumentów"],
                ["substitutes_edit","Edycja zamienników"],["tools_edit","Edycja narzędzi"],["suppliers_edit","Edycja dostawców"],
                ["locations_edit","Edycja lokalizacji"],["contractors_edit","Edycja kontrahentów"],["b2b_import","Import/eksport Mercedes"],
                ["integrations_edit","Ustawienia integracji"],["data_admin","Operacje na bazie danych"],["users_admin","Użytkownicy i uprawnienia"]
            ]})

        if path=="/api/audit":
            if not has_permission(session,"users_admin"):return self.send_json({"error":"forbidden"},403)
            with db() as c:rows=c.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 300").fetchall()
            return self.send_json({"events":[dict(r) for r in rows]})

        if path=="/api/b2b/export-history":
            with db() as c:rows=c.execute("SELECT * FROM b2b_export_history ORDER BY id DESC LIMIT 100").fetchall()
            return self.send_json({"exports":[dict(r) for r in rows],"folder":str(B2B_EXPORT_DIR)})

        if path=="/api/nbp/eur-rate":
            q=urllib.parse.parse_qs(u.query);date=clean(q.get("date",[""])[0],10)
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}",date):return self.send_json({"error":"bad_date"},400)
            try:r=nbp_eur_rate_for_date(date)
            except Exception as e:return self.send_json({"error":"nbp_unavailable","message":clean(e,300)},502)
            return self.send_json({"ok":True,"requested_date":date,**r})

        if path=="/api/tools/report":
            q=urllib.parse.parse_qs(u.query);year=clean(q.get("year",[""])[0],4);month=clean(q.get("month",[""])[0],2).zfill(2) if q.get("month",[""])[0] else ""
            where="t.active=1";args=[]
            if year and re.fullmatch(r"\d{4}",year):where+=" AND substr(t.purchase_date,1,4)=?";args.append(year)
            if month and re.fullmatch(r"\d{2}",month):where+=" AND substr(t.purchase_date,6,2)=?";args.append(month)
            with db() as c:
                rows=c.execute(f"""SELECT t.id,t.name,t.category,t.manufacturer,t.model,t.catalog_no,t.quantity,t.purchase_price_pln,t.purchase_price_eur,t.eur_rate,t.invoice_no,t.purchase_date,
                                  s.name supplier_name,l.code location_code,(COALESCE(t.quantity,1)*COALESCE(t.purchase_price_pln,0)) total_value
                                  FROM tools t LEFT JOIN suppliers s ON s.id=t.supplier_id LEFT JOIN locations l ON l.id=t.location_id
                                  WHERE {where} ORDER BY total_value DESC,t.name COLLATE NOCASE""",args).fetchall()
                items=[dict(r) for r in rows]
                for x in items:
                    qty=max(0,fnum(x.get("quantity"))) or 1
                    x["total_value_pln"]=round(qty*fnum(x.get("purchase_price_pln")),2)
                    x["total_value_eur"]=round(qty*fnum(x.get("purchase_price_eur")),2)
                    x["total_value"]=x["total_value_pln"]
                total=sum(fnum(x.get("total_value_pln")) for x in items)
                total_eur=sum(fnum(x.get("total_value_eur")) for x in items)
                quantity_total=sum((max(0,fnum(x.get("quantity"))) or 1) for x in items)
                def grouped(field):
                    d={}
                    for x in items:
                        k=clean(x.get(field),120) or "Brak danych";d[k]=d.get(k,0)+fnum(x.get("total_value"))
                    return [{"name":k,"value":round(v,2)} for k,v in sorted(d.items(),key=lambda kv:(-kv[1],kv[0]))]
                months={}
                for x in items:
                    k=(clean(x.get("purchase_date"),10)[:7] or "Bez daty");months[k]=months.get(k,0)+fnum(x.get("total_value"))
                monthly=[{"month":k,"value":round(v,2)} for k,v in sorted(months.items(),reverse=True)]
            return self.send_json({"ok":True,"total":round(total,2),"total_pln":round(total,2),"total_eur":round(total_eur,2),"quantity_total":round(quantity_total,2),"count":len(items),"items":items,"by_category":grouped("category"),"by_manufacturer":grouped("manufacturer"),"by_supplier":grouped("supplier_name"),"monthly":monthly})

        if path=="/api/tools":
            q=urllib.parse.parse_qs(u.query);search=clean(q.get("q",[""])[0],200);sort_key=clean(q.get("sort",["name"])[0],20);sort_dir=clean(q.get("dir",["asc"])[0],8).lower()
            sql="""SELECT t.*,l.code location_code,l.name location_name,s.name supplier_name FROM tools t
                   LEFT JOIN locations l ON l.id=t.location_id LEFT JOIN suppliers s ON s.id=t.supplier_id WHERE t.active=1""";args=[]
            if search:
                pat=f"%{search}%";sql+=" AND (t.name LIKE ? OR t.category LIKE ? OR t.manufacturer LIKE ? OR t.model LIKE ? OR t.catalog_no LIKE ? OR t.serial_no LIKE ? OR t.invoice_no LIKE ? OR l.code LIKE ?)";args=[pat]*8
            sm={"name":"t.name COLLATE NOCASE","category":"t.category COLLATE NOCASE","location":"l.code COLLATE NOCASE","price":"t.purchase_price_pln","date":"t.purchase_date","created":"t.created_at"}
            sql+=f" ORDER BY {sm.get(sort_key,sm['name'])} {'DESC' if sort_dir=='desc' else 'ASC'},t.id ASC"
            with db() as c:rows=c.execute(sql,args).fetchall()
            return self.send_json({"tools":[dict(r) for r in rows]})

        if path=="/api/pricing/settings":
            with db() as c:settings=get_pricing_settings(c)
            return self.send_json({"ok":True,"settings":settings})

        if path=="/api/quick-catalog":
            with db() as c:
                rows=quick_catalog_rows(c)
                portals=[]
                now=datetime.now()
                for r in c.execute("SELECT * FROM mercedes_portal_status ORDER BY source").fetchall():
                    d=dict(r);online=False
                    try: online=(now-datetime.fromisoformat(d.get("last_seen") or "1970-01-01")).total_seconds()<120
                    except Exception: pass
                    d["online"]=online;portals.append(d)
                # Bridge 15.0.8 wysyła dla B2B starszy heartbeat do b2b_runtime_status.
                # Dodajemy go do wspólnej listy portali, dzięki czemu „Pobierz dane Mercedes”
                # rozpoznaje już otwartą kartę i NIE uruchamia kolejnej zakładki Chrome.
                if not any(str(x.get("source") or "").upper() in {"B2B","XENTRY"} and x.get("online") for x in portals):
                    rt=c.execute("SELECT * FROM b2b_runtime_status WHERE id=1").fetchone()
                    if rt:
                        d=dict(rt);online=False
                        try: online=(now-datetime.fromisoformat(d.get("last_seen") or "1970-01-01")).total_seconds()<120
                        except Exception: pass
                        if online:
                            d["source"]="B2B";d["online"]=True;d["capabilities_json"]='{}';portals.append(d)
                locs=[dict(x) for x in c.execute("SELECT id,code,name FROM locations WHERE active=1 ORDER BY code,name").fetchall()]
            counts={k:0 for k in ("READY","VERIFY","WORKING","QUEUED","PARTIAL","NEW")}
            for x in rows:counts[x.get("state")]=counts.get(x.get("state"),0)+1
            return self.send_json({"entries":rows,"counts":counts,"portals":portals,"locations":locs})

        if path=="/api/products":
            q=urllib.parse.parse_qs(u.query);search=clean(q.get("q",[""])[0],200);low=clean(q.get("low",[""])[0],10);active=clean(q.get("active",["1"])[0],10);sort_key=clean(q.get("sort",["name"])[0],20);sort_dir=clean(q.get("dir",["asc"])[0],8).lower()
            sql="""SELECT p.*,s.name supplier_name,l.code location_code,l.name location_name,
                   (SELECT GROUP_CONCAT(a.alias_no, ', ') FROM product_aliases a WHERE a.product_id=p.id) aliases,
                   (SELECT mr.related_oem FROM mercedes_part_relations mr WHERE mr.product_id=p.id AND mr.relation_type='REPLACED_BY' ORDER BY mr.id DESC LIMIT 1) latest_oem,
                   av.status_code mb_status_code,av.dealer_name mb_dealer_name,av.checked_at mb_checked_at,av.checked_oem mb_checked_oem,av.error mb_availability_error,
                   (SELECT r.status FROM mb_availability_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) mb_request_status,
                   (SELECT r.status FROM partsinfo_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) pi_request_status,
                   (SELECT r.error FROM partsinfo_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) pi_request_error,
                   (SELECT r.status FROM b2b_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) b2b_request_status,
                   (SELECT r.error FROM b2b_enrich_requests r WHERE r.product_id=p.id ORDER BY r.id DESC LIMIT 1) b2b_request_error
                   FROM products p LEFT JOIN suppliers s ON s.id=p.supplier_id
                   LEFT JOIN locations l ON l.id=p.location_id LEFT JOIN mb_availability_cache av ON av.product_id=p.id WHERE 1=1"""
            args=[]
            if active=="1":sql+=" AND p.active=1"
            elif active=="0":sql+=" AND p.active=0"
            if search:
                pat=f"%{search}%";nq=normalize_lookup_code(search);npat=f"%{nq}%"
                normexpr=lambda field:f"REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPPER(COALESCE({field},'')),' ',''),'-',''),'.',''),'_',''),'/','')"
                sql+=f""" AND (
                    p.name LIKE ? OR p.category LIKE ? OR
                    {normexpr('p.sku')} LIKE ? OR {normexpr('p.oem_no')} LIKE ? OR {normexpr('p.barcode')} LIKE ? OR
                    EXISTS(SELECT 1 FROM product_aliases ax WHERE ax.product_id=p.id AND {normexpr('ax.alias_no')} LIKE ?) OR
                    EXISTS(SELECT 1 FROM mercedes_part_relations mr WHERE mr.product_id=p.id AND {normexpr('mr.related_oem')} LIKE ?)
                )"""
                args += [pat,pat,npat,npat,npat,npat,npat]
            if low=="1":sql+=" AND p.min_qty>0 AND p.stock_qty<p.min_qty"
            sort_map={
                "name":"p.name COLLATE NOCASE",
                "oem":"p.oem_no COLLATE NOCASE",
                "sku":"p.sku COLLATE NOCASE",
                "stock":"p.stock_qty",
                "location":"l.code COLLATE NOCASE",
                "purchase":"p.purchase_price",
                "purchase_gross":"p.purchase_price*(1+COALESCE(p.vat_rate,23)/100.0)",
                "catalog":"p.sale_price",
                "catalog_gross":"p.sale_price*(1+COALESCE(p.vat_rate,23)/100.0)",
                "sell":"p.sell_price_net",
                "sell_gross":"p.sell_price_net*(1+COALESCE(p.vat_rate,23)/100.0)",
                "supplier":"s.name COLLATE NOCASE",
                "created":"p.created_at"
            }
            order_expr=sort_map.get(sort_key,sort_map["name"]);direction="DESC" if sort_dir=="desc" else "ASC"
            sql+=f" ORDER BY {order_expr} {direction}, p.name COLLATE NOCASE ASC, p.id ASC"
            with db() as c:rows=c.execute(sql,args).fetchall()
            return self.send_json({"products":[dict(r) for r in rows]})

        if path.startswith("/api/product/") and path.endswith("/detail"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                p=c.execute("""SELECT p.*,s.name supplier_name,l.code location_code,l.name location_name
                               FROM products p LEFT JOIN suppliers s ON s.id=p.supplier_id LEFT JOIN locations l ON l.id=p.location_id WHERE p.id=?""",(pid,)).fetchone()
                if not p:return self.send_json({"error":"not_found"},404)
                aliases=c.execute("SELECT * FROM product_aliases WHERE product_id=? ORDER BY id",(pid,)).fetchall()
                mb_relations=c.execute("SELECT * FROM mercedes_part_relations WHERE product_id=? ORDER BY relation_type,related_oem",(pid,)).fetchall()
                moves=c.execute("""SELECT m.*,wd.document_no parent_document_no,wd.external_no,wd.source document_source,s.name supplier_name
                                   FROM movements m LEFT JOIN warehouse_documents wd ON wd.id=m.document_id LEFT JOIN suppliers s ON s.id=m.supplier_id
                                   WHERE m.product_id=? ORDER BY m.move_date DESC,m.id DESC LIMIT 250""",(pid,)).fetchall()
                docs=c.execute("""SELECT DISTINCT wd.*,s.name supplier_name,(SELECT SUM(ABS(mm.quantity*mm.unit_price)) FROM movements mm WHERE mm.document_id=wd.id) value
                                  FROM warehouse_documents wd JOIN movements m ON m.document_id=wd.id LEFT JOIN suppliers s ON s.id=wd.supplier_id
                                  WHERE m.product_id=? ORDER BY wd.doc_date DESC,wd.id DESC LIMIT 100""",(pid,)).fetchall()
                g=c.execute("SELECT group_id FROM product_substitute_group WHERE product_id=?",(pid,)).fetchone();local=[];external=[]
                if g:
                    local=c.execute("""SELECT p.*,l.code location_code FROM product_substitute_group pg JOIN products p ON p.id=pg.product_id LEFT JOIN locations l ON l.id=p.location_id WHERE pg.group_id=? AND p.id<>? ORDER BY p.active DESC,p.name""",(g["group_id"],pid)).fetchall()
                    external=c.execute("SELECT * FROM external_substitutes WHERE group_id=? ORDER BY source,brand,name",(g["group_id"],)).fetchall()
                av=c.execute("SELECT * FROM mb_availability_cache WHERE product_id=?",(pid,)).fetchone()
                iclink=c.execute("SELECT * FROM intercars_product_links WHERE product_id=?",(pid,)).fetchone()
                icmatches=c.execute("SELECT * FROM intercars_oe_links WHERE product_id=? ORDER BY brand,name,id",(pid,)).fetchall()
                req=c.execute("SELECT id,status,requested_at,started_at,error FROM mb_availability_requests WHERE product_id=? AND status IN ('PENDING','WORKING') ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
                rt=c.execute("SELECT * FROM b2b_runtime_status WHERE id=1").fetchone()
                hotspot_rows=[]
                fp=clean(p["diagram_fingerprint"],80) if "diagram_fingerprint" in p.keys() else ""
                if fp:
                    # Najpierw hotspoty katalogowe Parts Information — mogą istnieć nawet dla części,
                    # których nie mamy jeszcze w magazynie.
                    for h in c.execute("""SELECT * FROM mercedes_diagram_hotspots WHERE diagram_fingerprint=? AND marker_x IS NOT NULL AND marker_y IS NOT NULL
                                          ORDER BY CAST(position AS INTEGER),position,oem_no""",(fp,)).fetchall():
                        hd=dict(h);match=find_product_by_any_code(c,hd.get("oem_no") or "")
                        hd["id"]=match["id"] if match else None
                        hd["product_id"]=match["id"] if match else None
                        hd["sku"]=match["sku"] if match else ""
                        hd["stock_qty"]=match["stock_qty"] if match else 0
                        hd["unit"]=match["unit"] if match else "szt."
                        hd["mb_status_code"]=(c.execute("SELECT status_code FROM mb_availability_cache WHERE product_id=?",(match["id"],)).fetchone() or {"status_code":"UNKNOWN"})["status_code"] if match else "UNKNOWN"
                        hd["diagram_position"]=hd.pop("position")
                        hd["diagram_marker_x"]=hd.pop("marker_x")
                        hd["diagram_marker_y"]=hd.pop("marker_y")
                        if not hd.get("name") and match:hd["name"]=match["name"]
                        hotspot_rows.append(hd)
                    # Uzupełnij starszymi markerami z kartotek, jeśli katalog nie zwrócił pozycji.
                    known={(str(x.get("diagram_position")),normalize_mb_part(x.get("oem_no"))) for x in hotspot_rows}
                    oldhs=c.execute("""SELECT p.id,p.oem_no,p.sku,p.name,p.diagram_position,p.diagram_marker_x,p.diagram_marker_y,p.stock_qty,p.unit,av.status_code mb_status_code
                                      FROM products p LEFT JOIN mb_availability_cache av ON av.product_id=p.id
                                      WHERE p.diagram_fingerprint=? AND p.diagram_marker_x IS NOT NULL AND p.diagram_marker_y IS NOT NULL
                                      ORDER BY CAST(p.diagram_position AS INTEGER),p.name""",(fp,)).fetchall()
                    for oh in oldhs:
                        d=dict(oh);k=(str(d.get("diagram_position")),normalize_mb_part(d.get("oem_no")))
                        if k not in known:hotspot_rows.append(d)
                pi_req=c.execute("SELECT id,status,requested_at,started_at,finished_at,error,warning FROM partsinfo_enrich_requests WHERE product_id=? ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
                portals=c.execute("SELECT * FROM mercedes_portal_status ORDER BY source").fetchall()
                latest_oem=""
                current_oem=normalize_mb_part(p["oem_no"] or p["sku"] or "")
                # Idź po jawnych relacjach REPLACED_BY, maksymalnie 20 kroków (ochrona przed pętlą).
                cursor=current_oem;seen_latest=set()
                for _ in range(20):
                    if not cursor or cursor in seen_latest:break
                    seen_latest.add(cursor)
                    rr=c.execute("SELECT related_oem FROM mercedes_part_relations WHERE product_id=? AND relation_type='REPLACED_BY' ORDER BY id DESC LIMIT 1",(pid,)).fetchone() if cursor==current_oem else None
                    if not rr:break
                    nxt=normalize_mb_part(rr["related_oem"])
                    if not nxt or nxt==cursor:break
                    latest_oem=nxt;cursor=nxt
                    # Jeśli nowszy numer ma własną kartotekę, kontynuuj łańcuch z niej.
                    np=find_product_by_any_code(c,nxt)
                    if not np:break
                    pid2=int(np["id"])
                    rr2=c.execute("SELECT related_oem FROM mercedes_part_relations WHERE product_id=? AND relation_type='REPLACED_BY' ORDER BY id DESC LIMIT 1",(pid2,)).fetchone()
                    if not rr2:break
                    nxt2=normalize_mb_part(rr2["related_oem"])
                    if not nxt2 or nxt2 in seen_latest:break
                    latest_oem=nxt2;cursor=nxt2
                    # kolejna iteracja nie może użyć pid, więc kończymy po znalezieniu kolejnego jawnego kroku
                    break
            avd=dict(av) if av else None
            if avd:
                try:avd["details"]=json.loads(avd.pop("details_json") or "{}")
                except Exception:avd["details"]={}
                avd["raw_label"]=clean_mb_availability_label(avd.get("status_code"),avd.get("raw_label"))
            portal_out={}
            for row in portals:
                d=dict(row)
                try:d["capabilities"]=json.loads(d.pop("capabilities_json") or "{}")
                except Exception:d["capabilities"]={}
                portal_out[d["source"]]=d
            icd=dict(iclink) if iclink else None
            if icd:
                for key in ("eans_json","stock_json","raw_json"):
                    try:icd[key[:-5] if key.endswith("_json") else key]=json.loads(icd.pop(key) or ("[]" if key!="raw_json" else "{}"))
                    except Exception:icd[key[:-5] if key.endswith("_json") else key]=[] if key!="raw_json" else {}
            icmatch_out=[]
            for row in icmatches:
                d=dict(row)
                try:d["eans"]=json.loads(d.pop("eans_json") or "[]")
                except Exception:d["eans"]=[]
                icmatch_out.append(d)
            with db() as c:
                av_req=c.execute("SELECT id,status,requested_at,started_at,finished_at,error FROM mb_availability_requests WHERE product_id=? ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
                b2b_req=c.execute("SELECT id,status,requested_at,started_at,finished_at,error FROM b2b_enrich_requests WHERE product_id=? ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
            return self.send_json({"product":dict(p),"aliases":[dict(x) for x in aliases],"mercedes_relations":[dict(x) for x in mb_relations],"latest_oem":latest_oem,"movements":[dict(x) for x in moves],"documents":[dict(x) for x in docs],"alternatives":[dict(x) for x in local],"external_alternatives":[dict(x) for x in external],"availability":avd,"availability_request":dict(av_req) if av_req else None,"bridge_status":dict(rt) if rt else None,"partsinfo_request":dict(pi_req) if pi_req else None,"b2b_request":dict(b2b_req) if b2b_req else None,"portal_status":portal_out,"diagram_hotspots":hotspot_rows,"intercars":icd,"intercars_matches":icmatch_out})

        if path=="/api/cart":
            with db() as c:
                cart=get_open_cart(c)
                rows=c.execute("""SELECT ci.*,p.oem_no,p.sku,p.name,p.stock_qty,p.unit,p.purchase_price,p.sale_price,
                                 av.status_code mb_status_code,av.checked_at mb_checked_at,
                                 (SELECT r.status FROM b2b_cart_requests r WHERE r.cart_item_id=ci.id ORDER BY r.id DESC LIMIT 1) b2b_status,
                                 (SELECT r.message FROM b2b_cart_requests r WHERE r.cart_item_id=ci.id ORDER BY r.id DESC LIMIT 1) b2b_message,
                                 (SELECT r.final_oem FROM b2b_cart_requests r WHERE r.cart_item_id=ci.id ORDER BY r.id DESC LIMIT 1) b2b_final_oem
                                 FROM purchase_cart_items ci JOIN products p ON p.id=ci.product_id
                                 LEFT JOIN mb_availability_cache av ON av.product_id=p.id WHERE ci.cart_id=? ORDER BY ci.id""",(cart["id"],)).fetchall()
            return self.send_json({"cart":dict(cart),"items":[dict(x) for x in rows]})

        if path=="/api/documents":
            q=urllib.parse.parse_qs(u.query);typ=clean(q.get("type",[""])[0],20);search=clean(q.get("q",[""])[0],200)
            sql="""SELECT wd.*,s.name supplier_name,COUNT(m.id) lines,COALESCE(SUM(ABS(m.quantity*m.unit_price)),0) value
                   FROM warehouse_documents wd LEFT JOIN suppliers s ON s.id=wd.supplier_id LEFT JOIN movements m ON m.document_id=wd.id WHERE 1=1""";args=[]
            if typ:sql+=" AND wd.doc_type=?";args.append(typ)
            if search:
                pat="%"+search+"%";sql+=" AND (wd.document_no LIKE ? OR wd.external_no LIKE ? OR s.name LIKE ? OR wd.source LIKE ?)";args += [pat]*4
            sql+=" GROUP BY wd.id ORDER BY wd.doc_date DESC,wd.id DESC LIMIT 1500"
            with db() as c:rows=c.execute(sql,args).fetchall()
            return self.send_json({"documents":[dict(r) for r in rows]})

        if path.startswith("/api/document/"):
            try:did=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                doc=c.execute("""SELECT wd.*,s.name supplier_name,s.nip supplier_nip,s.email supplier_email,s.phone supplier_phone FROM warehouse_documents wd LEFT JOIN suppliers s ON s.id=wd.supplier_id WHERE wd.id=?""",(did,)).fetchone()
                if not doc:return self.send_json({"error":"not_found"},404)
                lines=c.execute("""SELECT m.*,p.sku,p.oem_no,p.name product_name,p.unit FROM movements m JOIN products p ON p.id=m.product_id WHERE m.document_id=? ORDER BY m.id""",(did,)).fetchall()
            return self.send_json({"document":dict(doc),"lines":[dict(x) for x in lines]})

        if path=="/api/movements":
            q=urllib.parse.parse_qs(u.query);search=clean(q.get("q",[""])[0],200);typ=clean(q.get("type",[""])[0],20)
            sql="""SELECT m.*,p.sku,p.oem_no,p.name product_name,s.name supplier_name
                   FROM movements m JOIN products p ON p.id=m.product_id
                   LEFT JOIN suppliers s ON s.id=m.supplier_id WHERE 1=1"""
            args=[]
            if search:
                pat=f"%{search}%";sql+=" AND (m.document_no LIKE ? OR m.reference_no LIKE ? OR m.motowarsztat_order_no LIKE ? OR m.shop_order_no LIKE ? OR p.sku LIKE ? OR p.oem_no LIKE ? OR p.name LIKE ?)";args += [pat]*7
            if typ:sql+=" AND m.move_type=?";args.append(typ)
            sql+=" ORDER BY m.move_date DESC,m.id DESC LIMIT 3000"
            with db() as c:rows=c.execute(sql,args).fetchall()
            return self.send_json({"movements":[dict(r) for r in rows]})

        if path=="/api/suppliers":
            with db() as c:rows=c.execute("SELECT * FROM suppliers WHERE active=1 ORDER BY name").fetchall()
            return self.send_json({"suppliers":[dict(r) for r in rows]})

        if path=="/api/locations":
            with db() as c:
                rows=c.execute("""SELECT l.*,
                    (SELECT COUNT(DISTINCT pl.product_id) FROM product_locations pl JOIN products p ON p.id=pl.product_id WHERE pl.location_id=l.id AND p.active=1) occupied
                    FROM locations l WHERE l.active=1 ORDER BY l.code""").fetchall()
                out=[]
                for r in rows:
                    d=dict(r); contents=c.execute("""SELECT p.id,p.oem_no,p.sku,p.name,p.stock_qty,p.unit FROM product_locations pl
                          JOIN products p ON p.id=pl.product_id WHERE pl.location_id=? AND p.active=1 ORDER BY p.name COLLATE NOCASE LIMIT 50""",(r["id"],)).fetchall()
                    d["contents"]=[dict(x) for x in contents];out.append(d)
            return self.send_json({"locations":out})

        if path=="/api/contractors":
            with db() as c:rows=c.execute("SELECT * FROM contractors ORDER BY name").fetchall()
            return self.send_json({"contractors":[dict(r) for r in rows]})

        if path=="/api/scan":
            q=urllib.parse.parse_qs(u.query);raw=clean(q.get("code",[""])[0],500)
            code=extract_scan_code(raw)
            with db() as c:
                row=find_product_by_any_code(c,code)
                if row:
                    d=dict(row)
                    loc=c.execute("SELECT code,name FROM locations WHERE id=?",(d.get("location_id"),)).fetchone() if d.get("location_id") else None
                    d["location_code"]=loc["code"] if loc else ""
                    return self.send_json({"found":True,"code":code,"product":d})
            return self.send_json({"found":False,"code":code,"suggested_oem":normalize_mb_part(code) if re.match(r"^[A-Z]\d{10,12}$",normalize_mb_part(code)) else ""})

        if path.startswith("/api/product/") and path.endswith("/availability"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                av=c.execute("SELECT * FROM mb_availability_cache WHERE product_id=?",(pid,)).fetchone()
                req=c.execute("SELECT id,status,requested_at,started_at,finished_at,error FROM mb_availability_requests WHERE product_id=? ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
                rt=c.execute("SELECT * FROM b2b_runtime_status WHERE id=1").fetchone()
            avd=dict(av) if av else None
            if avd:
                try:avd["details"]=json.loads(avd.pop("details_json") or "{}")
                except Exception:avd["details"]={}
                avd["raw_label"]=clean_mb_availability_label(avd.get("status_code"),avd.get("raw_label"))
            return self.send_json({"availability":avd,"request":dict(req) if req else None,"bridge_status":dict(rt) if rt else None})

        if path.startswith("/api/product/") and path.endswith("/size-profile"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                p=c.execute("SELECT id,name,category,size_class_override FROM products WHERE id=?",(pid,)).fetchone()
                if not p:return self.send_json({"error":"not_found"},404)
                profile=infer_part_size_profile(p["name"],p["category"],p["size_class_override"])
                profile["override"]=clean(p["size_class_override"],10).upper()
            return self.send_json({"ok":True,"profile":profile})

        if path=="/api/summary":
            with db() as c:
                k=c.execute("""SELECT COUNT(*) products_count,
                    COALESCE(SUM(stock_qty),0) qty_total,
                    COALESCE(SUM(stock_qty*purchase_price),0) purchase_value,
                    COALESCE(SUM(stock_qty*sale_price),0) sale_value,
                    SUM(CASE WHEN min_qty>0 AND stock_qty<min_qty THEN 1 ELSE 0 END) low_count
                    FROM products WHERE active=1""").fetchone()
                recent=c.execute("""SELECT m.move_type,COUNT(*) cnt,COALESCE(SUM(ABS(m.quantity*m.unit_price)),0) value
                    FROM movements m WHERE substr(m.move_date,1,7)=strftime('%Y-%m','now','localtime')
                    GROUP BY m.move_type ORDER BY m.move_type""").fetchall()
                top=c.execute("""SELECT p.id,p.sku,p.oem_no,p.name,p.stock_qty,p.min_qty,l.code location_code
                    FROM products p LEFT JOIN locations l ON l.id=p.location_id
                    WHERE p.active=1 AND p.min_qty>0 AND p.stock_qty<p.min_qty
                    ORDER BY (p.min_qty-p.stock_qty) DESC,p.name LIMIT 12""").fetchall()
            return self.send_json({"kpi":dict(k),"month":[dict(r) for r in recent],"low":[dict(r) for r in top]})

        if path=="/api/integrations/settings":
            cfg=read_integrations()
            with db() as c:
                logs=c.execute("SELECT * FROM integration_log ORDER BY id DESC LIMIT 12").fetchall()
            return self.send_json({"woo_url":cfg["woo_url"],"has_woo_key":bool(cfg["woo_key"] and cfg["woo_secret"]),"woo_auto_enabled":cfg.get("woo_auto_enabled",False),"woo_auto_minutes":cfg.get("woo_auto_minutes",10),"woo_catalog_beta_enabled":cfg.get("woo_catalog_beta_enabled",False),"woo_catalog_status":cfg.get("woo_catalog_status","draft"),"woo_catalog_price_mode":cfg.get("woo_catalog_price_mode","gross"),"woo_orders_sync_cursor":cfg.get("woo_orders_sync_cursor",""),"ic_base_url":cfg["ic_base_url"],"ic_token_url":cfg["ic_token_url"],"ic_location":cfg.get("ic_location",""),"ic_ship_to":cfg.get("ic_ship_to",""),"has_ic_key":bool(cfg["ic_client_id"] and cfg["ic_client_secret"]),"has_local_sales_db":SALES_DB_PATH.exists(),"logs":[dict(x) for x in logs]})

        if path=="/api/integrations/issues":
            with db() as c:rows=c.execute("SELECT * FROM integration_issues WHERE status='OPEN' ORDER BY id DESC LIMIT 500").fetchall()
            return self.send_json({"issues":[dict(x) for x in rows]})

        if path.startswith("/api/product/") and path.endswith("/alternatives"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                g=c.execute("SELECT group_id FROM product_substitute_group WHERE product_id=?",(pid,)).fetchone()
                if not g:return self.send_json({"group_id":None,"local":[],"external":[]})
                local=c.execute("""SELECT p.*,l.code location_code FROM product_substitute_group pg JOIN products p ON p.id=pg.product_id LEFT JOIN locations l ON l.id=p.location_id WHERE pg.group_id=? AND p.id<>? AND p.active=1 ORDER BY p.name""",(g["group_id"],pid)).fetchall()
                ext=c.execute("SELECT * FROM external_substitutes WHERE group_id=? ORDER BY source,brand,name",(g["group_id"],)).fetchall()
            return self.send_json({"group_id":g["group_id"],"local":[dict(x) for x in local],"external":[dict(x) for x in ext]})

        if path=="/api/intercars/search":
            q=urllib.parse.parse_qs(u.query);query=clean(q.get("q",[""])[0],160);mode=clean(q.get("mode",["auto"])[0],20);product_id=inum(q.get("product_id",["0"])[0])
            if not query and mode!="oe":return self.send_json({"error":"query_required"},400)
            try:
                with db() as c:
                    if mode=="oe":
                        pid=product_id
                        if not pid and query:
                            p=find_product_by_any_code(c,query);pid=p["id"] if p else 0
                        rows=c.execute("SELECT * FROM intercars_oe_links WHERE product_id=? ORDER BY brand,name",(pid,)).fetchall() if pid else []
                        items=[]
                        for r in rows:
                            d=dict(r)
                            try:eans=json.loads(d.get("eans_json") or "[]")
                            except Exception:eans=[]
                            items.append({"sku":d.get("ic_sku"),"index":d.get("ic_index"),"brand":d.get("brand"),"name":d.get("name"),"article_number":d.get("article_number"),"tecdoc":d.get("tecdoc"),"eans":eans,"image_url":d.get("image_url"),"source":"oe_link","oe_link_id":d.get("id")})
                        return self.send_json({"items":items,"mode":"oe","oe_supported_remote":False,"note":"Standardowe IC API nie udostępnia wyszukiwania po numerze OE; pokazano zapisane powiązania OE↔IC."})
                    local=local_ic_search(c,query,50)
                remote=[];remote_error=None
                try:remote=ic_remote_search(query,mode if mode in ("sku","index") else "auto")
                except Exception as e:remote_error=clean(e,220)
                merged=[];seen=set()
                for x in remote+local:
                    k=(x.get("sku") or "")+"|"+(x.get("index") or "")
                    if k in seen:continue
                    seen.add(k);merged.append(x)
                if remote:
                    with db() as c:cache_ic_items(c,remote)
                return self.send_json({"items":[{k:v for k,v in x.items() if k!="raw"} for x in merged[:100]],"remote_count":len(remote),"cache_count":len(local),"remote_error":remote_error})
            except urllib.error.HTTPError as e:return self.send_json({"error":"ic_http","status":e.code},400)
            except Exception as e:return self.send_json({"error":"ic_error","message":clean(e,300)},400)

        if path=="/api/b2b/settings":
            with db() as c:
                cnt=c.execute("SELECT COUNT(*) FROM b2b_import_log").fetchone()[0]
            return self.send_json({"bridge_token":get_b2b_token(),"imports_count":cnt})

        if path=="/api/b2b/imports":
            with db() as c:
                rows=c.execute("SELECT * FROM b2b_import_log ORDER BY id DESC LIMIT 100").fetchall()
            out=[]
            for r in rows:
                x=dict(r)
                try:x["summary"]=json.loads(x.pop("summary_json") or "{}")
                except Exception:x["summary"]={}
                out.append(x)
            return self.send_json({"imports":out})

        if path=="/api/b2b/captures":
            q=urllib.parse.parse_qs(u.query)
            limit=max(1,min(200,inum(q.get("limit",["80"])[0]) or 80))
            with db() as c:
                rows=c.execute("SELECT * FROM b2b_captures ORDER BY id DESC LIMIT ?",(limit,)).fetchall()
            out=[]
            for r in rows:
                x=dict(r)
                try:x["parts"]=json.loads(x.pop("parts_json") or "[]")
                except Exception:x["parts"]=[]
                try:x["operations"]=json.loads(x.pop("operations_json") or "[]")
                except Exception:x["operations"]=[]
                x.pop("raw_text",None)
                out.append(x)
            return self.send_json({"captures":out})

        if path=="/api/b2b/export-times.csv":
            with db() as c:rows=c.execute("SELECT id,captured_at,page_title,page_url,vin,operations_json FROM b2b_captures ORDER BY id DESC").fetchall()
            sio=io.StringIO();w=csv.writer(sio,delimiter=";")
            w.writerow(["Data","VIN","Kod operacji","Czas","Jednostka","Opis/kontekst","Źródło"])
            for r in rows:
                try:ops=json.loads(r["operations_json"] or "[]")
                except Exception:ops=[]
                for op in ops:
                    w.writerow([r["captured_at"],r["vin"],op.get("code",""),op.get("value",""),op.get("unit",""),op.get("context",""),r["page_url"]])
            b=("\ufeff"+sio.getvalue()).encode("utf-8")
            self.send_response(200);self.security_headers();self.send_header("Content-Type","text/csv; charset=utf-8");self.send_header("Content-Disposition",'attachment; filename="MB_B2B_czasy_operacji.csv"');self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b);return

        if path=="/api/backup":
            fd,tmp=tempfile.mkstemp(prefix="mb_magazyn_backup_",suffix=".sqlite3");os.close(fd)
            try:
                s=db();d=sqlite3.connect(tmp)
                with d:s.backup(d)
                d.close();s.close();b=Path(tmp).read_bytes()
                fn=f"MB_Magazyn_backup_{datetime.now().strftime('%Y-%m-%d_%H-%M')}.sqlite3"
                self.send_response(200);self.security_headers();self.send_header("Content-Type","application/octet-stream");self.send_header("Content-Disposition",f'attachment; filename="{fn}"');self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
            finally:
                try:os.remove(tmp)
                except Exception:pass
            return

        if path=="/api/export-products.csv":
            with db() as c:
                rows=c.execute("""SELECT p.sku,p.oem_no,p.barcode,p.name,p.category,p.stock_qty,p.min_qty,p.purchase_price,p.sale_price,p.unit,l.code location,s.name supplier
                                  FROM products p LEFT JOIN locations l ON l.id=p.location_id LEFT JOIN suppliers s ON s.id=p.supplier_id
                                  WHERE p.active=1 ORDER BY p.name""").fetchall()
            sio=io.StringIO();w=csv.writer(sio,delimiter=";")
            w.writerow(["SKU","OEM","Barcode","Nazwa","Kategoria","Stan","Minimum","Cena zakupu","Cena sprzedaży","Jednostka","Lokalizacja","Dostawca"])
            for r in rows:w.writerow(list(r))
            b=("\ufeff"+sio.getvalue()).encode("utf-8")
            self.send_response(200);self.security_headers();self.send_header("Content-Type","text/csv; charset=utf-8");self.send_header("Content-Disposition",'attachment; filename="MB_Magazyn_produkty.csv"');self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b);return

        return self.send_json({"error":"not_found"},404)

    def do_POST(self):
        path=urllib.parse.urlparse(self.path).path;data=self.read_json()
        if data is None:return self.send_json({"error":"bad_json"},400)

        if path=="/api/ui-preferences":
            try: prefs=save_ui_preferences(data)
            except ValueError:return self.send_json({"error":"bad_theme"},400)
            except Exception:return self.send_json({"error":"preferences_write_failed"},500)
            return self.send_json({"ok":True,"preferences":prefs})

        if path=="/api/setup":
            if not setup_required():return self.send_json({"error":"already_setup"},409)
            password=str(data.get("password",""));username=clean(data.get("username"),80).lower() or "admin"
            if len(password)<10:return self.send_json({"error":"password_too_short"},400)
            if not re.fullmatch(r"[a-zA-Z0-9._-]{3,80}",username):return self.send_json({"error":"bad_username"},400)
            salt,h=pwd_hash(password);now_s=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                cur=c.execute("INSERT INTO users(password_salt,password_hash,created_at,username,display_name,role,permissions_json,active,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(salt,h,now_s,username,"Administrator","ADMIN",json.dumps(["*"]),1,now_s))
                r=c.execute("SELECT * FROM users WHERE id=?",(cur.lastrowid,)).fetchone()
            sid,csrf=new_session(r)
            return self.send_json({"ok":True,"csrf":csrf,"user":user_dict(r)},headers={"Set-Cookie":f"mbmag_session={sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}" + ("; Secure" if os.environ.get("MBMAG_SECURE_COOKIE","0")=="1" else "")})

        if path=="/api/login":
            ip=self.client_address[0];now=time.time()
            with LOGIN_LOCK:
                arr=[x for x in LOGIN_ATTEMPTS.get(ip,[]) if now-x<600];LOGIN_ATTEMPTS[ip]=arr
                if len(arr)>=8:return self.send_json({"error":"too_many_attempts"},429)
            password=str(data.get("password",""));username=clean(data.get("username"),80).lower() or "admin"
            with db() as c:r=c.execute("SELECT * FROM users WHERE lower(username)=lower(?) LIMIT 1",(username,)).fetchone()
            if not r or not int(r["active"] or 0) or not verify_password(password,r["password_salt"],r["password_hash"]):
                with LOGIN_LOCK:LOGIN_ATTEMPTS.setdefault(ip,[]).append(time.time())
                time.sleep(.35);return self.send_json({"error":"invalid_login"},401)
            with LOGIN_LOCK:LOGIN_ATTEMPTS.pop(ip,None)
            now_s=datetime.now().isoformat(timespec="seconds")
            with db() as c:c.execute("UPDATE users SET last_login=?,updated_at=COALESCE(updated_at,?) WHERE id=?",(now_s,now_s,r["id"]))
            sid,csrf=new_session(r)
            return self.send_json({"ok":True,"csrf":csrf,"user":user_dict(r)},headers={"Set-Cookie":f"mbmag_session={sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}" + ("; Secure" if os.environ.get("MBMAG_SECURE_COOKIE","0")=="1" else "")})

        if path=="/api/logout":
            sid,s=get_session(self.headers.get("Cookie"))
            if sid:
                with SESSIONS_LOCK:SESSIONS.pop(sid,None)
            return self.send_json({"ok":True},headers={"Set-Cookie":"mbmag_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict" + ("; Secure" if os.environ.get("MBMAG_SECURE_COOKIE","0")=="1" else "")})

        if path=="/api/account/password":
            a=self.auth(csrf=True)
            if not a:return
            sid,session=a;current=str(data.get("current_password","") or "");newp=str(data.get("new_password","") or "")
            if len(newp)<10:return self.send_json({"error":"password_too_short"},400)
            with db() as c:
                r=c.execute("SELECT * FROM users WHERE id=?",(session.get("user_id"),)).fetchone()
                if not r or not verify_password(current,r["password_salt"],r["password_hash"]):return self.send_json({"error":"wrong_password"},403)
                salt,h=pwd_hash(newp);c.execute("UPDATE users SET password_salt=?,password_hash=?,must_change_password=0,updated_at=? WHERE id=?",(salt,h,datetime.now().isoformat(timespec="seconds"),r["id"]))
            return self.send_json({"ok":True})

        if path=="/api/users":
            a=self.auth(csrf=True,perm="users_admin")
            if not a:return
            username=clean(data.get("username"),80).lower();display=clean(data.get("display_name"),120) or username;password=str(data.get("password","") or "")
            role=clean(data.get("role"),20).upper() or "EMPLOYEE";perms=data.get("permissions") if isinstance(data.get("permissions"),list) else []
            if not re.fullmatch(r"[a-zA-Z0-9._-]{3,80}",username):return self.send_json({"error":"bad_username"},400)
            if len(password)<10:return self.send_json({"error":"password_too_short"},400)
            if role not in ("ADMIN","EMPLOYEE"):role="EMPLOYEE"
            if role=="ADMIN":perms=["*"]
            allowed={"products_edit","stock_edit","documents_edit","substitutes_edit","tools_edit","suppliers_edit","locations_edit","contractors_edit","b2b_import","integrations_edit","data_admin","users_admin","write_general"}
            perms=[x for x in perms if x in allowed]
            salt,h=pwd_hash(password);now_s=datetime.now().isoformat(timespec="seconds")
            try:
                with db() as c:
                    cur=c.execute("INSERT INTO users(password_salt,password_hash,created_at,username,display_name,role,permissions_json,active,must_change_password,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(salt,h,now_s,username,display,role,json.dumps(perms),1,1 if data.get("must_change_password",True) else 0,now_s))
                return self.send_json({"ok":True,"id":cur.lastrowid})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate_username"},409)

        if re.fullmatch(r"/api/user/\d+/password",path):
            a=self.auth(csrf=True,perm="users_admin")
            if not a:return
            uid=int(path.split("/")[3]);newp=str(data.get("password","") or "")
            if len(newp)<10:return self.send_json({"error":"password_too_short"},400)
            salt,h=pwd_hash(newp)
            with db() as c:
                cur=c.execute("UPDATE users SET password_salt=?,password_hash=?,must_change_password=1,updated_at=? WHERE id=?",(salt,h,datetime.now().isoformat(timespec="seconds"),uid))
                if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
            return self.send_json({"ok":True})

        if path=="/api/partsinfo/import":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            item=data.get("item") if isinstance(data.get("item"),dict) else data
            oem=normalize_mb_part(item.get("oem_no"));name=clean(item.get("name"),300) or (f"Mercedes-Benz OEM {oem}" if oem else "")
            if not oem:return self.send_bridge_json({"error":"missing_oem"},400)
            now_s=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                supplier_id=ensure_supplier(c,"Mercedes-Benz")
                raw=dict(item);raw["purchase_price"]=0;raw["suggested_price"]=0;raw["source_url"]=clean(item.get("source_url"),1500)
                pid,created=b2b_upsert_product(c,raw,supplier_id,True)
                c.execute("UPDATE products SET catalog_source='PARTSINFO',catalog_checked_at=?,name=CASE WHEN ?<>'' THEN ? ELSE name END,updated_at=? WHERE id=?",(now_s,name,name,now_s,pid))
                save_mercedes_number_relations(c,pid,raw);save_b2b_hotspots(c,pid,raw)
                # Po imporcie katalogu poproś aktywne B2B o JEDEN odczyt.
                # Ten sam odczyt zwraca cenę i dostępność, więc nie kolejkujemy
                # drugiego, konkurencyjnego zapytania o dostępność.
                b2b_req=request_b2b_enrich(c,pid,oem,force=True)
                av_req=None
            return self.send_bridge_json({"ok":True,"product_id":pid,"created":created,"oem_no":oem,"b2b_request_id":b2b_req,"availability_request_id":av_req})

        if re.fullmatch(r"/api/tool/\d+/delete",path):
            sid,session=a
            if not has_permission(session,"tools_edit"):return self.send_json({"error":"forbidden"},403)
            tid=int(path.split("/")[3])
            with db() as c:
                cur=c.execute("DELETE FROM tools WHERE id=?",(tid,))
                if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
            return self.send_json({"ok":True,"deleted":tid})

        if path=="/api/tools/b2b-request":
            a=self.auth(csrf=True,perm="tools_edit")
            if not a:return
            catalog=clean(data.get("catalog_no"),160).upper();catalog_norm=normalize_lookup_code(catalog)
            if not re.fullmatch(r"W\d{10,14}",catalog_norm):return self.send_json({"error":"bad_catalog_no"},400)
            tool_id=inum(data.get("tool_id"));now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                if tool_id:
                    t=c.execute("SELECT * FROM tools WHERE id=?",(tool_id,)).fetchone()
                    if not t:return self.send_json({"error":"not_found"},404)
                    c.execute("UPDATE tools SET catalog_no=CASE WHEN catalog_no IS NULL OR catalog_no='' THEN ? ELSE catalog_no END,updated_at=? WHERE id=?",(catalog_norm,now,tool_id))
                else:
                    t=c.execute("SELECT * FROM tools WHERE REPLACE(REPLACE(REPLACE(UPPER(COALESCE(catalog_no,'')),' ',''),'-',''),'.','')=? LIMIT 1",(catalog_norm,)).fetchone()
                    if t:tool_id=t["id"]
                    else:
                        cur=c.execute("""INSERT INTO tools(name,category,manufacturer,model,catalog_no,serial_no,location_id,quantity,purchase_price_pln,purchase_price_eur,eur_rate,invoice_no,supplier_id,purchase_date,image_data,notes,active,created_at,updated_at)
                                         VALUES(?,?,?,?,?,?,NULL,1,0,0,0,'',NULL,'','','',1,?,?)""",
                                      (f"Mercedes {catalog_norm}","Wyposażenie warsztatu Mercedes","Mercedes-Benz","",catalog_norm,"",now,now))
                        tool_id=cur.lastrowid
                c.execute("UPDATE tool_b2b_requests SET status='CANCELLED',finished_at=?,error='Zastąpione nowym zleceniem' WHERE tool_id=? AND status IN ('PENDING','WORKING')",(now,tool_id))
                cur=c.execute("INSERT INTO tool_b2b_requests(tool_id,requested_catalog_no,requested_at,status) VALUES(?,?,?,'PENDING')",(tool_id,catalog_norm,now))
            return self.send_json({"ok":True,"tool_id":tool_id,"request_id":cur.lastrowid})

        m_manual=re.fullmatch(r"/api/product/(\d+)/manual-substitute",path)
        if m_manual:
            a=self.auth(csrf=True,perm="substitutes_edit")
            if not a:return
            pid=int(m_manual.group(1));code=normalize_mb_part(data.get("code"));action=clean(data.get("action"),20).lower() or "add"
            if not code:return self.send_json({"error":"code_required"},400)
            with db() as c:
                prow=c.execute("SELECT oem_no FROM products WHERE id=?",(pid,)).fetchone()
                if not prow:return self.send_json({"error":"not_found"},404)
                if action=="remove":
                    c.execute("DELETE FROM mercedes_part_relations WHERE product_id=? AND related_oem=? AND relation_type='MANUAL'",(pid,code))
                else:
                    if normalize_mb_part(prow["oem_no"])==code:return self.send_json({"error":"same_code"},400)
                    c.execute("""INSERT INTO mercedes_part_relations(product_id,related_oem,relation_type,note,created_at) VALUES(?,?,?,?,?)
                                 ON CONFLICT(product_id,related_oem,relation_type) DO UPDATE SET note=excluded.note""",
                              (pid,code,"MANUAL","Zamiennik wpisany ręcznie",datetime.now().isoformat(timespec="seconds")))
            return self.send_json({"ok":True,"code":code})

        if path=="/api/tools/import-xlsx":
            a=self.auth(csrf=True,perm="tools_edit")
            if not a:return
            b64=data.get("data_b64") or "";filename=clean(data.get("filename"),180) or "narzedzia.xlsx";dry=bool(data.get("dry_run",True))
            try:
                raw=base64.b64decode(b64,validate=True)
                if len(raw)>7_000_000:raise ValueError("Plik jest zbyt duży")
                rows=parse_tools_inventory_xlsx(raw)
            except Exception as e:return self.send_json({"error":"xlsx_parse","message":"Nie udało się odczytać pliku Excel: "+clean(e,300)},400)
            if not rows:return self.send_json({"error":"no_tools","message":"Nie znaleziono pozycji narzędzi w pliku"},400)
            for x in rows:
                if x.get("currency")=="EUR":
                    x["purchase_price_eur"]=round(x.get("price",0),4);x["purchase_price_pln"]=0;x["eur_rate"]=0;x["eur_rate_date"]="";x["eur_rate_table"]=""
                else:
                    x["purchase_price_eur"]=0;x["purchase_price_pln"]=round(x.get("price",0),2);x["eur_rate"]=0;x["eur_rate_date"]="";x["eur_rate_table"]=""
            with db() as c:
                existing=set()
                for t in c.execute("SELECT catalog_no,invoice_no,purchase_date,quantity,purchase_price_eur,purchase_price_pln FROM tools WHERE active=1").fetchall():existing.add(_tool_import_signature(dict(t)))
            duplicate=sum(1 for x in rows if _tool_import_signature(x) in existing);images=sum(1 for x in rows if x.get("image_data"));eur=sum(1 for x in rows if x.get("currency")=="EUR");pln=sum(1 for x in rows if x.get("currency")=="PLN")
            preview=[{k:x.get(k) for k in ("source_row","catalog_no","name","currency","quantity","purchase_date","invoice_no","location","purchase_price_eur","purchase_price_pln")}|{"has_image":bool(x.get("image_data")),"duplicate":_tool_import_signature(x) in existing} for x in rows[:12]]
            if dry:return self.send_json({"ok":True,"dry_run":True,"filename":filename,"recognized":len(rows),"duplicates":duplicate,"new_rows":len(rows)-duplicate,"images":images,"eur_rows":eur,"pln_rows":pln,"nbp_dates":len(set(x.get('purchase_date') for x in rows if x.get('currency')=='EUR' and x.get('purchase_date'))),"preview":preview})
            rate_cache={};rate_errors={}
            for x in rows:
                if x.get("currency")=="EUR" and x.get("purchase_price_eur",0)>0 and x.get("purchase_date"):
                    d=x["purchase_date"]
                    if d not in rate_cache and d not in rate_errors:
                        try:rate_cache[d]=nbp_eur_rate_for_date(d)
                        except Exception as e:rate_errors[d]=clean(e,180)
                    rr=rate_cache.get(d) or {};x["eur_rate"]=fnum(rr.get("rate"));x["eur_rate_date"]=clean(rr.get("effective_date"),10);x["eur_rate_table"]=clean(rr.get("table"),80);x["purchase_price_pln"]=round(x["purchase_price_eur"]*x["eur_rate"],2) if x["eur_rate"] else 0
            imported=skipped=0;errors=[];now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                existing=set(_tool_import_signature(dict(t)) for t in c.execute("SELECT catalog_no,invoice_no,purchase_date,quantity,purchase_price_eur,purchase_price_pln FROM tools WHERE active=1").fetchall())
                for x in rows:
                    sig=_tool_import_signature(x)
                    if sig in existing:skipped+=1;continue
                    try:
                        loc=_location_for_tool_import(c,x.get("location"));notes=f"Import z Excel: {filename}, wiersz {x.get('source_row')}"
                        if x.get('currency')=='EUR' and x.get('purchase_price_eur') and not x.get('eur_rate'):
                            notes += "; brak kursu NBP — przelicz po uzupełnieniu daty/kursu"
                        c.execute("""INSERT INTO tools(name,category,manufacturer,model,catalog_no,serial_no,location_id,quantity,purchase_price_pln,purchase_price_eur,eur_rate,invoice_no,supplier_id,purchase_date,image_data,notes,active,created_at,updated_at,eur_rate_date,eur_rate_table)
                                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)""",
                                  (clean(x.get("name"),300),clean(x.get("category"),160),clean(x.get("manufacturer"),160),"",clean(x.get("catalog_no"),160),"",loc,max(0,fnum(x.get("quantity"))) or 1,max(0,fnum(x.get("purchase_price_pln"))),max(0,fnum(x.get("purchase_price_eur"))),max(0,fnum(x.get("eur_rate"))),clean(x.get("invoice_no"),160),None,clean(x.get("purchase_date"),10),clean(x.get("image_data"),6_000_000),notes,now,now,clean(x.get("eur_rate_date"),10),clean(x.get("eur_rate_table"),80)))
                        existing.add(sig);imported+=1
                    except Exception as e:errors.append({"row":x.get("source_row"),"catalog_no":x.get("catalog_no"),"message":clean(e,240)})
            return self.send_json({"ok":True,"dry_run":False,"recognized":len(rows),"imported":imported,"skipped_duplicates":skipped,"errors":errors,"images":images,"nbp_missing":len(rate_errors),"nbp_errors":rate_errors})

        if path=="/api/tool":
            a=self.auth(csrf=True)
            if not a:return
            name=clean(data.get("name"),300)
            if not name:return self.send_json({"error":"name_required"},400)
            now=datetime.now().isoformat(timespec="seconds")
            eur=max(0,fnum(data.get("purchase_price_eur")));rate=max(0,fnum(data.get("eur_rate")));pln=max(0,fnum(data.get("purchase_price_pln")))
            rate_date=clean(data.get("eur_rate_date"),10);rate_table=clean(data.get("eur_rate_table"),80)
            if eur>0 and rate>0:pln=round(eur*rate,2)
            image=clean(data.get("image_data"),6_000_000)
            if image and not image.startswith("data:image/"):image=""
            with db() as c:
                cur=c.execute("""INSERT INTO tools(name,category,manufacturer,model,catalog_no,serial_no,location_id,quantity,purchase_price_pln,purchase_price_eur,eur_rate,invoice_no,supplier_id,purchase_date,image_data,notes,active,created_at,updated_at,eur_rate_date,eur_rate_table) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)""",
                    (name,clean(data.get("category"),160),clean(data.get("manufacturer"),160),clean(data.get("model"),160),clean(data.get("catalog_no"),160),clean(data.get("serial_no"),160),inum(data.get("location_id")),max(0,fnum(data.get("quantity"))) or 1,pln,eur,rate,clean(data.get("invoice_no"),160),inum(data.get("supplier_id")),clean(data.get("purchase_date"),10),image,clean(data.get("notes"),4000),now,now,rate_date,rate_table))
            return self.send_json({"ok":True,"id":cur.lastrowid,"purchase_price_pln":pln})

        if path=="/api/b2b/upload-xlsx":
            a=self.auth(csrf=True)
            if not a:return
            ids=data.get("ids") or [];qty_map=data.get("quantities") if isinstance(data.get("quantities"),dict) else {};vin=clean(data.get("vin"),80);person=clean(data.get("person"),160);note=clean(data.get("note"),300)
            try:ids=[int(x) for x in ids][:500]
            except Exception:return self.send_json({"error":"bad_ids"},400)
            if not ids:return self.send_json({"error":"no_products"},400)
            marks=','.join('?' for _ in ids)
            with db() as c:rows=c.execute(f"SELECT id,oem_no,sku,name FROM products WHERE id IN ({marks}) AND active=1 ORDER BY name",ids).fetchall()
            items=[]
            for r in rows:
                oem=normalize_mb_part(r["oem_no"] or r["sku"] or "")
                if not oem:continue
                items.append({"oem_no":oem,"quantity":max(1,inum(qty_map.get(str(r['id']),1)) or 1),"vin":vin,"person":person,"description":r["name"],"note":note})
            if not items:return self.send_json({"error":"no_oem"},400)
            try:b=make_b2b_upload_xlsx(items)
            except Exception as e:return self.send_json({"error":"xlsx_error","message":clean(e,300)},500)
            fn=f"B2BConnectUpload_MB_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            saved_path=""
            try:
                B2B_EXPORT_DIR.mkdir(parents=True,exist_ok=True);target=B2B_EXPORT_DIR/fn;target.write_bytes(b);saved_path=str(target)
                session=a[1] if a else {}
                with db() as c:c.execute("INSERT INTO b2b_export_history(created_at,user_id,username,file_name,file_path,item_count,vin,note) VALUES(?,?,?,?,?,?,?,?)",(datetime.now().isoformat(timespec="seconds"),session.get("user_id"),session.get("username"),fn,saved_path,len(items),vin,note))
            except Exception as e:saved_path=f"Błąd zapisu lokalnego: {clean(e,180)}"
            if getattr(self,"_audit_id",None):audit_finish(self._audit_id,"OK",f"Eksport B2B: {fn}");self._audit_id=None
            self.send_response(200);self.security_headers();self.send_header("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");self.send_header("Content-Disposition",f'attachment; filename="{fn}"');self.send_header("X-MB-Export-Path",urllib.parse.quote(saved_path));self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b);return

        if path=="/api/mercedes/heartbeat":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            now=datetime.now().isoformat(timespec="seconds")
            source=clean(data.get("source"),30).upper()
            if source not in {"PARTSINFO","B2B","XENTRY"}:return self.send_bridge_json({"error":"bad_source"},400)
            page_url=clean(data.get("page_url"),1500)
            try:host=(urllib.parse.urlparse(page_url).hostname or "").lower()
            except Exception:host=""
            allowed=(source=="PARTSINFO" and host=="aftersales.mercedes-benz.com") or (source in {"B2B","XENTRY"} and (host=="b2bconnect.mercedes-benz.com" or host=="xentry.mercedes-benz.com" or host.endswith(".mercedes-benz.com")))
            if page_url and not allowed:return self.send_bridge_json({"error":"source_not_allowed"},403)
            caps=data.get("capabilities") if isinstance(data.get("capabilities"),dict) else {}
            with db() as c:
                c.execute("""INSERT INTO mercedes_portal_status(source,last_seen,page_url,page_title,dealer_name,extension_version,capabilities_json,last_error)
                             VALUES(?,?,?,?,?,?,?,?)
                             ON CONFLICT(source) DO UPDATE SET last_seen=excluded.last_seen,page_url=excluded.page_url,page_title=excluded.page_title,
                             dealer_name=excluded.dealer_name,extension_version=excluded.extension_version,capabilities_json=excluded.capabilities_json,last_error=excluded.last_error""",
                          (source,now,page_url,clean(data.get("page_title"),300),clean(data.get("dealer_name"),300),clean(data.get("extension_version"),40),json.dumps(caps,ensure_ascii=False),clean(data.get("last_error"),1000)))
                if source=="B2B" or (source=="XENTRY" and bool(caps.get("commerce"))):
                    c.execute("""INSERT INTO b2b_runtime_status(id,last_seen,page_url,page_title,dealer_name,extension_version,last_error)
                                 VALUES(1,?,?,?,?,?,?)
                                 ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen,page_url=excluded.page_url,page_title=excluded.page_title,
                                 dealer_name=excluded.dealer_name,extension_version=excluded.extension_version,last_error=excluded.last_error""",
                              (now,page_url,clean(data.get("page_title"),300),clean(data.get("dealer_name"),300),clean(data.get("extension_version"),40),clean(data.get("last_error"),1000)))
            return self.send_bridge_json({"ok":True,"server_time":now})

        if path=="/api/b2b/heartbeat":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            now=datetime.now().isoformat(timespec="seconds")
            page_url=clean(data.get("page_url"),1500)
            try:host=(urllib.parse.urlparse(page_url).hostname or "").lower()
            except Exception:host=""
            if page_url and not (host=="b2bconnect.mercedes-benz.com" or host.endswith(".mercedes-benz.com")):
                return self.send_bridge_json({"error":"source_not_allowed"},403)
            with db() as c:
                c.execute("""INSERT INTO b2b_runtime_status(id,last_seen,page_url,page_title,dealer_name,extension_version,last_error)
                             VALUES(1,?,?,?,?,?,?)
                             ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen,page_url=excluded.page_url,page_title=excluded.page_title,
                             dealer_name=excluded.dealer_name,extension_version=excluded.extension_version,last_error=excluded.last_error""",
                          (now,page_url,clean(data.get("page_title"),300),clean(data.get("dealer_name"),300),clean(data.get("extension_version"),40),clean(data.get("last_error"),1000)))
            return self.send_bridge_json({"ok":True,"server_time":now})

        if path=="/api/b2b/part":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            page_url=clean(data.get("page_url"),1500)
            try:host=(urllib.parse.urlparse(page_url).hostname or "").lower()
            except Exception:host=""
            if not (host=="b2bconnect.mercedes-benz.com" or host.endswith(".mercedes-benz.com")):
                return self.send_bridge_json({"error":"source_not_allowed"},403)
            item=data.get("item") or {}
            item["related_numbers"]=[normalize_mb_part(x) for x in (item.get("related_numbers") or []) if normalize_mb_part(x)]
            item["source_url"]=page_url
            oem=normalize_mb_part(item.get("oem_no"))
            sku=clean(item.get("sku"),120)
            name=clean(item.get("name"),300)
            if not (oem or sku):return self.send_bridge_json({"error":"missing_part_code"},400)
            supplier=clean(item.get("supplier_name"),250) or "Mercedes-Benz"
            now=datetime.now().isoformat(timespec="seconds")
            key=b2b_import_key("PART",page_url,"","",supplier,[item])
            with db() as c:
                supplier_id=ensure_supplier(c,supplier)
                pid,created=b2b_upsert_product(c,item,supplier_id,True)
                save_b2b_availability_from_item(c,pid,item)
                save_b2b_hotspots(c,pid,item)
                save_mercedes_number_relations(c,pid,item)
                try:
                    c.execute("""INSERT INTO b2b_import_log(import_key,import_type,imported_at,page_url,supplier_name,items_count,movements_count,summary_json)
                                 VALUES(?,?,?,?,?,1,0,?)""",
                              (key,"PART",now,page_url,supplier,json.dumps({"product_id":pid,"created":created,"oem_no":oem,"sku":sku,"name":name},ensure_ascii=False)))
                except sqlite3.IntegrityError:
                    pass
                product=c.execute("SELECT id,sku,oem_no,name,stock_qty,purchase_price,sale_price FROM products WHERE id=?",(pid,)).fetchone()
            return self.send_bridge_json({"ok":True,"mode":"PART","created":created,"product":dict(product)})

        if path=="/api/b2b/order":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            page_url=clean(data.get("page_url"),1500)
            try:host=(urllib.parse.urlparse(page_url).hostname or "").lower()
            except Exception:host=""
            if not (host=="b2bconnect.mercedes-benz.com" or host.endswith(".mercedes-benz.com")):
                return self.send_bridge_json({"error":"source_not_allowed"},403)
            order_no=clean(data.get("order_no"),150)
            purchase_date=normalize_polish_date(data.get("purchase_date"))
            supplier=clean(data.get("supplier_name"),250) or "Mercedes-Benz"
            items=data.get("items") or []
            if not isinstance(items,list) or not items:return self.send_bridge_json({"error":"no_order_items"},400)
            clean_items=[]
            for x in items[:500]:
                if not isinstance(x,dict):continue
                oem=normalize_mb_part(x.get("oem_no"));sku=clean(x.get("sku"),120)
                if not (oem or sku):continue
                q=abs(fnum(x.get("quantity") or 1))
                if q<=0:continue
                clean_items.append({
                    "sku":sku,"oem_no":oem,"name":clean(x.get("name"),300),
                    "related_numbers":[normalize_mb_part(v) for v in (x.get("related_numbers") or []) if normalize_mb_part(v)],
                    "replacement_numbers":[normalize_mb_part(v) for v in (x.get("replacement_numbers") or []) if normalize_mb_part(v)],
                    "substitute_numbers":[normalize_mb_part(v) for v in (x.get("substitute_numbers") or []) if normalize_mb_part(v)],
                    "quantity":q,"purchase_price":max(0,fnum(x.get("purchase_price"))),
                    "suggested_price":max(0,fnum(x.get("suggested_price"))),
                    "unit":clean(x.get("unit"),20) or "szt.",
                    "preview_image":clean(x.get("preview_image"),6_000_000),
                    "diagram_position":clean(x.get("diagram_position"),30),
                    "diagram_hotspots":x.get("diagram_hotspots") if isinstance(x.get("diagram_hotspots"),list) else [],
                    "source_url":page_url,
                    "availability_status":clean(x.get("availability_status"),30),
                    "availability_label":clean(x.get("availability_label"),1000),
                    "availability_dealer":clean(x.get("availability_dealer"),300),
                    "availability_details":x.get("availability_details") if isinstance(x.get("availability_details"),dict) else {}
                })
                try: clean_items[-1]["diagram_marker_x"]=float(x.get("diagram_marker_x")) if x.get("diagram_marker_x") is not None else None
                except Exception: clean_items[-1]["diagram_marker_x"]=None
                try: clean_items[-1]["diagram_marker_y"]=float(x.get("diagram_marker_y")) if x.get("diagram_marker_y") is not None else None
                except Exception: clean_items[-1]["diagram_marker_y"]=None
            if not clean_items:return self.send_bridge_json({"error":"no_valid_items"},400)
            key=b2b_import_key("ORDER",page_url,order_no,purchase_date,supplier,clean_items)
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                # Numer zamówienia Mercedes jest nadrzędnym kluczem duplikatu.
                # URL i układ strony B2B mogą się zmieniać między otwarciami tego samego zamówienia.
                duplicate_order = bool(order_no and c.execute("SELECT id FROM b2b_import_log WHERE import_type='ORDER' AND order_no=? LIMIT 1",(order_no,)).fetchone())
                duplicate_key = bool(c.execute("SELECT id FROM b2b_import_log WHERE import_key=?",(key,)).fetchone())
                supplier_id=ensure_supplier(c,supplier)
                if duplicate_order or duplicate_key:
                    # Nie naliczaj stanu magazynowego drugi raz, ale pozwól ponownemu importowi
                    # odświeżyć metadane Mercedes (ceny, dostępność, relacje, zamienniki i rysunki).
                    refreshed=0
                    for item in clean_items:
                        item["source_url"]=page_url
                        pid,_=b2b_upsert_product(c,item,supplier_id,True)
                        save_mercedes_number_relations(c,pid,item)
                        save_b2b_availability_from_item(c,pid,item)
                        save_b2b_hotspots(c,pid,item)
                        refreshed+=1
                    return self.send_bridge_json({"ok":True,"duplicate":True,"metadata_refreshed":refreshed,"message":"Zamówienie było już zaimportowane — odświeżono dane B2B bez ponownego zwiększania stanu","order_no":order_no})
                doc_id,internal_doc=create_warehouse_document(c,"PZ",purchase_date,order_no,supplier_id,"Mercedes B2B","Import zamówienia Mercedes B2B")
                created_count=0;updated_count=0;movements=0;summary=[]
                for item in clean_items:
                    item["source_url"]=page_url
                    pid,created=b2b_upsert_product(c,item,supplier_id,True)
                    save_mercedes_number_relations(c,pid,item)
                    save_b2b_availability_from_item(c,pid,item)
                    save_b2b_hotspots(c,pid,item)
                    created_count += 1 if created else 0
                    updated_count += 0 if created else 1
                    q=item["quantity"];price=item["purchase_price"]
                    p=c.execute("SELECT stock_qty FROM products WHERE id=?",(pid,)).fetchone()
                    new_qty=float(p["stock_qty"])+q
                    line_no=f"{internal_doc}/{movements+1:02d}"
                    c.execute("""INSERT INTO movements(document_no,move_type,move_date,product_id,quantity,unit_price,reference_no,supplier_id,note,created_at,document_id)
                                 VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                              (line_no,"PZ",purchase_date,pid,q,price,order_no,supplier_id,"Import zamówienia Mercedes B2B",now,doc_id))
                    c.execute("""UPDATE products SET stock_qty=?,
                        purchase_price=CASE WHEN ?>0 THEN ? ELSE purchase_price END,
                        sale_price=CASE WHEN ?>0 THEN ? ELSE sale_price END,
                        supplier_id=?,updated_at=? WHERE id=?""",
                              (new_qty,price,price,item["suggested_price"],item["suggested_price"],supplier_id,now,pid))
                    movements+=1
                    summary.append({"product_id":pid,"oem_no":item["oem_no"],"sku":item["sku"],"name":item["name"],"qty":q,"purchase_price":price,"suggested_price":item["suggested_price"],"document_no":internal_doc})
                c.execute("""INSERT INTO b2b_import_log(import_key,import_type,imported_at,page_url,order_no,purchase_date,supplier_name,items_count,movements_count,summary_json)
                             VALUES(?,?,?,?,?,?,?,?,?,?)""",
                          (key,"ORDER",now,page_url,order_no,purchase_date,supplier,len(clean_items),movements,
                           json.dumps({"created_products":created_count,"updated_products":updated_count,"internal_document_no":internal_doc,"document_id":doc_id,"items":summary},ensure_ascii=False)))
            return self.send_bridge_json({"ok":True,"mode":"ORDER","duplicate":False,"order_no":order_no,"internal_document_no":internal_doc,"document_id":doc_id,"items":len(clean_items),"movements":movements,"created_products":created_count,"updated_products":updated_count})

        if path=="/api/tools/b2b/enrich/result":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            rid=inum(data.get("request_id"));now=datetime.now().isoformat(timespec="seconds")
            if not rid:return self.send_bridge_json({"error":"bad_request"},400)
            with db() as c:
                req=c.execute("SELECT * FROM tool_b2b_requests WHERE id=?",(rid,)).fetchone()
                if not req:return self.send_bridge_json({"error":"request_not_found"},404)
                if not data.get("ok",True):
                    c.execute("UPDATE tool_b2b_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,clean(data.get("error"),1000) or "Błąd B2B narzędzia",rid))
                    return self.send_bridge_json({"ok":True})
                item=data.get("item") if isinstance(data.get("item"),dict) else {}
                requested=normalize_lookup_code(req["requested_catalog_no"]);incoming=normalize_lookup_code(item.get("catalog_no"))
                if requested and incoming and requested!=incoming:
                    c.execute("UPDATE tool_b2b_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,f"B2B zwróciło {incoming}, oczekiwano {requested}",rid))
                    return self.send_bridge_json({"error":"catalog_mismatch"},409)
                tool=c.execute("SELECT * FROM tools WHERE id=?",(req["tool_id"],)).fetchone()
                if not tool:return self.send_bridge_json({"error":"tool_not_found"},404)
                name=clean(item.get("name"),300);catalog=clean(item.get("catalog_no") or req["requested_catalog_no"],160)
                price_eur=max(0,fnum(item.get("price_eur")));availability=clean(item.get("availability"),120)
                image=clean(item.get("image_data"),6_000_000);src=clean(item.get("source_url"),1500)
                if image and not image.startswith("data:image/"):image=""
                c.execute("""UPDATE tools SET
                             name=CASE WHEN ?<>'' THEN ? ELSE name END,
                             catalog_no=CASE WHEN ?<>'' THEN ? ELSE catalog_no END,
                             manufacturer=CASE WHEN manufacturer IS NULL OR manufacturer='' THEN 'Mercedes-Benz' ELSE manufacturer END,
                             category=CASE WHEN category IS NULL OR category='' THEN 'Wyposażenie warsztatu Mercedes' ELSE category END,
                             purchase_price_eur=CASE WHEN ?>0 THEN ? ELSE purchase_price_eur END,
                             purchase_price_pln=CASE WHEN ?>0 AND eur_rate>0 THEN ROUND(?*eur_rate,2) ELSE purchase_price_pln END,
                             image_data=CASE WHEN (image_data IS NULL OR image_data='') AND ?<>'' THEN ? ELSE image_data END,
                             b2b_availability=?,b2b_checked_at=?,b2b_source_url=?,updated_at=? WHERE id=?""",
                          (name,name,catalog,catalog,price_eur,price_eur,price_eur,price_eur,image,image,availability,now,src,now,req["tool_id"]))
                c.execute("UPDATE tool_b2b_requests SET status='DONE',finished_at=?,error=NULL WHERE id=?",(now,rid))
            return self.send_bridge_json({"ok":True,"tool_id":req["tool_id"]})

        if path=="/api/partsinfo/enrich/result":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            rid=inum(data.get("request_id"));now=datetime.now().isoformat(timespec="seconds")
            if not rid:return self.send_bridge_json({"error":"bad_request"},400)
            with db() as c:
                req=c.execute("SELECT * FROM partsinfo_enrich_requests WHERE id=?",(rid,)).fetchone()
                if not req:return self.send_bridge_json({"error":"request_not_found"},404)
                if not data.get("ok",True):
                    err=clean(data.get("error"),1000) or "Błąd Parts Information"
                    attempts=max(0,inum(req["attempts"]))
                    if attempts < 3:
                        warning=f"Parts Information: próba {attempts}/3 nieudana — ponawiam"
                        c.execute("UPDATE partsinfo_enrich_requests SET status='PENDING',started_at=NULL,finished_at=NULL,error=?,warning=? WHERE id=?",(err,warning,rid))
                        c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE product_id=?",(now,req["product_id"]))
                        return self.send_bridge_json({"ok":True,"retry":True,"attempts":attempts,"max_attempts":3})
                    final=f"PI: błąd po 3 próbach — użyto danych B2B. {err}"
                    c.execute("UPDATE partsinfo_enrich_requests SET status='ERROR',finished_at=?,error=?,warning=? WHERE id=?",(now,final,"Do weryfikacji — Parts Information nie zwróciło danych",rid))
                    c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE product_id=?",(now,req["product_id"]))
                    return self.send_bridge_json({"ok":True,"retry":False,"attempts":attempts,"max_attempts":3})
                item=data.get("item") if isinstance(data.get("item"),dict) else {}
                pid=req["product_id"];prod=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
                if not prod:return self.send_bridge_json({"error":"product_not_found"},404)
                incoming=normalize_mb_part(item.get("oem_no"));old=normalize_mb_part(prod["oem_no"] or req["requested_oem"]);requested=normalize_mb_part(req["requested_oem"])
                details=item.get("availability_details") if isinstance(item.get("availability_details"),dict) else {}
                verified=bool(details.get("verified_requested_oem")) and (not requested or incoming==requested)
                pi_suffix64_alias=bool(requested.endswith("64") and len(requested)>2 and incoming==requested[:-2])
                if requested and incoming and incoming!=requested and not pi_suffix64_alias:
                    c.execute("UPDATE partsinfo_enrich_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,f"Parts Information zwróciło {incoming}, oczekiwano {requested}",rid))
                    c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE product_id=?",(now,pid))
                    return self.send_bridge_json({"error":"oem_mismatch","message":f"Parts Information zwróciło {incoming}, oczekiwano {requested}"},409)
                if incoming and incoming!=old:
                    other=c.execute("SELECT id FROM products WHERE oem_no=? AND id<>?",(incoming,pid)).fetchone()
                    if not other:
                        c.execute("UPDATE products SET oem_no=?,sku=CASE WHEN sku IS NULL OR sku='' OR sku=? THEN ? ELSE sku END WHERE id=?",(incoming,old,incoming,pid))
                        if old:add_product_alias(c,pid,old,"MB_PI_SUFFIX64" if pi_suffix64_alias else "MB_PREVIOUS","Numer wejściowy Mercedes z końcówką 64" if pi_suffix64_alias else "Numer wpisany / poprzedni według Parts Information")
                for a in (item.get("related_numbers") or []):add_product_alias(c,pid,a,"MB_RELATED","Numer powiązany z Mercedes Parts Information")
                preview=clean(item.get("preview_image"),6_000_000)
                fp=hashlib.sha256(preview.encode("utf-8",errors="ignore")).hexdigest()[:32] if preview else clean(item.get("diagram_fingerprint"),64)
                pos=clean(item.get("diagram_position"),30)
                def coord(v):
                    try:
                        x=float(v)
                        return x if 0<=x<=1 else None
                    except Exception:return None
                mx,my=coord(item.get("diagram_marker_x")),coord(item.get("diagram_marker_y"))
                name=clean(item.get("name"),300)
                category=clean(item.get("category") or item.get("catalog_context"),120)
                src=clean(item.get("source_url"),1500)
                c.execute("""UPDATE products SET
                             name=CASE WHEN ?<>'' THEN ? ELSE name END,
                             category=CASE WHEN ?<>'' AND (category IS NULL OR category='' OR category='Do skatalogowania') THEN ? ELSE category END,
                             preview_image=CASE WHEN (preview_image IS NULL OR preview_image='') AND ?<>'' THEN ? ELSE preview_image END,
                             source_url=CASE WHEN ?<>'' THEN ? ELSE source_url END,
                             diagram_position=CASE WHEN ?<>'' THEN ? ELSE diagram_position END,
                             diagram_marker_x=COALESCE(?,diagram_marker_x),
                             diagram_marker_y=COALESCE(?,diagram_marker_y),
                             diagram_fingerprint=CASE WHEN ?<>'' THEN ? ELSE diagram_fingerprint END,
                             catalog_source='PARTSINFO',catalog_checked_at=?,updated_at=? WHERE id=?""",
                          (name,name,category,category,preview,preview,src,src,pos,pos,mx,my,fp,fp,now,now,pid))
                hotspots=item.get("diagram_hotspots") if isinstance(item.get("diagram_hotspots"),list) else []
                if fp:
                    # Do not delete older rows blindly: merge new positions from the same diagram.
                    if pos and mx is not None and my is not None:
                        hotspots=[{"position":pos,"oem_no":incoming or old,"name":name,"x":mx,"y":my},*hotspots]
                    for h in hotspots[:500]:
                        if not isinstance(h,dict):continue
                        hp=clean(h.get("position"),30);ho=normalize_mb_part(h.get("oem_no"));hn=clean(h.get("name"),300)
                        hx,hy=coord(h.get("x")),coord(h.get("y"))
                        if not hp or hx is None or hy is None:continue
                        upsert_diagram_hotspot(c,fp,hp,ho,hn,hx,hy,src,now)
                # Automatyczne wzbogacenie Parts Information ma zapisywać dokładnie te same
                # relacje co ręczny import: zamienniki logistyczne i kierunek zastąpień.
                save_mercedes_number_relations(c,pid,item)
                warning=clean(data.get("warning"),1000)
                c.execute("UPDATE partsinfo_enrich_requests SET status='DONE',finished_at=?,error=NULL,warning=? WHERE id=?",(now,warning,rid))
                c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE product_id=?",(now,pid))
                maybe_auto_assign_quick_location(c,pid)
            return self.send_bridge_json({"ok":True})

        if path=="/api/b2b/availability/result":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            rid=inum(data.get("request_id"));status=clean(data.get("status_code"),30).upper()
            allowed={"DEALER","CENTRAL","GERMANY","UNAVAILABLE","UNKNOWN","ERROR"}
            if not rid or status not in allowed:return self.send_bridge_json({"error":"bad_result"},400)
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                req=c.execute("SELECT * FROM mb_availability_requests WHERE id=?",(rid,)).fetchone()
                if not req:return self.send_bridge_json({"error":"request_not_found"},404)
                err=clean(data.get("error"),1000)
                if status=="ERROR":
                    c.execute("UPDATE mb_availability_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,err or "Błąd odczytu B2B",rid))
                else:
                    details=data.get("details") if isinstance(data.get("details"),dict) else {}
                    c.execute("""INSERT INTO mb_availability_cache(product_id,status_code,dealer_name,checked_oem,checked_at,source_url,raw_label,details_json,error,source)
                                 VALUES(?,?,?,?,?,?,?,?,?,?)
                                 ON CONFLICT(product_id) DO UPDATE SET status_code=excluded.status_code,dealer_name=excluded.dealer_name,checked_oem=excluded.checked_oem,checked_at=excluded.checked_at,source_url=excluded.source_url,raw_label=excluded.raw_label,details_json=excluded.details_json,error=excluded.error,source=excluded.source""",
                              (req["product_id"],status,clean(data.get("dealer_name"),300),normalize_mb_part(data.get("checked_oem") or req["requested_oem"]),now,clean(data.get("source_url"),1500),clean(data.get("raw_label"),1000),json.dumps(details,ensure_ascii=False),err,clean(data.get("source"),30) or "B2B"))
                    c.execute("UPDATE mb_availability_requests SET status='DONE',finished_at=?,error=NULL WHERE id=?",(now,rid))
            return self.send_bridge_json({"ok":True})

        if path=="/api/b2b/parts":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            page_url=clean(data.get("page_url"),1500)
            try:host=(urllib.parse.urlparse(page_url).hostname or "").lower()
            except Exception:host=""
            if not (host=="b2bconnect.mercedes-benz.com" or host.endswith(".mercedes-benz.com")):return self.send_bridge_json({"error":"source_not_allowed"},403)
            items=data.get("items") or []
            if not isinstance(items,list) or not items:return self.send_bridge_json({"error":"no_items"},400)
            now=datetime.now().isoformat(timespec="seconds");out=[]
            with db() as c:
                supplier_id=ensure_supplier(c,"Mercedes-Benz")
                for raw in items[:200]:
                    if not isinstance(raw,dict):continue
                    raw["source_url"]=page_url
                    oem=normalize_mb_part(raw.get("oem_no"));sku=clean(raw.get("sku"),120)
                    if not (oem or sku):continue
                    # related_numbers belong ONLY to this one B2B row.
                    raw["related_numbers"]=[normalize_mb_part(x) for x in (raw.get("related_numbers") or []) if normalize_mb_part(x)]
                    pid,created=b2b_upsert_product(c,raw,supplier_id,True)
                    save_b2b_availability_from_item(c,pid,raw)
                    save_b2b_hotspots(c,pid,raw)
                    save_mercedes_number_relations(c,pid,raw)
                    out.append({"product_id":pid,"created":created,"oem_no":oem,"name":clean(raw.get("name"),300)})
            return self.send_bridge_json({"ok":True,"mode":"PARTS","count":len(out),"items":out})

        if path=="/api/b2b/enrich/result":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            rid=inum(data.get("request_id"));now=datetime.now().isoformat(timespec="seconds")
            if not rid:return self.send_bridge_json({"error":"bad_request"},400)
            # Ujemny ID = wyszukiwanie B2B uruchomione bezpośrednio z formularza nowej części.
            if rid<0:
                mid=abs(rid)
                with db() as c:
                    req=c.execute("SELECT * FROM b2b_manual_search_requests WHERE id=?",(mid,)).fetchone()
                    if not req:return self.send_bridge_json({"error":"request_not_found"},404)
                    if not data.get("ok",True):
                        c.execute("UPDATE b2b_manual_search_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,clean(data.get("error"),1000) or "Błąd wyszukiwania B2B",mid))
                        return self.send_bridge_json({"ok":True})
                    item=data.get("item") if isinstance(data.get("item"),dict) else {}
                    incoming=normalize_mb_part(item.get("oem_no"));requested=normalize_mb_part(req["requested_oem"])
                    if requested and incoming and incoming!=requested:
                        c.execute("UPDATE b2b_manual_search_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,f"B2B zwróciło {incoming}, oczekiwano {requested}",mid))
                        return self.send_bridge_json({"error":"oem_mismatch"},409)
                    keep={k:item.get(k) for k in ("oem_no","sku","name","purchase_price","suggested_price","diagram_position","related_numbers","replacement_numbers","substitute_numbers","availability_status","availability_label","availability_dealer","source_url")}
                    c.execute("UPDATE b2b_manual_search_requests SET status='DONE',finished_at=?,error=NULL,result_json=? WHERE id=?",(now,json.dumps(keep,ensure_ascii=False),mid))
                return self.send_bridge_json({"ok":True,"manual_search":True})
            with db() as c:
                req=c.execute("SELECT * FROM b2b_enrich_requests WHERE id=?",(rid,)).fetchone()
                if not req:return self.send_bridge_json({"error":"request_not_found"},404)
                if not data.get("ok",True):
                    c.execute("UPDATE b2b_enrich_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,clean(data.get("error"),1000) or "Błąd B2B",rid))
                    c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE product_id=?",(now,req["product_id"]))
                    return self.send_bridge_json({"ok":True})
                item=data.get("item") if isinstance(data.get("item"),dict) else {}
                pid=req["product_id"];prod=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
                if not prod:return self.send_bridge_json({"error":"product_not_found"},404)
                incoming=normalize_mb_part(item.get("oem_no"));old=normalize_mb_part(prod["oem_no"] or req["requested_oem"]);requested=normalize_mb_part(req["requested_oem"])
                details=item.get("availability_details") if isinstance(item.get("availability_details"),dict) else {}
                verified=bool(details.get("verified_requested_oem")) and (not requested or incoming==requested)
                if requested and incoming and incoming!=requested:
                    c.execute("UPDATE b2b_enrich_requests SET status='ERROR',finished_at=?,error=? WHERE id=?",(now,f"B2B zwróciło {incoming}, oczekiwano {requested}",rid))
                    c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE product_id=?",(now,pid))
                    return self.send_bridge_json({"error":"oem_mismatch","message":f"B2B zwróciło {incoming}, oczekiwano {requested}"},409)
                if incoming and incoming!=old:
                    # B2B może zwrócić numer zastępujący; zachowaj go jako powiązanie,
                    # ale katalog/rysunek pozostawia Parts Information.
                    add_product_alias(c,pid,incoming,"MB_RELATED","Numer handlowy / zastępujący z B2B")
                for a in (item.get("related_numbers") or []):
                    add_product_alias(c,pid,a,"MB_PREVIOUS","Numer poprzedni / zastępujący B2B")
                save_mercedes_number_relations(c,pid,item)
                save_b2b_availability_from_item(c,pid,item)
                save_b2b_hotspots(c,pid,item)
                # Jeden odczyt B2B dostarcza jednocześnie cenę i dostępność.
                # Nie wyszukuj drugi raz tego samego OEM, jeśli oczekuje też osobne zlecenie dostępności.
                av_status=clean(item.get("availability_status"),30).upper()
                if av_status in ("DEALER","CENTRAL","GERMANY","UNAVAILABLE","UNKNOWN"):
                    c.execute("UPDATE mb_availability_requests SET status='DONE',finished_at=?,error=NULL WHERE product_id=? AND status IN ('PENDING','WORKING')",(now,pid))
                purchase=max(0,fnum(item.get("purchase_price")))
                catalog=max(0,fnum(item.get("suggested_price")))
                fallback_name=clean(item.get("name"),300)
                current_name=clean(prod["name"],300)
                generic=(not current_name or current_name.upper().startswith("MERCEDES-BENZ OEM ") or current_name.upper().startswith("DO SKATALOGOWANIA"))
                partsinfo_authoritative=(clean(prod["catalog_source"] if "catalog_source" in prod.keys() else "",40).upper()=="PARTSINFO")
                pi_last=c.execute("SELECT status FROM partsinfo_enrich_requests WHERE product_id=? ORDER BY id DESC LIMIT 1",(pid,)).fetchone()
                pi_failed=bool(pi_last and clean(pi_last["status"],20).upper()=="ERROR")
                update_name=bool(fallback_name) and not fallback_name.upper().startswith("MERCEDES-BENZ OEM ") and (generic or pi_failed or (verified and not partsinfo_authoritative))
                pricing_mode=prod["pricing_mode"] if "pricing_mode" in prod.keys() else "MARKUP"
                old_margin=prod["margin_pct"] if "margin_pct" in prod.keys() else 0
                effective_purchase=purchase if purchase>0 else fnum(prod["purchase_price"] if "purchase_price" in prod.keys() else 0)
                new_sell=catalog if catalog>0 else (calc_sell_net(effective_purchase,old_margin,pricing_mode) if purchase>0 else fnum(prod["sell_price_net"] if "sell_price_net" in prod.keys() else 0))
                new_margin=pricing_pct_from_prices(effective_purchase,catalog,pricing_mode) if catalog>0 and effective_purchase>0 else fnum(old_margin)
                c.execute("""UPDATE products SET
                             name=CASE WHEN ?=1 AND ?<>'' THEN ? ELSE name END,
                             purchase_price=CASE WHEN ?>0 THEN ? ELSE purchase_price END,
                             sale_price=CASE WHEN ?>0 THEN ? ELSE sale_price END,
                             sell_price_net=CASE WHEN ?>0 THEN ? ELSE sell_price_net END,
                             margin_pct=CASE WHEN ?>0 THEN ? ELSE margin_pct END,
                             commerce_checked_at=?,updated_at=? WHERE id=?""",
                          (1 if update_name else 0,fallback_name,fallback_name,purchase,purchase,catalog,catalog,new_sell,new_sell,catalog,new_margin,now,now,pid))
                c.execute("UPDATE b2b_enrich_requests SET status='DONE',finished_at=?,error=NULL WHERE id=?",(now,rid))
                c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE product_id=?",(now,pid))
                maybe_auto_assign_quick_location(c,pid)
            return self.send_bridge_json({"ok":True})

        if path=="/api/b2b/cart/result":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            rid=inum(data.get("request_id"));status=clean(data.get("status"),40).upper();now=datetime.now().isoformat(timespec="seconds")
            if status not in {"ADDED","ADDED_REVIEW_QTY","NOT_FOUND","ERROR","REPLACED"}:status="ERROR"
            with db() as c:
                req=c.execute("SELECT * FROM b2b_cart_requests WHERE id=?",(rid,)).fetchone()
                if not req:return self.send_bridge_json({"error":"request_not_found"},404)
                c.execute("UPDATE b2b_cart_requests SET status=?,finished_at=?,final_oem=?,message=? WHERE id=?",(status,now,normalize_mb_part(data.get("final_oem")),clean(data.get("message"),1000),rid))
            return self.send_bridge_json({"ok":True})

        if path=="/api/b2b/bridge":
            if not self.valid_b2b_token():return self.send_bridge_json({"error":"bad_token"},403)
            page_url=clean(data.get("page_url"),1500)
            try:
                host=(urllib.parse.urlparse(page_url).hostname or "").lower()
            except Exception:host=""
            if not (host=="b2bconnect.mercedes-benz.com" or host.endswith(".mercedes-benz.com")):
                return self.send_bridge_json({"error":"source_not_allowed"},403)
            raw=clean(data.get("raw_text"),350000)
            selected=clean(data.get("selected_text"),20000)
            if selected and selected not in raw: raw=(selected+"\n"+raw)[:350000]
            if not raw.strip():return self.send_bridge_json({"error":"empty_capture"},400)
            vin,parts,operations=parse_b2b_text(raw)
            cap_at=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                cur=c.execute("""INSERT INTO b2b_captures(captured_at,page_title,page_url,source_host,vin,selected_text,raw_text,parts_json,operations_json,status)
                                 VALUES(?,?,?,?,?,?,?,?,?,'NEW')""",
                              (cap_at,clean(data.get("page_title"),500),page_url,host,vin,selected,raw,
                               json.dumps(parts,ensure_ascii=False),json.dumps(operations,ensure_ascii=False)))
                cid=cur.lastrowid
            return self.send_bridge_json({"ok":True,"capture_id":cid,"vin":vin,"parts":len(parts),"operations":len(operations)})

        a=self.auth(csrf=True)
        if not a:return

        if path=="/api/b2b/manual-search/request":
            sid,session=a
            if not has_permission(session,"b2b_import") and not has_permission(session,"products_edit"):
                return self.send_json({"error":"forbidden"},403)
            oem=normalize_mb_part(data.get("oem") or data.get("code"))
            if not oem:return self.send_json({"error":"oem_required"},400)
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                # Jedno aktywne zlecenie dla danego OEM — wielokrotne kliknięcie nie tworzy kolejki duplikatów.
                old=c.execute("SELECT * FROM b2b_manual_search_requests WHERE requested_oem=? AND status IN ('PENDING','WORKING') ORDER BY id DESC LIMIT 1",(oem,)).fetchone()
                if old:return self.send_json({"ok":True,"request_id":old["id"],"oem":oem,"reused":True})
                cur=c.execute("INSERT INTO b2b_manual_search_requests(requested_oem,requested_at,status) VALUES(?,?,'PENDING')",(oem,now))
                rid=cur.lastrowid
            return self.send_json({"ok":True,"request_id":rid,"oem":oem,"reused":False})

        if path=="/api/pricing/settings":
            # Zmiana ustawień cen wymaga prawa do edycji kartoteki.
            sid,session=a
            if not has_permission(session,"products_edit"):return self.send_json({"error":"forbidden","permission":"products_edit"},403)
            vat=max(0,min(100,fnum(data.get("vat_rate"))))
            mode=normalize_pricing_mode(data.get("pricing_mode"));pct=fnum(data.get("pricing_pct"))
            if mode=="MARGIN" and pct>=100:return self.send_json({"error":"margin_too_high"},400)
            pct=max(-100,pct) if mode=="MARKUP" else max(-100,min(99.99,pct))
            apply_all=bool(data.get("apply_all"));active_only=bool(data.get("active_only",True));now=datetime.now().isoformat(timespec="seconds")
            updated=skipped=0
            with db() as c:
                c.execute("INSERT INTO pricing_settings(id,vat_rate,pricing_mode,pricing_pct,updated_at) VALUES(1,?,?,?,?) ON CONFLICT(id) DO UPDATE SET vat_rate=excluded.vat_rate,pricing_mode=excluded.pricing_mode,pricing_pct=excluded.pricing_pct,updated_at=excluded.updated_at",(vat,mode,pct,now))
                if apply_all:
                    sql="SELECT id,purchase_price FROM products"+(" WHERE active=1" if active_only else "")
                    rows=c.execute(sql).fetchall()
                    for r in rows:
                        buy=max(0,fnum(r["purchase_price"]))
                        if buy<=0:
                            c.execute("UPDATE products SET vat_rate=?,pricing_mode=?,margin_pct=?,updated_at=? WHERE id=?",(vat,mode,pct,now,r["id"]));skipped+=1;continue
                        sell=calc_sell_net(buy,pct,mode)
                        c.execute("UPDATE products SET vat_rate=?,pricing_mode=?,margin_pct=?,sell_price_net=?,updated_at=? WHERE id=?",(vat,mode,pct,sell,now,r["id"]));updated+=1
            return self.send_json({"ok":True,"settings":{"vat_rate":vat,"pricing_mode":mode,"pricing_pct":pct,"updated_at":now},"updated":updated,"skipped_no_purchase_price":skipped})

        if path=="/api/backup/create":
            backup_dir=DATA_DIR/"backup"
            backup_dir.mkdir(parents=True,exist_ok=True)
            fn=f"MB_Magazyn_backup_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.sqlite3"
            target=backup_dir/fn
            s=db();d=sqlite3.connect(str(target))
            try:
                with d:s.backup(d)
            finally:
                d.close();s.close()
            return self.send_json({"ok":True,"filename":fn,"path":str(target)})


        if path=="/api/products/bulk-delete":
            ids=data.get("ids") if isinstance(data.get("ids"),list) else []
            ids=sorted({inum(x) for x in ids if inum(x)>0})
            if not ids:return self.send_json({"error":"no_products"},400)
            if clean(data.get("confirm"),30)!="USUN":return self.send_json({"error":"confirmation_required"},400)
            backup_dir=DATA_DIR/"backup";backup_dir.mkdir(parents=True,exist_ok=True)
            fn=f"MB_Magazyn_before_delete_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.sqlite3";target=backup_dir/fn
            src=db();dst=sqlite3.connect(str(target))
            try:
                with dst:src.backup(dst)
            finally:dst.close();src.close()
            marks=",".join("?" for _ in ids)
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                doc_ids=[r[0] for r in c.execute(f"SELECT DISTINCT document_id FROM movements WHERE product_id IN ({marks}) AND document_id IS NOT NULL",ids).fetchall()]
                c.execute(f"DELETE FROM movements WHERE product_id IN ({marks})",ids)
                c.execute(f"UPDATE external_sync_lines SET product_id=NULL WHERE product_id IN ({marks})",ids)
                c.execute(f"DELETE FROM product_substitute_group WHERE product_id IN ({marks})",ids)
                c.execute(f"DELETE FROM products WHERE id IN ({marks})",ids)
                if doc_ids:
                    dm=",".join("?" for _ in doc_ids)
                    c.execute(f"DELETE FROM warehouse_documents WHERE id IN ({dm}) AND NOT EXISTS(SELECT 1 FROM movements m WHERE m.document_id=warehouse_documents.id)",doc_ids)
                orphan_groups=[r[0] for r in c.execute("SELECT id FROM substitute_groups WHERE NOT EXISTS(SELECT 1 FROM product_substitute_group pg WHERE pg.group_id=substitute_groups.id)").fetchall()]
                if orphan_groups:
                    gm=",".join("?" for _ in orphan_groups);c.execute(f"DELETE FROM external_substitutes WHERE group_id IN ({gm})",orphan_groups);c.execute(f"DELETE FROM substitute_groups WHERE id IN ({gm})",orphan_groups)
                c.commit()
            return self.send_json({"ok":True,"deleted":len(ids),"backup":str(target),"backup_filename":fn})

        if path=="/api/database/reset":
            if clean(data.get("confirm"),80)!="WYCZYSC BAZE":return self.send_json({"error":"confirmation_required"},400)
            backup_dir=DATA_DIR/"backup";backup_dir.mkdir(parents=True,exist_ok=True)
            fn=f"MB_Magazyn_before_reset_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.sqlite3";target=backup_dir/fn
            src=db();dst=sqlite3.connect(str(target))
            try:
                with dst:src.backup(dst)
            finally:dst.close();src.close()
            keep={"users"};conn=db();tables=[]
            try:
                conn.execute("PRAGMA foreign_keys=OFF")
                tables=[r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall() if r[0] not in keep]
                conn.execute("BEGIN IMMEDIATE")
                for t in tables:
                    if not re.fullmatch(r"[A-Za-z0-9_]+",t):continue
                    conn.execute(f'DELETE FROM "{t}"')
                seq_exists=conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sqlite_sequence'").fetchone()
                if seq_exists and tables:
                    marks=",".join("?" for _ in tables);conn.execute(f"DELETE FROM sqlite_sequence WHERE name IN ({marks})",tables)
                conn.commit()
            except Exception:
                try:conn.rollback()
                except Exception:pass
                raise
            finally:
                try:conn.execute("PRAGMA foreign_keys=ON")
                except Exception:pass
                conn.close()
            return self.send_json({"ok":True,"backup":str(target),"backup_filename":fn,"cleared_tables":len(tables)})

        if path=="/api/b2b/token/regenerate":
            return self.send_json({"ok":True,"bridge_token":regenerate_b2b_token()})

        if path.startswith("/api/b2b/capture/") and path.endswith("/create-product"):
            try:cid=int(path.split("/")[4])
            except Exception:return self.send_json({"error":"bad_id"},400)
            code=normalize_mb_part(clean(data.get("oem_no"),80))
            if not code:return self.send_json({"error":"oem_required"},400)
            with db() as c:
                cap=c.execute("SELECT * FROM b2b_captures WHERE id=?",(cid,)).fetchone()
                if not cap:return self.send_json({"error":"capture_not_found"},404)
                existing=c.execute("SELECT id,name FROM products WHERE oem_no=? AND active=1",(code,)).fetchone()
                if existing:return self.send_json({"ok":True,"id":existing["id"],"existing":True})
                context=clean(data.get("context"),500)
                name=clean(data.get("name"),300)
                if not name:
                    name=re.sub(re.escape(code),"",context,flags=re.I).strip(" -|:;")
                if len(name)<3:name=f"Mercedes-Benz OEM {code}"
                now=datetime.now().isoformat(timespec="seconds");ps=get_pricing_settings(c)
                cur=c.execute("""INSERT INTO products(oem_no,name,category,min_qty,purchase_price,sale_price,margin_pct,vat_rate,pricing_mode,sell_price_net,unit,notes,created_at,updated_at)
                                 VALUES(?,?,?,0,0,0,?,?,?,0,'szt.',?,?,?)""",
                              (code,name[:300],"Mercedes B2B",ps["pricing_pct"],ps["vat_rate"],ps["pricing_mode"],f"Źródło: {cap['page_url']}\nVIN: {cap['vin'] or ''}\nKontekst: {context}",now,now))
                pid=cur.lastrowid;ensure_product_barcode(c,pid)
            return self.send_json({"ok":True,"id":pid,"existing":False})

        if path=="/api/integrations/settings":
            save_integrations(data);return self.send_json({"ok":True})

        if path=="/api/integrations/sync-woo":
            try:
                source=clean(data.get("source"),30) or "direct"
                if not SYNC_LOCK.acquire(blocking=False):return self.send_json({"error":"sync_busy"},409)
                try:
                    if source=="local":
                        seen,made,issues=sync_local_sales();meta={}
                    else:
                        seen,made,issues,meta=sync_woo_direct()
                finally:SYNC_LOCK.release()
                return self.send_json({"ok":True,"seen":seen,"movements":made,"issues":issues,**meta})
            except urllib.error.HTTPError as e:return self.send_json({"error":"woo_http","status":e.code},400)
            except Exception as e:return self.send_json({"error":"woo_error","message":clean(e,300)},400)

        if path=="/api/integrations/import-moto":
            rows=data.get("rows") or []
            if not isinstance(rows,list) or len(rows)>50000:return self.send_json({"error":"bad_rows"},400)
            made=issues=0;seen=0
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                for i,r in enumerate(rows):
                    if not isinstance(r,dict):continue
                    order=clean(r.get("order_no"),150);sku=clean(r.get("sku"),120);oem=clean(r.get("oem_no"),120);qty=abs(fnum(r.get("quantity")));date=clean(r.get("date"),10) or datetime.now().strftime("%Y-%m-%d");action=clean(r.get("action"),20).upper() or "RW"
                    if not order or qty<=0 or (not sku and not oem):continue
                    seen+=1;line=clean(r.get("line_id"),120) or (sku or oem)
                    desired=0.0 if action in ("ZW","RETURN","0") else qty
                    m,iss=apply_external_line(c,"motowarsztat",order,line,sku,oem,clean(r.get("name"),300),desired,action,date,moto_order=order);made+=m;issues+=iss
                c.execute("INSERT INTO integration_log(source,synced_at,result,records_seen,movements_created,issues_count,message) VALUES(?,?,?,?,?,?,?)",("motowarsztat",datetime.now().isoformat(timespec="seconds"),"OK",seen,made,issues,"Import CSV zużycia części"));c.commit()
            return self.send_json({"ok":True,"seen":seen,"movements":made,"issues":issues})

        if path.startswith("/api/integrations/issues/") and path.endswith("/map"):
            try:iid=int(path.split("/")[4]);pid=int(data.get("product_id"))
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                issue=c.execute("SELECT * FROM integration_issues WHERE id=?",(iid,)).fetchone()
                prod=c.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
                if not issue or not prod:return self.send_json({"error":"not_found"},404)
                c.execute("UPDATE external_sync_lines SET product_id=? WHERE source=? AND external_doc=? AND external_line=?",(pid,issue["source"],issue["external_doc"],issue["external_line"]))
                c.execute("UPDATE integration_issues SET status='RESOLVED',message=message||' | Ręcznie przypisano do produktu ID '||?,updated_at=? WHERE id=?",(pid,datetime.now().isoformat(timespec="seconds"),iid))
            return self.send_json({"ok":True})

        if path=="/api/intercars/test":
            try:tok=ic_token();return self.send_json({"ok":True,"token_received":bool(tok)})
            except urllib.error.HTTPError as e:return self.send_json({"error":"ic_http","status":e.code},400)
            except Exception as e:return self.send_json({"error":"ic_error","message":clean(e,300)},400)

        if path=="/api/intercars/import-product":
            sku=clean(data.get("sku"),120);index=clean(data.get("index"),160);name=clean(data.get("name"),300) or index or sku;price=max(0,fnum(data.get("price_net")));brand=clean(data.get("brand"),160)
            eans=data.get("eans") if isinstance(data.get("eans"),list) else [];barcode=clean(eans[0],120) if eans else "";now=datetime.now().isoformat(timespec="seconds")
            try:
                with db() as c:
                    existing=find_product(c,sku,index)
                    if existing:
                        save_ic_link(c,existing["id"],data);save_ic_oe_link(c,existing["id"],data);cache_ic_items(c,[data]);return self.send_json({"ok":True,"id":existing["id"],"existing":True})
                    ps=get_pricing_settings(c);catalog=max(0,fnum(data.get("list_price_net")));sell=calc_sell_net(price,ps["pricing_pct"],ps["pricing_mode"]) if price>0 else catalog
                    cur=c.execute("""INSERT INTO products(sku,oem_no,barcode,name,category,min_qty,purchase_price,sale_price,margin_pct,vat_rate,pricing_mode,sell_price_net,unit,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(sku,index,barcode,name,"Inter Cars",0,price,catalog,ps["pricing_pct"],ps["vat_rate"],ps["pricing_mode"],sell,"szt.",f"Producent: {brand}" if brand else "",now,now));pid=cur.lastrowid;ensure_product_barcode(c,pid)
                    save_ic_link(c,pid,data);save_ic_oe_link(c,pid,data);cache_ic_items(c,[data])
                return self.send_json({"ok":True,"id":pid,"existing":False})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate_code"},409)

        if path=="/api/intercars/link-product":
            try:pid=int(data.get("product_id"))
            except Exception:return self.send_json({"error":"bad_id"},400)
            sku=clean(data.get("sku"),120);index=clean(data.get("index"),160)
            if not sku and not index:return self.send_json({"error":"ic_code_required"},400)
            try:
                tok=ic_token();obj=ic_call("/catalog/products",params={"sku":sku} if sku else {"index":index},token=tok);items=normalize_ic_items(obj)
                if not items:return self.send_json({"error":"ic_not_found"},404)
                item=next((x for x in items if sku and x.get("sku")==sku),items[0]);item=enrich_ic([item],tok)[0]
                with db() as c:
                    if not c.execute("SELECT 1 FROM products WHERE id=?",(pid,)).fetchone():return self.send_json({"error":"not_found"},404)
                    save_ic_link(c,pid,item);save_ic_oe_link(c,pid,item);cache_ic_items(c,[item])
                return self.send_json({"ok":True,"item":{k:v for k,v in item.items() if k!="raw"}})
            except urllib.error.HTTPError as e:return self.send_json({"error":"ic_http","status":e.code},400)
            except Exception as e:return self.send_json({"error":"ic_error","message":clean(e,300)},400)

        if path.startswith("/api/product/") and path.endswith("/intercars/sync"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            try:
                with db() as c:item=refresh_ic_link(c,pid)
                if not item:return self.send_json({"error":"ic_not_linked"},404)
                return self.send_json({"ok":True,"item":{k:v for k,v in item.items() if k!="raw"}})
            except urllib.error.HTTPError as e:return self.send_json({"error":"ic_http","status":e.code},400)
            except Exception as e:return self.send_json({"error":"ic_error","message":clean(e,300)},400)

        if path=="/api/intercars/sync-all":
            ok=failed=0;errors=[]
            try:tok=ic_token()
            except Exception as e:return self.send_json({"error":"ic_error","message":clean(e,300)},400)
            with db() as c:ids=[r[0] for r in c.execute("SELECT product_id FROM intercars_product_links ORDER BY product_id").fetchall()]
            for pid in ids:
                try:
                    with db() as c:
                        if refresh_ic_link(c,pid,tok):ok+=1
                        else:failed+=1
                except Exception as e:failed+=1;errors.append({"product_id":pid,"error":clean(e,180)})
            return self.send_json({"ok":True,"synced":ok,"failed":failed,"errors":errors[:20]})

        if path=="/api/intercars/customer":
            try:return self.send_json({"ok":True,"data":ic_call("/customer",token=ic_token())})
            except urllib.error.HTTPError as e:return self.send_json({"error":"ic_http","status":e.code},400)
            except Exception as e:return self.send_json({"error":"ic_error","message":clean(e,300)},400)

        if path.startswith("/api/product/") and path.endswith("/mercedes-enrich/request"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            force=bool(data.get("force",True))
            with db() as c:
                prod=c.execute("SELECT id,oem_no,sku FROM products WHERE id=?",(pid,)).fetchone()
                if not prod:return self.send_json({"error":"not_found"},404)
                oem=normalize_mb_part(prod["oem_no"] or prod["sku"])
                if not oem:return self.send_json({"error":"no_oem"},400)
                pi_id=request_partsinfo_enrich(c,pid,oem,force=force)
                b2b_id=request_b2b_enrich(c,pid,oem,force=force)
                # B2B enrich zapisuje cenę i dostępność w jednym przebiegu.
                # Oddzielna kolejka dostępności powodowała dwa automatyczne
                # wyszukania tego samego OEM i potrafiła nadpisywać stan zadania.
                av_id=None
            return self.send_json({"ok":True,"queued":True,"oem":oem,"partsinfo_request_id":pi_id,"b2b_request_id":b2b_id,"availability_request_id":av_id,"message":"Zlecono Parts Information oraz jeden odczyt B2B (cena + dostępność)."})

        if path.startswith("/api/product/") and path.endswith("/b2b-enrich/request"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                prod=c.execute("SELECT id,oem_no,sku FROM products WHERE id=?",(pid,)).fetchone()
                if not prod:return self.send_json({"error":"not_found"},404)
                oem=normalize_mb_part(prod["oem_no"] or prod["sku"])
                if not oem:return self.send_json({"error":"no_oem"},400)
                rid=request_b2b_enrich(c,pid,oem,force=bool(data.get("force",True)))
            return self.send_json({"ok":True,"queued":True,"request_id":rid,"oem":oem})

        if path=="/api/products/mercedes-enrich-many":
            ids=data.get("ids") if isinstance(data.get("ids"),list) else []
            only_missing=bool(data.get("only_missing",False))
            force=bool(data.get("force",False))
            queued=[];skipped=[]
            with db() as c:
                if not ids and only_missing:
                    rows=c.execute("""SELECT id,oem_no,sku,name,preview_image FROM products WHERE active=1 AND ((preview_image IS NULL OR preview_image='') OR name IS NULL OR trim(name)='' OR lower(name) IN ('do weryfikacji','część mercedes','czesc mercedes')) ORDER BY id LIMIT 1000""").fetchall()
                else:
                    clean_ids=[]
                    for raw in ids[:1000]:
                        try: clean_ids.append(int(raw))
                        except Exception: pass
                    rows=[]
                    if clean_ids:
                        marks=','.join('?' for _ in clean_ids)
                        rows=c.execute(f"SELECT id,oem_no,sku,name,preview_image FROM products WHERE active=1 AND id IN ({marks})",clean_ids).fetchall()
                for prod in rows:
                    if only_missing and prod["preview_image"] and clean(prod["name"],300) and clean(prod["name"],300).lower() not in ('do weryfikacji','część mercedes','czesc mercedes'):
                        skipped.append({"id":prod["id"],"reason":"complete"});continue
                    oem=normalize_mb_part(prod["oem_no"] or prod["sku"])
                    if not oem:
                        skipped.append({"id":prod["id"],"reason":"no_oem"});continue
                    pi_id=request_partsinfo_enrich(c,prod["id"],oem,force=force)
                    b2b_id=request_b2b_enrich(c,prod["id"],oem,force=force)
                    queued.append({"id":prod["id"],"oem":oem,"partsinfo_request_id":pi_id,"b2b_request_id":b2b_id,"had_image":bool(prod["preview_image"]),"name":prod["name"] or ""})
            return self.send_json({"ok":True,"queued":len(queued),"skipped":len(skipped),"items":queued,"skipped_items":skipped,"message":"Zlecono zbiorcze uzupełnianie danych Mercedes."})

        if path=="/api/availability/request-many":
            ids=data.get("ids") if isinstance(data.get("ids"),list) else []
            queued=0
            with db() as c:
                for raw_id in ids[:500]:
                    pid=inum(raw_id)
                    if not pid:continue
                    p=c.execute("SELECT id,oem_no,sku FROM products WHERE id=? AND active=1",(pid,)).fetchone()
                    if not p:continue
                    oem=normalize_mb_part(p["oem_no"] or p["sku"])
                    if oem and request_availability(c,pid,oem,force=bool(data.get("force",False))):queued+=1
            return self.send_json({"ok":True,"queued":queued})

        if path=="/api/cart/item" or path=="/api/cart/send-b2b":
            return self.send_json({"error":"disabled","message":"Koszyk/zamawianie do Mercedes B2B zostało wyłączone."},410)

        if path.startswith("/api/product/") and path.endswith("/alternatives/link"):
            try:pid=int(path.split("/")[3]);alt=int(data.get("alternative_product_id"))
            except Exception:return self.send_json({"error":"bad_id"},400)
            if pid==alt:return self.send_json({"error":"same_product"},400)
            with db() as c:
                if not c.execute("SELECT 1 FROM products WHERE id=? AND active=1",(pid,)).fetchone() or not c.execute("SELECT 1 FROM products WHERE id=? AND active=1",(alt,)).fetchone():return self.send_json({"error":"not_found"},404)
                gid=link_substitutes(c,pid,alt)
            return self.send_json({"ok":True,"group_id":gid})

        if path.startswith("/api/product/") and path.endswith("/alternatives/external"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                gid=ensure_group(c,pid);now=datetime.now().isoformat(timespec="seconds")
                c.execute("""INSERT INTO external_substitutes(group_id,source,external_sku,external_index,brand,name,description,last_stock,last_price_net,last_price_gross,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                             ON CONFLICT(group_id,source,external_sku,external_index) DO UPDATE SET brand=excluded.brand,name=excluded.name,description=excluded.description,last_stock=excluded.last_stock,last_price_net=excluded.last_price_net,last_price_gross=excluded.last_price_gross,updated_at=excluded.updated_at""",
                          (gid,"intercars",clean(data.get("sku"),120),clean(data.get("index"),160),clean(data.get("brand"),160),clean(data.get("name"),300),clean(data.get("description"),1200),fnum(data.get("stock")),fnum(data.get("price_net")),fnum(data.get("price_gross")),now))
            return self.send_json({"ok":True})

        if path.startswith("/api/product/") and path.endswith("/restore"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                cur=c.execute("UPDATE products SET active=1,updated_at=? WHERE id=?",(datetime.now().isoformat(timespec="seconds"),pid))
                if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
            return self.send_json({"ok":True})

        if path.startswith("/api/product/") and path.endswith("/availability/request"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            force=bool(data.get("force",False))
            with db() as c:
                prod=c.execute("SELECT id,oem_no,sku FROM products WHERE id=? AND active=1",(pid,)).fetchone()
                if not prod:return self.send_json({"error":"not_found"},404)
                oem=normalize_mb_part(prod["oem_no"] or prod["sku"])
                if not oem:return self.send_json({"error":"no_oem"},400)
                if not force:
                    av=c.execute("SELECT checked_at FROM mb_availability_cache WHERE product_id=?",(pid,)).fetchone()
                    if av and av["checked_at"]:
                        try:
                            age=(datetime.now()-datetime.fromisoformat(av["checked_at"])).total_seconds()
                            if age<300:return self.send_json({"ok":True,"queued":False,"cached":True,"oem":oem})
                        except Exception:pass
                rid=request_availability(c,pid,oem,force=force)
            return self.send_json({"ok":True,"queued":True,"cached":False,"request_id":rid,"status":"PENDING","oem":oem})

        if path.startswith("/api/product/") and path.endswith("/size-class"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            value=clean(data.get("size_class"),10).upper()
            if value not in ("","AUTO","XS","S","M","L","XL"):return self.send_json({"error":"bad_size_class"},400)
            with db() as c:
                p=c.execute("SELECT id,name,category FROM products WHERE id=?",(pid,)).fetchone()
                if not p:return self.send_json({"error":"not_found"},404)
                override="" if value in ("","AUTO") else value
                c.execute("UPDATE products SET size_class_override=?,updated_at=? WHERE id=?",(override,datetime.now().isoformat(timespec="seconds"),pid))
                profile=infer_part_size_profile(p["name"],p["category"],override)
            return self.send_json({"ok":True,"profile":profile})

        if path.startswith("/api/product/") and path.endswith("/location/suggest"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                suggestion=suggest_location_for_product(c,pid,assign=False)
            return self.send_json({"ok":True,"suggestion":suggestion})

        if path.startswith("/api/product/") and path.endswith("/location/auto"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                suggestion=suggest_location_for_product(c,pid,assign=True,create_if_missing=True)
            return self.send_json({"ok":True,"suggestion":suggestion})

        if path.startswith("/api/product/") and path.endswith("/diagram-marker/clear"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                p=c.execute("SELECT diagram_fingerprint,diagram_position,oem_no FROM products WHERE id=?",(pid,)).fetchone()
                if not p:return self.send_json({"error":"not_found"},404)
                c.execute("UPDATE products SET diagram_marker_x=NULL,diagram_marker_y=NULL,updated_at=? WHERE id=?",(now,pid))
                if p["diagram_fingerprint"] and p["diagram_position"]:
                    c.execute("DELETE FROM mercedes_diagram_hotspots WHERE diagram_fingerprint=? AND position=? AND COALESCE(oem_no,'')=COALESCE(?,'')",(p["diagram_fingerprint"],p["diagram_position"],normalize_mb_part(p["oem_no"])))
            return self.send_json({"ok":True})

        if path.startswith("/api/product/") and path.endswith("/diagram-marker"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            try:mx=float(data.get("x"));my=float(data.get("y"))
            except Exception:return self.send_json({"error":"bad_coords"},400)
            if not (0<=mx<=1 and 0<=my<=1):return self.send_json({"error":"bad_coords"},400)
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                p=c.execute("SELECT id,oem_no,name,diagram_position,diagram_fingerprint,source_url FROM products WHERE id=?",(pid,)).fetchone()
                if not p:return self.send_json({"error":"not_found"},404)
                pos=clean(data.get("diagram_position"),30) or clean(p["diagram_position"],30)
                c.execute("UPDATE products SET diagram_marker_x=?,diagram_marker_y=?,diagram_position=CASE WHEN ?<>'' THEN ? ELSE diagram_position END,updated_at=? WHERE id=?",(mx,my,pos,pos,now,pid))
                fp=clean(p["diagram_fingerprint"],80)
                oem=normalize_mb_part(clean(data.get("oem_no"),120) or p["oem_no"])
                name=clean(data.get("name"),300) or p["name"]
                if fp and pos:
                    if oem:
                        c.execute("DELETE FROM mercedes_diagram_hotspots WHERE diagram_fingerprint=? AND oem_no=? AND position<>?",(fp,oem,pos))
                    upsert_diagram_hotspot(c,fp,pos,oem,name,mx,my,clean(data.get("source_url"),1500) or clean(p["source_url"],1500),now)
            return self.send_json({"ok":True,"x":mx,"y":my})

        if path=="/api/system/open-chrome":
            url=clean(data.get("url"),1800)
            try:
                exe=open_url_in_chrome(url);return self.send_json({"ok":True,"browser":"chrome","executable":exe})
            except FileNotFoundError:return self.send_json({"error":"chrome_not_found","message":"Nie znaleziono Google Chrome"},404)
            except Exception as e:return self.send_json({"error":"open_failed","message":clean(e,300)},400)

        if path.startswith("/api/product/") and path.endswith("/stock-target"):
            try:pid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            if data.get("quantity") in (None,""):return self.send_json({"error":"quantity_required"},400)
            target=fnum(data.get("quantity"))
            if target<0:return self.send_json({"error":"bad_quantity"},400)
            try:
                with db() as c:
                    c.execute("BEGIN IMMEDIATE");r=set_product_stock_target(c,pid,target,clean(data.get("reference_no"),150) or "INWENTARYZACJA-KATALOGOWANIE",clean(data.get("note"),1000) or "Stan wpisany podczas katalogowania części","Katalogowanie")
                return self.send_json({"ok":True,**r})
            except ValueError:return self.send_json({"error":"product_not_found"},404)

        if path=="/api/shop-beta/test-connection":
            try:
                cfg=read_integrations()
                items=woo_call_json("GET","/products",None,{"per_page":1,"status":"any"})
                return self.send_json({"ok":True,"store":cfg.get("woo_url","").rstrip("/"),"api":"wc/v3","sample_count":len(items) if isinstance(items,list) else 0})
            except WooAPIError as e:
                return self.send_json({"error":"woo_http","status":e.status,"woo_code":e.code,"message":e.message},400)
            except Exception as e:
                return self.send_json({"error":"woo_error","message":clean(e,400)},400)

        if path=="/api/shop-beta/test-write-access":
            # Realny test prawa zapisu: utwórz niewidoczny szkic techniczny i od razu go usuń.
            created_id=0
            try:
                stamp=datetime.now().strftime("%Y%m%d%H%M%S")
                payload={"name":"MB Auto Serwis — test API "+stamp,"type":"simple","status":"draft","catalog_visibility":"hidden","regular_price":"1.00","manage_stock":False,"description":"Automatyczny test prawa zapisu API. Produkt powinien zostać natychmiast usunięty."}
                obj=woo_call_json("POST","/products",payload)
                created_id=inum(obj.get("id"))
                if not created_id:raise ValueError("WooCommerce nie zwrócił ID produktu testowego")
                try:
                    woo_call_json("DELETE",f"/products/{created_id}",None,{"force":"true"})
                    return self.send_json({"ok":True,"write":True,"cleanup":True,"woo_product_id":created_id,"message":"Zapis WooCommerce działa. Produkt testowy został utworzony i usunięty."})
                except Exception as de:
                    return self.send_json({"ok":True,"write":True,"cleanup":False,"woo_product_id":created_id,"message":f"Zapis działa, ale nie udało się automatycznie usunąć produktu testowego ID {created_id}: {clean(de,300)}"})
            except WooAPIError as e:
                msg=f"WooCommerce odrzucił zapis: {e.message} [HTTP {e.status}, {e.code}]"
                if e.status in (401,403):msg=f"Brak prawa zapisu lub problem autoryzacji WooCommerce. Klucz musi mieć Odczyt/Zapis. {msg}"
                return self.send_json({"error":"woo_write_failed","status":e.status,"woo_code":e.code,"message":msg,"created_id":created_id},400)
            except Exception as e:
                return self.send_json({"error":"woo_write_failed","message":clean(e,500),"created_id":created_id},400)

        if path=="/api/shop-beta/test-publish":
            ids=[inum(x) for x in (data.get("ids") or []) if inum(x)]
            if not ids:return self.send_json({"error":"no_products","message":"Zaznacz co najmniej jeden produkt"},400)
            cfg=read_integrations()
            if not cfg.get("woo_catalog_beta_enabled"):
                return self.send_json({"error":"beta_disabled","message":"Włącz realną synchronizację produktów BETA"},409)
            args=ids;sql="SELECT * FROM products WHERE active=1 AND woo_publish_enabled=1 AND id IN (%s) ORDER BY id"%(",".join("?"*len(ids)))
            with db() as c:rows=c.execute(sql,args).fetchall()
            result=[]
            for p in rows:
                sku=normalize_lookup_code(p["oem_no"] or p["sku"] or p["barcode"])
                if inum(p["woo_product_id"]):
                    result.append({"product_id":p["id"],"ok":False,"error":"Produkt ma już Woo ID — test nie nadpisuje istniejących produktów"});continue
                try:
                    # Najpierw spróbuj znaleźć istniejący produkt po wszystkich sensownych wariantach SKU.
                    # Starsze wpisy w Woo mogą mieć spacje/myślniki, podczas gdy CRM używa numeru znormalizowanego.
                    sku_variants=[]
                    for _v in (sku,clean(p["oem_no"],120),clean(p["sku"],120),clean(p["barcode"],120)):
                        _v=clean(_v,120)
                        if _v and _v not in sku_variants:sku_variants.append(_v)
                    existing=None
                    for _sku in sku_variants:
                        found=woo_call_json("GET","/products",None,{"sku":_sku,"per_page":20})
                        if isinstance(found,list) and found:
                            existing=found[0];break
                    if existing:
                        wid=inum(existing.get("id"));now=datetime.now().isoformat(timespec="seconds")
                        # Dokładny SKU już istnieje: nie nadpisuj produktu, tylko bezpiecznie powiąż CRM z Woo.
                        if wid:
                            with db() as c2:c2.execute("UPDATE products SET woo_product_id=?,woo_sync_status='POWIĄZANY-WOO',woo_last_sync=?,woo_last_error=NULL WHERE id=?",(wid,now,p["id"]))
                        result.append({"product_id":p["id"],"woo_product_id":wid,"ok":True,"outcome":"linked","status":existing.get("status"),"name":existing.get("name"),"sku":existing.get("sku"),"warning":f"Produkt o SKU {existing.get('sku') or sku} już istniał — powiązano bez nadpisywania"});continue
                    payload=woo_product_payload(p,cfg,"draft");warning=""
                    imgs,img_warning=woo_prepare_images(p,sku,title=payload.get("name") or sku)
                    if imgs:payload["images"]=imgs
                    elif img_warning:warning=img_warning
                    try:
                        obj=woo_call_json("POST","/products",payload)
                    except WooAPIError as e:
                        if payload.get("images") and _woo_image_error(e):
                            retry=dict(payload);retry.pop("images",None)
                            obj=woo_call_json("POST","/products",retry)
                            warning=(warning+" " if warning else "")+"Szkic utworzono bez zdjęcia — WooCommerce nie przyjęło obrazów produktu."
                        else:raise
                    wid=inum(obj.get("id"));now=datetime.now().isoformat(timespec="seconds")
                    if not wid:raise ValueError("WooCommerce nie zwrócił ID utworzonego produktu")
                    with db() as c2:c2.execute("UPDATE products SET woo_product_id=?,woo_sync_status='TEST-SZKIC',woo_last_sync=?,woo_last_error=NULL WHERE id=?",(wid,now,p["id"]))
                    result.append({"product_id":p["id"],"woo_product_id":wid,"ok":True,"outcome":"created","status":obj.get("status"),"name":obj.get("name"),"permalink":obj.get("permalink"),"sku":obj.get("sku"),"warning":warning})
                except WooAPIError as e:
                    if e.status in (401,403):err=f"Brak uprawnień zapisu w WooCommerce (HTTP {e.status}). Klucz REST musi mieć Odczyt/Zapis. {e.message}"
                    else:err=f"WooCommerce: {e.message} [HTTP {e.status}, {e.code}]"
                    with db() as c2:c2.execute("UPDATE products SET woo_sync_status='BŁĄD',woo_last_error=? WHERE id=?",(clean(err,600),p["id"]))
                    result.append({"product_id":p["id"],"ok":False,"error":clean(err,600),"woo_status":e.status,"woo_code":e.code})
                except Exception as e:
                    err=clean(e,600)
                    with db() as c2:c2.execute("UPDATE products SET woo_sync_status='BŁĄD',woo_last_error=? WHERE id=?",(err,p["id"]))
                    result.append({"product_id":p["id"],"ok":False,"error":err})
            return self.send_json({"ok":True,"mode":"TEST_DRAFT_CREATE_ONLY","items":result})

        if path=="/api/shop-beta/product":
            pid=inum(data.get("product_id"));enabled=1 if data.get("enabled") else 0;now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                p=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
                if not p:return self.send_json({"error":"not_found"},404)
                mode=normalize_pricing_mode(data.get("pricing_mode") if data.get("pricing_mode") not in (None,"") else p["pricing_mode"])
                pct=fnum(data.get("margin_pct")) if data.get("margin_pct") not in (None,"") else fnum(p["margin_pct"])
                sell=calc_sell_net(fnum(p["purchase_price"]),pct,mode) if fnum(p["purchase_price"])>0 else fnum(p["sell_price_net"])
                c.execute("UPDATE products SET woo_publish_enabled=?,woo_sync_status=?,pricing_mode=?,margin_pct=?,sell_price_net=?,updated_at=? WHERE id=?",(enabled,"DO SYNCHRONIZACJI" if enabled else "NIEPUBLIKOWANY",mode,pct,sell,now,pid))
            return self.send_json({"ok":True,"enabled":bool(enabled),"pricing_mode":mode,"margin_pct":pct,"sell_price_net":round(sell,2)})

        if path=="/api/shop-beta/preview":
            ids=[inum(x) for x in (data.get("ids") or []) if inum(x)]
            cfg=read_integrations();args=[];sql="SELECT * FROM products WHERE active=1 AND woo_publish_enabled=1"
            if ids:sql+=" AND id IN (%s)"%(",".join("?"*len(ids)));args=ids
            with db() as c:rows=c.execute(sql,args).fetchall()
            items=[]
            for p in rows:
                pl=woo_product_payload(p,cfg);items.append({"product_id":p["id"],"woo_product_id":p["woo_product_id"],"payload":pl,"image_ready":bool(pl.get("images"))})
            return self.send_json({"ok":True,"beta_enabled":bool(cfg.get("woo_catalog_beta_enabled")),"dry_run":True,"items":items})

        if path in ("/api/shop-beta/sync","/api/shop-beta/update-prices"):
            cfg=read_integrations();dry=bool(data.get("dry_run",True))
            if not dry and not cfg.get("woo_catalog_beta_enabled"):return self.send_json({"error":"beta_disabled","message":"Włącz moduł Sklep BETA w ustawieniach"},409)
            ids=[inum(x) for x in (data.get("ids") or []) if inum(x)]
            sql="SELECT * FROM products WHERE active=1 AND woo_publish_enabled=1";args=[]
            if ids:sql+=" AND id IN (%s)"%(",".join("?"*len(ids)));args=ids
            sql+=" ORDER BY id"
            with db() as c:rows=c.execute(sql,args).fetchall()
            result=[]
            for p in rows:
                payload=woo_product_payload(p,cfg)
                if path.endswith("update-prices"):payload={k:payload[k] for k in ("regular_price","manage_stock","stock_quantity","stock_status")}
                if dry:
                    result.append({"product_id":p["id"],"action":"update" if p["woo_product_id"] else "create","payload":payload});continue
                try:
                    wid=inum(p["woo_product_id"])
                    if not wid:
                        sku=normalize_lookup_code(p["oem_no"] or p["sku"] or p["barcode"])
                        found=woo_call_json("GET","/products",None,{"sku":sku,"per_page":20}) if sku else []
                        if isinstance(found,list) and found:wid=inum(found[0].get("id"))
                    obj=woo_call_json("PUT" if wid else "POST",f"/products/{wid}" if wid else "/products",payload)
                    wid=inum(obj.get("id")) or wid;now=datetime.now().isoformat(timespec="seconds")
                    with db() as c2:c2.execute("UPDATE products SET woo_product_id=?,woo_sync_status='ZSYNCHRONIZOWANY',woo_last_sync=?,woo_last_error=NULL WHERE id=?",(wid,now,p["id"]))
                    result.append({"product_id":p["id"],"woo_product_id":wid,"ok":True})
                except Exception as e:
                    err=clean(e,600)
                    with db() as c2:c2.execute("UPDATE products SET woo_sync_status='BŁĄD',woo_last_error=? WHERE id=?",(err,p["id"]))
                    result.append({"product_id":p["id"],"ok":False,"error":err})
            return self.send_json({"ok":True,"dry_run":dry,"items":result})

        if path=="/api/quick-catalog/add":
            codes=extract_quick_catalog_codes(data.get("codes") if data.get("codes") is not None else data.get("codes_text"))
            if not codes:return self.send_json({"error":"no_codes","message":"Nie znaleziono numerów części"},400)
            location_id=inum(data.get("location_id"));min_qty=max(0,fnum(data.get("min_qty")));stock_given=data.get("stock_qty") not in (None,"");stock_qty=max(0,fnum(data.get("stock_qty"))) if stock_given else None;source=clean(data.get("source"),30) or "MANUAL";auto_location=1 if data.get("auto_location",True) else 0
            now=datetime.now().isoformat(timespec="seconds");created=existing_count=queued=0;items=[]
            with db() as c:
                ps=get_pricing_settings(c)
                for code in codes:
                    p=find_product_by_any_code(c,code)
                    is_new=False
                    if not p:
                        try:
                            cur=c.execute("""INSERT INTO products(sku,oem_no,barcode,name,category,location_id,min_qty,purchase_price,sale_price,margin_pct,vat_rate,pricing_mode,sell_price_net,unit,notes,created_at,updated_at)
                                             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                          ("",code,"",f"Mercedes-Benz OEM {code}","Do skatalogowania",location_id,min_qty,0,0,ps["pricing_pct"],ps["vat_rate"],ps["pricing_mode"],0,"szt.","Utworzono przez Szybkie katalogowanie",now,now))
                            pid=cur.lastrowid;ensure_product_barcode(c,pid);p=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone();created+=1;is_new=True
                        except sqlite3.IntegrityError:
                            p=find_product_by_any_code(c,code)
                    if not p:continue
                    pid=int(p["id"]);existing_count += 0 if is_new else 1
                    if is_new and location_id:
                        loc=c.execute("SELECT id FROM locations WHERE id=? AND active=1",(location_id,)).fetchone()
                        if loc:assign_product_to_location(c,pid,location_id,True)
                    if stock_given:
                        set_product_stock_target(c,pid,stock_qty,"KATALOGOWANIE",f"Stan ustawiony przy katalogowaniu {code}","Szybkie katalogowanie")
                    c.execute("""INSERT INTO quick_catalog_entries(requested_oem,product_id,source,created_at,updated_at,auto_location)
                                 VALUES(?,?,?,?,?,?) ON CONFLICT(requested_oem,product_id) DO UPDATE SET source=excluded.source,updated_at=excluded.updated_at,auto_location=excluded.auto_location""",
                              (code,pid,source,now,now,auto_location))
                    pi_id=request_partsinfo_enrich(c,pid,code,force=False)
                    b2b_id=request_b2b_enrich(c,pid,code,force=False)
                    queued+=1
                    items.append({"product_id":pid,"requested_oem":code,"created":is_new,"partsinfo_request_id":pi_id,"b2b_request_id":b2b_id})
            return self.send_json({"ok":True,"received":len(codes),"created":created,"existing":existing_count,"queued":queued,"items":items})

        if path=="/api/quick-catalog/retry-errors":
            count=0;now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                for q in c.execute("SELECT id,product_id,requested_oem FROM quick_catalog_entries ORDER BY id").fetchall():
                    pi=c.execute("SELECT status FROM partsinfo_enrich_requests WHERE product_id=? ORDER BY id DESC LIMIT 1",(q["product_id"],)).fetchone()
                    bb=c.execute("SELECT status FROM b2b_enrich_requests WHERE product_id=? ORDER BY id DESC LIMIT 1",(q["product_id"],)).fetchone()
                    if (pi and pi["status"]=="ERROR") or (bb and bb["status"]=="ERROR"):
                        request_partsinfo_enrich(c,q["product_id"],q["requested_oem"],force=True);request_b2b_enrich(c,q["product_id"],q["requested_oem"],force=True)
                        c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE id=?",(now,q["id"]));count+=1
            return self.send_json({"ok":True,"queued":count})

        if path.startswith("/api/quick-catalog/") and path.endswith("/retry"):
            try:qid=int(path.split("/")[3])
            except Exception:return self.send_json({"error":"bad_id"},400)
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                q=c.execute("SELECT * FROM quick_catalog_entries WHERE id=?",(qid,)).fetchone()
                if not q:return self.send_json({"error":"not_found"},404)
                pi=request_partsinfo_enrich(c,q["product_id"],q["requested_oem"],force=True)
                bb=request_b2b_enrich(c,q["product_id"],q["requested_oem"],force=True)
                c.execute("UPDATE quick_catalog_entries SET updated_at=? WHERE id=?",(now,qid))
            return self.send_json({"ok":True,"partsinfo_request_id":pi,"b2b_request_id":bb})

        if path=="/api/product":
            name=clean(data.get("name"),300)
            if not name:return self.send_json({"error":"name_required"},400)
            now=datetime.now().isoformat(timespec="seconds")
            purchase=max(0,fnum(data.get("purchase_price")));catalog=max(0,fnum(data.get("sale_price")))
            with db() as _pc:ps=get_pricing_settings(_pc)
            pricing_mode=normalize_pricing_mode(data.get("pricing_mode") or ps["pricing_mode"])
            margin=fnum(data.get("margin_pct")) if data.get("margin_pct") not in (None,"") else fnum(ps["pricing_pct"])
            margin=max(-100,margin) if pricing_mode=="MARKUP" else max(-100,min(99.99,margin))
            vat=max(0,fnum(data.get("vat_rate"))) if data.get("vat_rate") not in (None,"") else fnum(ps["vat_rate"]);sell=max(0,fnum(data.get("sell_price_net")))
            if sell<=0:sell=calc_sell_net(purchase,margin,pricing_mode) if purchase>0 else catalog
            sku_in=clean(data.get("sku"),120);oem_in=normalize_mb_part(data.get("oem_no"));barcode_in=clean(data.get("barcode"),120) or auto_barcode_seed(oem_in,sku_in)
            vals=(sku_in,oem_in,barcode_in,name,clean(data.get("category"),120),
                  inum(data.get("supplier_id")),inum(data.get("location_id")),max(0,fnum(data.get("min_qty"))),purchase,catalog,margin,vat,pricing_mode,sell,
                  clean(data.get("unit"),20) or "szt.",clean(data.get("notes"),3000),clean(data.get("diagram_position"),30),now,now)
            try:
                with db() as c:
                    cur=c.execute("""INSERT INTO products(sku,oem_no,barcode,name,category,supplier_id,location_id,min_qty,purchase_price,sale_price,margin_pct,vat_rate,pricing_mode,sell_price_net,unit,notes,diagram_position,created_at,updated_at)
                                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",vals)
                    pid=cur.lastrowid
                    ensure_product_barcode(c,pid)
                    for alias in re.split(r"[,;\n]+",clean(data.get("aliases"),2000)):
                        if normalize_mb_part(alias):add_product_alias(c,pid,alias,"MB_MANUAL","Numer wpisany ręcznie")
                return self.send_json({"ok":True,"id":pid})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate_code"},409)

        if path=="/api/document/create-from-products":
            typ=clean(data.get("doc_type"),20).upper()
            if typ not in MOVE_TYPES:return self.send_json({"error":"bad_type"},400)
            date=normalize_polish_date(data.get("doc_date")) or datetime.now().strftime("%Y-%m-%d")
            raw_items=data.get("items") if isinstance(data.get("items"),list) else []
            items=[]
            for it in raw_items[:500]:
                if not isinstance(it,dict):continue
                pid=inum(it.get("product_id"));qty=abs(fnum(it.get("quantity")))
                if pid and qty>0:items.append({"product_id":pid,"quantity":qty,"unit_price":it.get("unit_price")})
            if not items:return self.send_json({"error":"no_items"},400)
            supplier_id=inum(data.get("supplier_id"));external_no=clean(data.get("reference_no"),150)
            moto_no=clean(data.get("motowarsztat_order_no"),150);shop_no=clean(data.get("shop_order_no"),150);notes=clean(data.get("notes"),3000)
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                prepared=[]
                seen=set()
                for it in items:
                    pid=it["product_id"]
                    if pid in seen:continue
                    seen.add(pid)
                    p=c.execute("SELECT id,name,oem_no,sku,stock_qty,purchase_price,sell_price_net,sale_price,margin_pct,pricing_mode FROM products WHERE id=? AND active=1",(pid,)).fetchone()
                    if not p:
                        c.rollback();return self.send_json({"error":"product_not_found","product_id":pid},404)
                    qty=it["quantity"];delta=MOVE_TYPES[typ]*qty;new_qty=fnum(p["stock_qty"])+delta
                    if new_qty < -0.000001:
                        c.rollback();return self.send_json({"error":"insufficient_stock","product_id":pid,"product":p["name"],"stock":p["stock_qty"],"requested":qty},409)
                    if it.get("unit_price") not in (None,""):
                        price=max(0,fnum(it.get("unit_price")))
                    elif typ=="WZ":
                        price=max(0,fnum(p["sell_price_net"]) or fnum(p["sale_price"]))
                    else:
                        price=max(0,fnum(p["purchase_price"]))
                    prepared.append((p,qty,delta,new_qty,price))
                if not prepared:
                    c.rollback();return self.send_json({"error":"no_items"},400)
                doc_id,doc=create_warehouse_document(c,typ,date,external_no,supplier_id,"Kartoteka — zaznaczone pozycje",notes or "Dokument utworzony z zaznaczonych pozycji kartoteki")
                for line_idx,(p,qty,delta,new_qty,price) in enumerate(prepared,1):
                    line_no=f"{doc}/{line_idx:02d}"
                    c.execute("""INSERT INTO movements(document_no,move_type,move_date,product_id,quantity,unit_price,reference_no,motowarsztat_order_no,shop_order_no,supplier_id,note,created_at,document_id)
                                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                              (line_no,typ,date,p["id"],delta,price,external_no,moto_no,shop_no,supplier_id,notes,now,doc_id))
                    new_sell=calc_sell_net(price,p["margin_pct"],p["pricing_mode"] if "pricing_mode" in p.keys() else "MARKUP") if typ=="PZ" and price>0 else fnum(p["sell_price_net"])
                    c.execute("""UPDATE products SET stock_qty=?,
                              sell_price_net=CASE WHEN ?='PZ' AND ?>0 THEN ? ELSE sell_price_net END,
                              purchase_price=CASE WHEN ?='PZ' AND ?>0 THEN ? ELSE purchase_price END,updated_at=? WHERE id=?""",
                              (new_qty,typ,price,new_sell,typ,price,price,now,p["id"]))
                c.commit()
            return self.send_json({"ok":True,"document_id":doc_id,"document_no":doc,"doc_type":typ,"lines":len(prepared)})

        if path=="/api/movement":
            typ=clean(data.get("move_type"),20)
            if typ not in MOVE_TYPES:return self.send_json({"error":"bad_type"},400)
            pid=inum(data.get("product_id"));qty=abs(fnum(data.get("quantity")));date=clean(data.get("move_date"),10) or datetime.now().strftime("%Y-%m-%d")
            if not pid or qty<=0:return self.send_json({"error":"bad_data"},400)
            price=max(0,fnum(data.get("unit_price")))
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                c.execute("BEGIN IMMEDIATE")
                p=c.execute("SELECT stock_qty,margin_pct,pricing_mode,sell_price_net FROM products WHERE id=? AND active=1",(pid,)).fetchone()
                if not p:
                    c.rollback();return self.send_json({"error":"product_not_found"},404)
                delta=MOVE_TYPES[typ]*qty
                new_qty=float(p["stock_qty"])+delta
                if new_qty < -0.000001:
                    c.rollback();return self.send_json({"error":"insufficient_stock","stock":p["stock_qty"]},409)
                supplier_id=inum(data.get("supplier_id"))
                doc_id,doc=create_warehouse_document(c,typ,date,clean(data.get("reference_no"),150),supplier_id,"Ręczny","Ruch magazynowy")
                c.execute("""INSERT INTO movements(document_no,move_type,move_date,product_id,quantity,unit_price,reference_no,motowarsztat_order_no,shop_order_no,supplier_id,note,created_at,document_id)
                             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (doc,typ,date,pid,delta,price,clean(data.get("reference_no"),150),clean(data.get("motowarsztat_order_no"),150),
                           clean(data.get("shop_order_no"),150),supplier_id,clean(data.get("note"),3000),now,doc_id))
                new_sell=calc_sell_net(price,p["margin_pct"],p["pricing_mode"] if "pricing_mode" in p.keys() else "MARKUP") if typ=="PZ" and price>0 else fnum(p["sell_price_net"])
                c.execute("""UPDATE products SET stock_qty=?,
                          sell_price_net=CASE WHEN ?='PZ' AND ?>0 THEN ? ELSE sell_price_net END,
                          purchase_price=CASE WHEN ?='PZ' AND ?>0 THEN ? ELSE purchase_price END, updated_at=? WHERE id=?""",
                          (new_qty,typ,price,new_sell,typ,price,price,now,pid))
                c.commit()
            return self.send_json({"ok":True,"document_no":doc,"stock_qty":new_qty})

        if path=="/api/contractor/lookup-nip":
            try:return self.send_json({"ok":True,"company":mf_lookup_nip(data.get("nip"))})
            except urllib.error.HTTPError as e:return self.send_json({"error":"mf_http","status":e.code},400)
            except Exception as e:return self.send_json({"error":"nip_lookup","message":clean(e,250)},400)

        if path=="/api/contractor":
            name=clean(data.get("name"),300);nip=re.sub(r"\D","",clean(data.get("nip"),20))
            if not name or len(nip)!=10:return self.send_json({"error":"bad_company"},400)
            role=clean(data.get("role"),50) or "Klient"
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                c.execute("""INSERT INTO contractors(name,nip,regon,krs,address,vat_status,phone,email,role,mf_request_id,updated_at)
                             VALUES(?,?,?,?,?,?,?,?,?,?,?)
                             ON CONFLICT(nip) DO UPDATE SET name=excluded.name,regon=excluded.regon,krs=excluded.krs,address=excluded.address,
                             vat_status=excluded.vat_status,phone=excluded.phone,email=excluded.email,role=excluded.role,mf_request_id=excluded.mf_request_id,updated_at=excluded.updated_at""",
                          (name,nip,clean(data.get("regon"),30),clean(data.get("krs"),30),clean(data.get("address"),500),
                           clean(data.get("vat_status"),80),clean(data.get("phone"),100),clean(data.get("email"),200),role,clean(data.get("mf_request_id"),120),now))
                if "Dostawca" in role:
                    row=c.execute("SELECT id FROM suppliers WHERE nip=? OR lower(name)=lower(?) LIMIT 1",(nip,name)).fetchone()
                    if row:c.execute("UPDATE suppliers SET name=?,nip=?,phone=?,email=?,active=1 WHERE id=?",(name,nip,clean(data.get("phone"),100),clean(data.get("email"),200),row["id"]))
                    else:c.execute("INSERT INTO suppliers(name,nip,phone,email,notes,active) VALUES(?,?,?,?,?,1)",(name,nip,clean(data.get("phone"),100),clean(data.get("email"),200),"Utworzony z kartoteki NIP"))
            return self.send_json({"ok":True})

        if path=="/api/supplier":
            name=clean(data.get("name"),250)
            if not name:return self.send_json({"error":"name_required"},400)
            try:
                with db() as c:c.execute("INSERT INTO suppliers(name,phone,email,nip,notes,active) VALUES(?,?,?,?,?,1)",(name,clean(data.get("phone"),100),clean(data.get("email"),200),clean(data.get("nip"),50),clean(data.get("notes"),2000)))
                return self.send_json({"ok":True})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate"},409)

        if path=="/api/location":
            code=clean(data.get("code"),80).upper();name=clean(data.get("name"),200)
            if not code:return self.send_json({"error":"code_required"},400)
            try:
                with db() as c:c.execute("INSERT INTO locations(code,name,notes,size_class,capacity,storage_type,active) VALUES(?,?,?,?,?,?,1)",(code,name,clean(data.get("notes"),1000),clean(data.get("size_class"),10).upper() or "ANY",max(0,inum(data.get("capacity"))),clean(data.get("storage_type"),30).upper() or "GENERAL"))
                return self.send_json({"ok":True})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate"},409)

        if path=="/api/import-products":
            rows=data.get("rows") or []
            if not isinstance(rows,list) or len(rows)>50000:return self.send_json({"error":"bad_rows"},400)
            now=datetime.now().isoformat(timespec="seconds");n=0
            with db() as c:
                ps=get_pricing_settings(c)
                for r in rows:
                    if not isinstance(r,dict):continue
                    name=clean(r.get("name"),300)
                    if not name:continue
                    sku=clean(r.get("sku"),120);oem=clean(r.get("oem_no"),120);barcode=clean(r.get("barcode"),120)
                    existing=None
                    if sku:existing=c.execute("SELECT id,margin_pct,pricing_mode,sell_price_net FROM products WHERE sku=?",(sku,)).fetchone()
                    if not existing and oem:existing=c.execute("SELECT id,margin_pct,pricing_mode,sell_price_net FROM products WHERE oem_no=?",(oem,)).fetchone()
                    purchase=max(0,fnum(r.get("purchase_price")));catalog=max(0,fnum(r.get("sale_price")))
                    if existing:
                        pmode=normalize_pricing_mode(existing["pricing_mode"] if "pricing_mode" in existing.keys() else "MARKUP");ppct=fnum(existing["margin_pct"]);sell=calc_sell_net(purchase,ppct,pmode) if purchase>0 else fnum(existing["sell_price_net"])
                        c.execute("""UPDATE products SET name=?,category=?,barcode=COALESCE(NULLIF(?,''),barcode),min_qty=?,purchase_price=?,sale_price=?,sell_price_net=?,unit=?,updated_at=? WHERE id=?""",
                                  (name,clean(r.get("category"),120),barcode,max(0,fnum(r.get("min_qty"))),purchase,catalog,sell,clean(r.get("unit"),20) or "szt.",now,existing["id"]))
                    else:
                        sell=calc_sell_net(purchase,ps["pricing_pct"],ps["pricing_mode"]) if purchase>0 else catalog
                        try:
                            cur=c.execute("""INSERT INTO products(sku,oem_no,barcode,name,category,min_qty,purchase_price,sale_price,margin_pct,vat_rate,pricing_mode,sell_price_net,unit,created_at,updated_at)
                                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(sku,oem,barcode,name,clean(r.get("category"),120),max(0,fnum(r.get("min_qty"))),purchase,catalog,ps["pricing_pct"],ps["vat_rate"],ps["pricing_mode"],sell,clean(r.get("unit"),20) or "szt.",now,now))
                            ensure_product_barcode(c,cur.lastrowid)
                        except sqlite3.IntegrityError:continue
                    n+=1
            return self.send_json({"ok":True,"rows":n})

        return self.send_json({"error":"not_found"},404)

    def do_PUT(self):
        path=urllib.parse.urlparse(self.path).path;data=self.read_json()
        a=self.auth(csrf=True)
        if not a:return
        sid,session=a

        if re.fullmatch(r"/api/user/\d+",path):
            if not has_permission(session,"users_admin"):return self.send_json({"error":"forbidden"},403)
            uid=int(path.rsplit("/",1)[1]);display=clean(data.get("display_name"),120);role=clean(data.get("role"),20).upper() or "EMPLOYEE"
            active=1 if data.get("active",True) else 0;perms=data.get("permissions") if isinstance(data.get("permissions"),list) else []
            if uid==session.get("user_id") and not active:return self.send_json({"error":"cannot_disable_self"},400)
            if role=="ADMIN":perms=["*"]
            allowed={"products_edit","stock_edit","documents_edit","substitutes_edit","tools_edit","suppliers_edit","locations_edit","contractors_edit","b2b_import","integrations_edit","data_admin","users_admin","write_general"}
            perms=[x for x in perms if x in allowed]
            with db() as c:
                cur=c.execute("UPDATE users SET display_name=?,role=?,permissions_json=?,active=?,updated_at=? WHERE id=?",(display,role,json.dumps(perms),active,datetime.now().isoformat(timespec="seconds"),uid))
                if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
            return self.send_json({"ok":True})

        if path.startswith("/api/tool/"):
            try:tid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            name=clean(data.get("name"),300)
            if not name:return self.send_json({"error":"name_required"},400)
            eur=max(0,fnum(data.get("purchase_price_eur")));rate=max(0,fnum(data.get("eur_rate")));pln=max(0,fnum(data.get("purchase_price_pln")))
            rate_date=clean(data.get("eur_rate_date"),10);rate_table=clean(data.get("eur_rate_table"),80)
            if eur>0 and rate>0:pln=round(eur*rate,2)
            image=clean(data.get("image_data"),6_000_000)
            if image and not image.startswith("data:image/"):image=""
            now=datetime.now().isoformat(timespec="seconds")
            with db() as c:
                old=c.execute("SELECT image_data FROM tools WHERE id=?",(tid,)).fetchone()
                if not old:return self.send_json({"error":"not_found"},404)
                if not image:image=old["image_data"]
                c.execute("""UPDATE tools SET name=?,category=?,manufacturer=?,model=?,catalog_no=?,serial_no=?,location_id=?,quantity=?,purchase_price_pln=?,purchase_price_eur=?,eur_rate=?,invoice_no=?,supplier_id=?,purchase_date=?,image_data=?,notes=?,updated_at=?,eur_rate_date=?,eur_rate_table=? WHERE id=?""",
                    (name,clean(data.get("category"),160),clean(data.get("manufacturer"),160),clean(data.get("model"),160),clean(data.get("catalog_no"),160),clean(data.get("serial_no"),160),inum(data.get("location_id")),max(0,fnum(data.get("quantity"))) or 1,pln,eur,rate,clean(data.get("invoice_no"),160),inum(data.get("supplier_id")),clean(data.get("purchase_date"),10),image,clean(data.get("notes"),4000),now,rate_date,rate_table,tid))
            return self.send_json({"ok":True,"purchase_price_pln":pln})

        if path.startswith("/api/intercars/oe-link/"):
            try:lid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:c.execute("DELETE FROM intercars_oe_links WHERE id=?",(lid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/tool/"):
            try:tid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:c.execute("DELETE FROM tools WHERE id=?",(tid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/alternative/external/"):
            try:aid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:c.execute("DELETE FROM external_substitutes WHERE id=?",(aid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/document/"):
            try:did=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            doc_date=normalize_polish_date(data.get("doc_date"));external_no=clean(data.get("external_no"),150);supplier_id=inum(data.get("supplier_id"));notes=clean(data.get("notes"),2000);lines=data.get("lines") or []
            with db() as c:
                doc=c.execute("SELECT * FROM warehouse_documents WHERE id=?",(did,)).fetchone()
                if not doc:return self.send_json({"error":"not_found"},404)
                existing={r["id"]:r for r in c.execute("SELECT * FROM movements WHERE document_id=?",(did,)).fetchall()};changes=[]
                for it in lines:
                    mid=inum(it.get("id"));oldm=existing.get(mid)
                    if not oldm:continue
                    q=abs(fnum(it.get("quantity")));price=max(0,fnum(it.get("unit_price")))
                    if q<=0:return self.send_json({"error":"bad_quantity"},400)
                    pos=doc["doc_type"] in ("PZ","ZW","KOREKTA+");newq=q if pos else -q;delta=newq-fnum(oldm["quantity"])
                    p=c.execute("SELECT stock_qty,name FROM products WHERE id=?",(oldm["product_id"],)).fetchone()
                    if not p or fnum(p["stock_qty"])+delta < -1e-6:return self.send_json({"error":"insufficient_stock","product":p["name"] if p else "?"},409)
                    changes.append((mid,oldm["product_id"],newq,price,delta))
                c.execute("UPDATE warehouse_documents SET doc_date=?,external_no=?,supplier_id=?,notes=? WHERE id=?",(doc_date,external_no,supplier_id,notes,did))
                for mid,pid,newq,price,delta in changes:
                    c.execute("UPDATE movements SET move_date=?,quantity=?,unit_price=?,reference_no=?,supplier_id=? WHERE id=?",(doc_date,newq,price,external_no,supplier_id,mid));c.execute("UPDATE products SET stock_qty=stock_qty+?,updated_at=? WHERE id=?",(delta,datetime.now().isoformat(timespec="seconds"),pid))
            return self.send_json({"ok":True})

        if path.startswith("/api/contractor/"):
            try:cid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            name=clean(data.get("name"),300);nip=re.sub(r"\D","",clean(data.get("nip"),20)) or None
            if not name:return self.send_json({"error":"name_required"},400)
            try:
                with db() as c:c.execute("UPDATE contractors SET name=?,nip=?,regon=?,krs=?,address=?,vat_status=?,phone=?,email=?,role=?,updated_at=? WHERE id=?",(name,nip,clean(data.get("regon"),30),clean(data.get("krs"),30),clean(data.get("address"),500),clean(data.get("vat_status"),80),clean(data.get("phone"),100),clean(data.get("email"),200),clean(data.get("role"),50) or "Klient",datetime.now().isoformat(timespec="seconds"),cid))
                return self.send_json({"ok":True})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate_nip"},409)

        if path.startswith("/api/supplier/"):
            try:sid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            name=clean(data.get("name"),250)
            if not name:return self.send_json({"error":"name_required"},400)
            with db() as c:c.execute("UPDATE suppliers SET name=?,phone=?,email=?,nip=?,notes=?,active=1 WHERE id=?",(name,clean(data.get("phone"),100),clean(data.get("email"),200),clean(data.get("nip"),50),clean(data.get("notes"),2000),sid))
            return self.send_json({"ok":True})

        if path.startswith("/api/location/"):
            try:lid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            code=clean(data.get("code"),80).upper();name=clean(data.get("name"),200)
            if not code:return self.send_json({"error":"code_required"},400)
            try:
                with db() as c:
                    cur=c.execute("UPDATE locations SET code=?,name=?,notes=?,size_class=?,capacity=?,storage_type=? WHERE id=?",(code,name,clean(data.get("notes"),1000),clean(data.get("size_class"),10).upper() or "ANY",max(0,inum(data.get("capacity"))),clean(data.get("storage_type"),30).upper() or "GENERAL",lid))
                    if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
                return self.send_json({"ok":True})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate"},409)

        if path.startswith("/api/product/"):
            try:pid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            now=datetime.now().isoformat(timespec="seconds")
            purchase=max(0,fnum(data.get("purchase_price")));catalog=max(0,fnum(data.get("sale_price")));pricing_mode=normalize_pricing_mode(data.get("pricing_mode"));margin=fnum(data.get("margin_pct"));margin=max(-100,margin) if pricing_mode=="MARKUP" else max(-100,min(99.99,margin));vat=max(0,fnum(data.get("vat_rate"))) if data.get("vat_rate") not in (None,"") else 23;sell=max(0,fnum(data.get("sell_price_net")))
            if sell<=0:sell=calc_sell_net(purchase,margin,pricing_mode) if purchase>0 else catalog
            expected=clean(data.get("expected_updated_at"),40)
            sku_in=clean(data.get("sku"),120);oem_in=normalize_mb_part(data.get("oem_no"));barcode_in=clean(data.get("barcode"),120) or auto_barcode_seed(oem_in,sku_in)
            vals=(sku_in,oem_in,barcode_in,clean(data.get("name"),300),
                  clean(data.get("category"),120),inum(data.get("supplier_id")),inum(data.get("location_id")),max(0,fnum(data.get("min_qty"))),
                  purchase,catalog,margin,vat,pricing_mode,sell,clean(data.get("unit"),20) or "szt.",clean(data.get("notes"),3000),clean(data.get("diagram_position"),30),now,pid)
            try:
                with db() as c:
                    if expected:
                        current=c.execute("SELECT updated_at FROM products WHERE id=?",(pid,)).fetchone()
                        if current and clean(current["updated_at"],40)!=expected:return self.send_json({"error":"edit_conflict","current_updated_at":current["updated_at"]},409)
                    cur=c.execute("""UPDATE products SET sku=?,oem_no=?,barcode=?,name=?,category=?,supplier_id=?,location_id=?,min_qty=?,purchase_price=?,sale_price=?,margin_pct=?,vat_rate=?,pricing_mode=?,sell_price_net=?,unit=?,notes=?,diagram_position=?,updated_at=? WHERE id=?""",vals)
                    if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
                    ensure_product_barcode(c,pid)
                    if "aliases" in data:
                        c.execute("DELETE FROM product_aliases WHERE product_id=?",(pid,))
                        for alias in re.split(r"[,;\n]+",clean(data.get("aliases"),2000)):
                            if normalize_mb_part(alias):add_product_alias(c,pid,alias,"MB_MANUAL","Numer edytowany ręcznie")
                return self.send_json({"ok":True})
            except sqlite3.IntegrityError:return self.send_json({"error":"duplicate_code"},409)
        return self.send_json({"error":"not_found"},404)

    def do_DELETE(self):
        path=urllib.parse.urlparse(self.path).path
        a=self.auth(csrf=True)
        if not a:return
        sid,session=a

        if path.startswith("/api/quick-catalog/"):
            try:qid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            if not has_permission(session,"products_edit"):return self.send_json({"error":"forbidden"},403)
            with db() as c:
                cur=c.execute("DELETE FROM quick_catalog_entries WHERE id=?",(qid,))
                if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
            return self.send_json({"ok":True,"deleted":qid})

        if path.startswith("/api/tool/"):
            if not has_permission(session,"tools_edit"):return self.send_json({"error":"forbidden"},403)
            try:tid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                cur=c.execute("DELETE FROM tools WHERE id=?",(tid,))
                if cur.rowcount==0:return self.send_json({"error":"not_found"},404)
            return self.send_json({"ok":True,"deleted":tid})

        if path.startswith("/api/b2b/capture/"):
            try:cid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:c.execute("DELETE FROM b2b_captures WHERE id=?",(cid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/alternative/external/"):
            try:aid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:c.execute("DELETE FROM external_substitutes WHERE id=?",(aid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/cart/item/"):
            try:iid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:c.execute("DELETE FROM purchase_cart_items WHERE id=?",(iid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/supplier/"):
            try:sid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                c.execute("UPDATE products SET supplier_id=NULL WHERE supplier_id=?",(sid,));c.execute("UPDATE warehouse_documents SET supplier_id=NULL WHERE supplier_id=?",(sid,));c.execute("UPDATE movements SET supplier_id=NULL WHERE supplier_id=?",(sid,));c.execute("DELETE FROM suppliers WHERE id=?",(sid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/location/"):
            try:lid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                used=c.execute("SELECT COUNT(*) FROM products WHERE location_id=? AND active=1",(lid,)).fetchone()[0]
                c.execute("UPDATE products SET location_id=NULL WHERE location_id=?",(lid,))
                c.execute("DELETE FROM locations WHERE id=?",(lid,))
            return self.send_json({"ok":True,"unassigned_products":used})

        if path.startswith("/api/contractor/"):
            try:cid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:c.execute("DELETE FROM contractors WHERE id=?",(cid,))
            return self.send_json({"ok":True})

        if path.startswith("/api/product/"):
            try:pid=int(path.rsplit("/",1)[1])
            except Exception:return self.send_json({"error":"bad_id"},400)
            with db() as c:
                row=c.execute("SELECT id,name FROM products WHERE id=?",(pid,)).fetchone()
                if not row:return self.send_json({"error":"not_found"},404)
                has=c.execute("SELECT COUNT(*) FROM movements WHERE product_id=?",(pid,)).fetchone()[0]
                c.execute("UPDATE products SET active=0,updated_at=? WHERE id=?",(datetime.now().isoformat(timespec="seconds"),pid))
            return self.send_json({"ok":True,"mode":"archived","movements":has})

        return self.send_json({"error":"not_found"},404)

def auto_sync_loop():
    last=0.0
    while True:
        try:
            cfg=read_integrations();mins=max(1,int(cfg.get("woo_auto_minutes",10)))
            if cfg.get("woo_auto_enabled") and cfg.get("woo_key") and cfg.get("woo_secret") and time.time()-last>=mins*60:
                if SYNC_LOCK.acquire(blocking=False):
                    try:
                        sync_woo_direct();last=time.time()
                    except Exception:
                        last=time.time()
                    finally:SYNC_LOCK.release()
        except Exception:pass
        time.sleep(30)

def run():
    init_db()
    print("="*66)
    print(" MB Auto Serwis - System Magazynowy")
    print(f" Adres lokalny: http://{HOST}:{PORT}")
    print(f" Baza: {DB_PATH}")
    print(" Tryb dostępu: " + ("LAN / wielu użytkowników" if HOST not in ("127.0.0.1","localhost") else "tylko ten komputer"))
    print("="*66)
    if os.environ.get("MBCRM_NO_BROWSER")!="1":
        threading.Thread(target=lambda:(time.sleep(.8), subprocess.Popen([chrome_executable(),"--new-tab",f"http://{HOST}:{PORT}"]) if chrome_executable() else webbrowser.open(f"http://{HOST}:{PORT}")),daemon=True).start()
    threading.Thread(target=auto_sync_loop,daemon=True).start()
    srv=ThreadingHTTPServer((HOST,PORT),Handler)
    try:srv.serve_forever()
    except KeyboardInterrupt:pass
    finally:srv.server_close()

if __name__=="__main__":run()
