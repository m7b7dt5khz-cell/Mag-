# MB Auto Serwis CRM – deployment source

Kod wdrożeniowy systemu magazynowego MB Auto Serwis 15.6.4 Stable Recovery.
Repozytorium nie zawiera bazy danych, danych klientów, haseł ani tokenów integracji.

## Render
- runtime: Docker
- host: `0.0.0.0`
- port: zmienna `PORT` nadawana przez Render
- dane trwałe: `MBMAG_DATA_DIR=/var/lib/mbcrm`
- health check: `/healthz`

Po pierwszym uruchomieniu system poprosi o utworzenie konta administratora.
